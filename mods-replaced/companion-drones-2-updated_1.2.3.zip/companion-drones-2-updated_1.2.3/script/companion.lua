local utils = require("utils") -- I don' t think I actually use anything from this currently but I might one day
local abandon_job_distance = 128 -- distance that we ignore jobs and follow the player instead
local follow_range = 12  -- how close we stick to the player
local sticker_life = 11  -- modifies flight speed (sorta, it's complicated)
local dist_bonus = 2     -- offset when setting job destination
local staging_step = 2   -- [UNUSED as of 2.0 Updated fix] previously forced a minimum
                          -- 2-tile hop even inside working range, causing the
                          -- "creeping toward job" performance bug. Kept only
                          -- for reference; no longer read anywhere.
local inner_margin = 2   -- offset when stopping on a job
local job_engage_range = 15 -- how close the companion must physically get to
                             -- a job target to be considered "in the zone"
                             -- and actually able to work it (independent of
                             -- how far it's willing to search for jobs,
                             -- storage.max_distance -- see
                             -- _job_distance_and_range())
local def_speed = 5.0    -- companion speed
local lib = {}           -- predeclaration
local debug_mode = false -- enables debugging functionality (no gameplay difference)

-- Kiting: while in combat, the companion tries to stay near the outer edge
-- of its equipped defense equipment's range instead of standing still (or
-- drifting closer) while something chews on it. kite_band is how far
-- inside max range it tolerates before retreating; kite_retreat_step is how
-- far it hops away per retreat move. Both flat, not per-tier-scaled -- see
-- the "flat multiplier, not compounding" precedent elsewhere in this file
-- (equipment recipe plate scaling, shield recharge rate) for why.
local kite_band = 12
local kite_retreat_step = 6

-- Ground hazard dodging: acid/spit attacks (vanilla spitters/worms, and
-- Space Age pentapods) don't just deal an instant hit -- their splash also
-- drops a lingering `type = "fire"` entity on the ground (see
-- acid_splash_fire() / acid-splash-fire-worm-*/-spitter-* in the base
-- game's enemy-projectiles.lua) that keeps burning anything standing in it.
-- The companion flies (water/cliffs don't block it, see set_job_destination/
-- set_attack_destination), so nothing else in this file ever steers it off
-- of a hazard tile it happens to be sitting on. Checking by prototype
-- `type == "fire"` rather than specific acid-splash-* names also means this
-- dodges ordinary fire (flamethrower turrets, burning trees) for free.
local hazard_scan_radius = 6
local hazard_retreat_step = 2 -- was 6, then 3; feedback both times said the
                               -- hop was longer than needed to clear a
                               -- puddle and long hops can break pathfinding

-- How many consecutive dodge hops (proactive or reactive) a companion will
-- take before giving up on dodging for a while. Without this, a companion
-- standing near a wide/spreading fire (or a fire wall placed deliberately
-- between it and the player) dodges forever without ever making progress
-- toward its actual goal -- confirmed live: companions never reached the
-- player through a fire wall because they kept retreating from the fire
-- indefinitely, even after it had burned out. After the streak limit is
-- hit, dodging is suppressed for hazard_dodge_suppress_ticks so whatever
-- real movement goal the companion has (reach the player, resume a job)
-- gets a chance to actually make progress, even at the cost of a few ticks
-- of fire damage.
local hazard_dodge_streak_limit = 3
local hazard_dodge_suppress_ticks = 60

-- Preserve player life: how long (ticks) a companion keeps beelining for
-- the player after the player takes a hit, refreshed on every subsequent
-- hit. ~3s -- long enough that a companion mid-flight doesn't visibly
-- bail out and resume its old job the instant the cooldown-gated damage
-- event handler happens not to fire again for a moment, short enough that
-- it doesn't permanently glue every companion to the player after one
-- graze.
local defend_player_duration = 180

-- Real per-tier attack range, must match make_defense_equipment(...)'s
-- `range` argument for companion-defense-mk1..4 in data.lua. There's no
-- live equivalent to read this back off LuaEquipment the way
-- get_roboport_reach() reads construction_radius off logistic_cell, so this
-- has to be kept in sync by hand -- same precedent as
-- defense_tier_projectile_count below, which already duplicates data.lua
-- values for the same reason.
local defense_tier_range =
{
    [1] = 23,
    [2] = 28,
    [3] = 36,
    [4] = 46,
}

-- Shared by set_attack_destination() (kiting range) and
-- get_defense_projectile_count() (damage scaling): scans the companion's
-- equipment grid for the highest-tier companion-defense-mkN it has equipped.
-- Returns 0 if no grid or no defense equipment found.
local function get_best_defense_tier(companion)
    local grid = companion.entity.grid
    if not grid then return 0 end

    local best_tier = 0
    for _, equipment in pairs(grid.equipment) do
        local tier = tonumber(equipment.name:match("^companion%-defense%-mk(%d)$"))
        if tier and tier > best_tier then
            best_tier = tier
        end
    end
    return best_tier
end

--[[ TABLE OF CONTENTS ]]--
--[[
Line  133 Initialization
Line  338 Utilities
Line 1345 Core Logic
Line 1765 Secondary Utilities
Line 2545 Migrations
Line 2754 Commands and Remotes
Last updated 4.1.0]]
--------------------------- Stat Defaults ---------------------------

local function set_defaults()
    if not storage then storage = storage or {} end
    storage.companion_update_interval = settings.startup["set-update-interval"].value or 5
    storage.fuel_multiplier = 1
    storage.companion_speed_factor = storage.companion_speed_factor or 1.0
    storage.player_speed_factor = storage.player_speed_factor or {}
    storage.base_speed                   = def_speed
    storage.attack_count                 = 8
    storage.max_distance                 = 100
    storage.max_companions               = 3
end

--------------------------- Initialization ---------------------------

local script_data =
{
    companions = {},
    active_companions = {},
    player_data = {},
    search_schedule = {},
    -- FIX (companions crisscrossing/re-treading each other's routes on a
    -- shared big task instead of each sweeping its own patch): replaces the
    -- old flat specific_job_search_queue (a single nearest-chunk-to-whoever
    -- pool shared by every companion). player_index -> { zones = { {owner =
    -- companion unit_number or nil, chunks = {area, area, ...}}, ... } }.
    -- Each zone is a contiguous vertical strip (left to right) of the
    -- queued area, worked in a fixed serpentine (column-by-column,
    -- alternating direction) order by its owner -- not nearest-first -- so
    -- one companion's path reads as a clean sweep instead of jumping
    -- around, and the "help elsewhere" fallback (see min_x below) prefers
    -- the leftmost unfinished zone, so the whole task visibly sweeps left
    -- to right as one front. See dissect_and_queue_area() (zone creation/
    -- assignment) and process_job_zones() (per-tick work pulling, including
    -- that fallback).
    job_zones = {},
    -- FIX (multi-companion duplicate routes): entity.unit_number -> claiming
    -- companion's unit_number, for entities a companion has picked as its
    -- current_job_target and is flying toward but hasn't reached yet (once
    -- real robots are dispatched, vanilla's own is_registered_for_* claim
    -- already excludes it via bots_claimed(), independent of this table).
    -- See Companion:claim_entity()/is_claimed_by_other().
    claimed_entities = {},
    -- FIX (companions converging on the same chunk while "helping" outside
    -- their own zone): player_index -> {chunk_key -> claiming companion's
    -- unit_number}. Only consulted by process_job_zones()'s fallback branch
    -- (a companion working its own zone doesn't need this -- nobody else
    -- touches that zone's front chunk). See chunk_claimed_by_other() there.
    claimed_chunks = {}
}

local function bind_storage()
    if not storage.companion then
        storage.companion = script_data
    else
        script_data = storage.companion
    end
end

lib.on_init = function()
    set_defaults()
    storage.companion = storage.companion or script_data
    storage.companion_update_interval = settings.startup["set-update-interval"].value or 5
    local force = game.forces.player
    if force.max_failed_attempts_per_tick_per_construction_queue == 1 then
        force.max_failed_attempts_per_tick_per_construction_queue = 4
    end
    if force.max_successful_attempts_per_tick_per_construction_queue == 3 then
        force.max_successful_attempts_per_tick_per_construction_queue = 8
    end
    bind_storage()
end

local repair_tools
local get_repair_tools = function()
    if repair_tools then
        return repair_tools
    end
    repair_tools = {}
    for k, item in pairs (prototypes.item) do
        if item.type == "repair-tool" then
            repair_tools[item.name] = true
        end
    end
    return repair_tools
end

local fuel_items
local get_fuel_items = function(player)
    local fuel_items = {}
    for k, item in pairs(prototypes.item) do
        if item.fuel_value > 0 and item.fuel_category == "chemical" then
            table.insert(fuel_items, {name = item.name, count = 1, fuel_top_speed_multiplier = item.fuel_top_speed_multiplier})
        end
    end

    local use_best_fuel_first = settings.get_player_settings(player)["set-fuel-preference"].value
    table.sort(fuel_items, function(a, b)
        if use_best_fuel_first then
            return a.fuel_top_speed_multiplier > b.fuel_top_speed_multiplier
        else
            return a.fuel_top_speed_multiplier < b.fuel_top_speed_multiplier
        end
    end)

    return fuel_items
end

local get_companion = function(unit_number)

    local companion = unit_number and script_data.companions[unit_number]
    if not companion then return end

    if not companion.entity.valid then
        companion:on_destroyed()
        return
    end

    return companion
end

local name = "secret_companion_surface_please_don't_touch"
local hide_secret_surface = function(surface)
    for _, force in pairs(game.forces) do
        force.set_surface_hidden(surface, true)
    end
end
local get_secret_surface = function()
    local surface = game.surfaces[name]
    if surface then
        hide_secret_surface(surface)
        return surface
    end
    surface = game.create_surface(name, {height = 1, width = 1})
    hide_secret_surface(surface)
    return surface
end

local rotate_vector = function(vector,    orientation)
    local x = vector[1] or vector.x
    local y = vector[2] or vector.y
    local angle = (orientation) * math.pi * 2
    return
    {
        x = (math.cos(angle) * x) - (math.sin(angle) * y),
        y = (math.sin(angle) * x) + (math.cos(angle) * y)
    }
end

local get_player_speed = function(player, boost)
    local boost = boost or 10.0 
    if player.vehicle then
        return math.abs(player.vehicle.speed) * boost
    end

    if player.character then
        return player.character_running_speed * boost
    end

    return 0.3

end

local Companion = {}
Companion.metatable = {__index = Companion}

local function get_max_companions(force)
    local tech = force.technologies["follower-robot-count-5"]
    -- follower-robot-count-5's level is absolute across the whole
    -- follower-robot-count-1..5 chain, not self-contained: its minimum
    -- (unresearched) level is 5, not 1. Read .level directly rather than
    -- gating on .researched -- in testing, cheating .researched via console
    -- didn't reliably stick for this infinite technology, while .level is
    -- the actual progress counter and is safe to read unconditionally
    -- (it never reports below its data-defined minimum of 5).
    local level = (tech and tech.level) or 5
    local bonus = math.max(0, level - 5)
    return storage.max_companions + bonus
end

Companion.new = function(entity, player)
    local player_data = script_data.player_data[player.index]
    if not player_data then
        player_data = {
            companions = {},
            last_job_search_offset = 0,
            last_attack_search_offset = 0
        }
        script_data.player_data[player.index] = player_data
        player.set_shortcut_available("companion-construction-toggle", true)
        player.set_shortcut_available("companion-attack-toggle", true)
    end

    local count = 0
    for _ in pairs(player_data.companions) do count = count + 1 end
    local max_companions = get_max_companions(player.force)
    if count >= max_companions then
        if count == 1 then
			player.print("Your follower-robot network is already at capacity. It can't support another companion yet.")
		else
			player.print("Your follower-robot network can't support more than " .. max_companions .. " companions yet. Research Follower robot count to expand it.")
		end
        if entity and entity.valid then
			local inserted = player.insert{name = entity.name, count = 1}
			if inserted == 0 then
				-- NEEDS FIX: If player inventory is full, just drop it on the ground
				entity.surface.spill_item_stack(entity.position, {name = entity.name, count = 1}, true, player.force, false)
			end
			entity.destroy()
		end
        return
    end

    player.request_translation({"idle-line.0"})
    player_data.companions[entity.unit_number] = true

    local companion = {
        entity = entity,
        player = player,
        unit_number = entity.unit_number,
        robots = {},
        flagged_for_equipment_changed = true,
        last_attack_tick = 0,
        job_done_pending = false,
        speed = 0,
        last_idle_line_tick = 0,
        next_forced_idle_tick = 18000,
		last_robot_count = 0
    }

    setmetatable(companion, Companion.metatable)
    script_data.companions[entity.unit_number] = companion
    script.register_on_object_destroyed(entity)

    companion:try_to_refuel()
    companion:set_active()
end

--------------------------- Utilities ---------------------------

local adjust_follow_behavior = function(player)
    local player_data = script_data.player_data[player.index]
    if not player_data then return end
    local count = 0
    local guys = {}

    local surface = player.physical_surface

    for unit_number, bool in pairs (player_data.companions) do
        local companion = get_companion(unit_number)
        if companion then
            if not companion.active and (companion.entity.surface == surface) then
                count = count + 1
                guys[count] = companion
            end
        end
    end

    if count == 0 then return end
    local reach = player.reach_distance - 2
    local length = math.min(5 + (count * 0.33), reach)
    if count == 1 then length = 2 end
    local dong = 0.75 + (0.5 / count)
    local shift = {x = 0, y =0}
    local speed = get_player_speed(player, 1.0)
    if player.vehicle then
        local orientation = player.vehicle.orientation
        dong = dong + orientation
        shift = rotate_vector({0, -speed * 15}, orientation)
    elseif player.character then
        local walking_state = player.character.walking_state
        if walking_state.walking then
            shift = rotate_vector({0, -speed * 15}, walking_state.direction / 8)
        end
    end

    local offset = {length, 0}
    local position = player.physical_position
    for k, companion in pairs (guys) do
        local angle = (k / count) + dong
        local follow_offset = rotate_vector(offset, angle)
        follow_offset.x = follow_offset.x + shift.x
        follow_offset.y = follow_offset.y + shift.y
        local target = companion.entity.follow_target
        if not (target and target.valid) then
            if player.character then
                companion.entity.follow_target = player.character
            else
                companion.entity.autopilot_destination = {position.x + follow_offset.x, position.y + follow_offset.y}
            end
        end
        -- stupid solution but if it works ... is it really stupid?
        if follow_offset and follow_offset.x and follow_offset.y and follow_offset.x <= 10000 and follow_offset.y <= 10000 then
            companion.entity.follow_offset = follow_offset
        end
        companion:set_speed(speed + companion:get_distance_boost(companion.entity.autopilot_destination))
        companion:try_to_refuel()
    end
end

-- FIX (job zone bigger than real dispatch range): job_engage_range (15) is
-- a fixed guess at "close enough for the equipped roboport to dispatch
-- robots", but real roboport construction_radius per tier is now 4/8/12/16
-- (see data.lua) -- smaller than 15 for mk1/mk2/mk3. A companion could
-- declare itself "in the job zone" at 15 tiles and stop, while its actual
-- roboport can't reach that far, so vanilla never dispatches a single
-- robot (robots stays 0 forever). The companion would then drift a little,
-- re-evaluate, stop again at ~15 tiles, forever -- visible via the debug
-- hotkey as is_busy flickering while position barely changes, even on flat
-- terrain with the player nearby (not the separate unreachable-target
-- stall case). Clamp reach to the companion's actual equipped roboport
-- radius so it only ever calls itself "in zone" somewhere robots can
-- really reach.
local function get_roboport_reach(companion)
    -- LuaEquipment has no construction_radius of its own -- the entity's
    -- logistic_cell is where vanilla exposes the (already-combined, if
    -- multiple roboports are equipped) real radius that actually matters
    -- for robot dispatch.
    local cell = companion.entity.logistic_cell
    if not cell or not cell.valid then return job_engage_range end
    local radius = cell.construction_radius
    if not radius or radius <= 0 then return job_engage_range end
    return math.min(job_engage_range, radius)
end

function Companion:_job_distance_and_range(target)
    local t = target or self.current_job_target
    if not t then return nil, nil end
    local tx = t.x or t[1]
    local ty = t.y or t[2]
    local p  = self.entity.position
    local dx = tx - p.x
    local dy = ty - p.y
    local d  = math.sqrt(dx*dx + dy*dy)
    -- FIX (oscillation loop resuming a job): this used to return
    -- storage.max_distance (how far the companion SEARCHES for work, up to
    -- 100+ tiles) as the "reach" for deciding whether it's close enough to a
    -- job to actually work it. That's a different concept from how close it
    -- physically needs to be for its equipped roboport to dispatch real
    -- robots (construction_radius, single digits to ~12 tiles) -- so
    -- set_job_destination() would stop the companion dozens of tiles short
    -- of the actual target and declare the job zone "reached", when no
    -- robot could ever engage anything from there. With current_job_target
    -- still set and nothing to do, it would drift back toward the player,
    -- cross back out of that oversized "zone", get redirected back to the
    -- job, arrive at the same short-of-target spot, and repeat forever --
    -- visible in-game as the companion circling in place, flying to the
    -- player and back with no progress. job_engage_range is a small,
    -- fixed "close enough to actually work" distance, decoupled from the
    -- search radius, further clamped to the actually-equipped roboport's
    -- real construction_radius (see get_roboport_reach() above).
    local reach = get_roboport_reach(self)
    return d, reach
end

function Companion:_inside_job_zone(margin)
    local d, reach = self:_job_distance_and_range()
    if not d then return false end
    margin = margin or inner_margin
    return d <= math.max(0, reach - margin)
end

local function eff_base()
    if not storage.companion_speed_factor then
        storage.companion_speed_factor = 1.0
    end
    return (storage.base_speed) * (storage.companion_speed_factor)
end

local get_speed_boost = function(burner)
    local burning = burner and burner.currently_burning
    if not burning then return 1 end
    storage.fuel_multiplier = storage.fuel_multiplier or 1
    return (burning.fuel_top_speed_multiplier or 1) * storage.fuel_multiplier
end

function Companion:can_spawn_robot()
    return table_size(self.robots or {}) < (storage.scripted_robot_limit or 69)
end

function Companion:set_robot_stack()
    local inventory = self:get_inventory()
    if not inventory.set_filter(21,"companion-construction-robot") then
        inventory[21].clear()
        inventory.set_filter(21,"companion-construction-robot")
    end

    -- FIX (stuck oscillating full/not-full, "laser bank" flickering): the
    -- companion's roboport-equipment is a real personal logistic network, so
    -- the game itself autonomously dispatches robots to anything within
    -- construction_radius the instant slot 21 has reserve robots in it --
    -- entirely independent of try_to_find_work()/pick(). Standing in the
    -- middle of a big to-be-deconstructed area, every single one of those
    -- auto-dispatches fires robot_spawned() -> set_active() -> back here,
    -- which used to unconditionally refill the stack to 100 regardless of
    -- why we got called. That meant the full-inventory recall in
    -- Companion:update() could clear_robots() all it wanted: the network
    -- would just get handed a fresh 100-robot reserve on the very next spawn
    -- and immediately redeploy, so is_busy_for_construction never actually
    -- settled to false and the drone could never leave to go unload. Refuse
    -- to restock while getting full so the network genuinely runs dry.
    if self.can_construct and self:player_wants_construction() and not self.is_getting_full then
        inventory[21].set_stack({name = "companion-construction-robot", count = 100})
    else
        inventory[21].clear()
    end
end

function Companion:clear_robot_stack()
    local inventory = self:get_inventory()
    if not inventory.set_filter(21,"companion-construction-robot") then
        inventory[21].clear()
        inventory.set_filter(21,"companion-construction-robot")
    end
    inventory[21].clear()
end

function Companion:set_active()
    self:set_robot_stack()
    self.flagged_for_equipment_changed = true
    local mod = self.unit_number % storage.companion_update_interval
    local list = script_data.active_companions[mod]
    if not list then
        list = {}
        script_data.active_companions[mod] = list
    end
    list[self.unit_number] = true
    self.active = true
    self:set_speed((eff_base() * 1.2) * get_speed_boost(self.entity.burner))
    adjust_follow_behavior(self.player)
end

function Companion:clear_active()
    if not self.active then return end
    if not self.out_of_energy then
        local pending_job_line = self.job_done_tick and not self.job_done_announced
        if pending_job_line and game.tick - self.job_done_tick < 10 then
            if math.random(1, 20) > 15 then
                self:say_random("search-for-nearby-work-line")
            end
            self.job_done_announced = true
            self.job_done_tick = nil
        end
    end
    local mod = self.unit_number % storage.companion_update_interval
    local list = script_data.active_companions[mod]
    if not list then
        error("companion clear_active()")
        return
    end
    list[self.unit_number] = nil
    if not next(list) then
        script_data.active_companions[mod] = nil
    end
    self.active = false
    self:clear_robots()
    adjust_follow_behavior(self.player)
    self.next_idle_line_tick = nil
    self.test_idle_tick = nil
    self.test_idle_fired = nil
    self.job_done_tick = nil
   
    return
end

function Companion:clear_speed_sticker()
    if not self.speed_sticker then return end
    self.speed_sticker.destroy()
    self.speed_sticker = nil
end

function Companion:get_speed_sticker()
    if self.speed_sticker and self.speed_sticker.valid then
        return self.speed_sticker
    end
    self.speed_sticker = self.entity.surface.create_entity{
        name   = "speed-sticker",
        target = self.entity,
        force  = self.entity.force,
        position = self.entity.position,
    }
    if self.speed_sticker then self.speed_sticker.disabled_by_script = false end -- 2.1: .active write removed
    return self.speed_sticker
end

function Companion:get_distance_boost(position)
    local distance = self:distance(position)
    return (distance / 10)
end


function Companion:clear_speed_fx()
    local fx = self.speed_fx
    if fx and fx.valid then
        fx.destroy()
    end
    self.speed_fx = nil
end

function Companion:get_speed_fx()
    local fx = self.speed_fx
    if fx and fx.valid then
        return fx
    end
    self.speed_fx = rendering.draw_animation{
        animation    = "companion-speed-flame",
        target       = self.entity,
        surface      = self.entity.surface,
        render_layer = "object",
    }
    return self.speed_fx
end

function Companion:set_speed(speed)
    local factor = storage.companion_speed_factor or 1.0
    self.speed = speed
    self._last_speed_factor = factor
    if not storage.base_speed then storage.base_speed = 10 end

    local pos = self.entity.position
    local tick = game.tick
    local v = 0
    if self._last_pos and self._last_pos_tick then
        local dt = tick - self._last_pos_tick
        if dt > 0 then
            local dx = pos.x - self._last_pos.x
            local dy = pos.y - self._last_pos.y
            v = math.sqrt(dx*dx + dy*dy) / dt
        end
    end
    self._last_pos = pos
    self._last_pos_tick = tick

    if v > 0.015 then
        local sticker = self:get_speed_sticker()
        if sticker and sticker.valid then
            sticker.time_to_live = 11
            sticker.disabled_by_script = false -- 2.1: .active write removed
        end
        local fx = self:get_speed_fx()
        if fx and fx.valid then
            fx.time_to_live = 11

            local S_MIN  = 0.15
            local S_MAX  = 1.0
            local V_FULL = 0.11
            local SENS   = 100.0

            local GAIN = (1.0 - S_MIN) / math.log(1 + SENS * V_FULL)
            local s = S_MIN + GAIN * math.log(1 + SENS * v)
            if s > S_MAX then s = S_MAX end

            fx.x_scale = s
            fx.y_scale = s
        end
    else
        self:clear_speed_sticker()
        self:clear_speed_fx()
    end
end

function Companion:get_speed()
    return self.speed
end

function Companion:get_grid()
    return self.entity.grid
end

function Companion:clear_passengers()

    if self.driver and self.driver.valid then
        self.driver.destroy()
        self.driver = nil
    end

    if self.passenger and self.passenger.valid then
        self.passenger.destroy()
        self.passenger = nil
    end

end

function Companion:check_equipment()
    self.flagged_for_equipment_changed = nil

    local grid = self:get_grid()

    self.can_construct = false
    for k, equipment in pairs (grid.equipment) do
        if equipment.type == "roboport-equipment" then
			if equipment.name:find("^companion%-roboport") then
				self.can_construct = true
				break
			elseif equipment.name:find("^personal%-roboport") then
				self:say("I can't use this, this roboport is for you!")
				break
			end
		end
    end

    if self.can_construct then
        local network = self.entity.logistic_network
        local max_robots = (network and network.robot_limit) or 100
        if max_robots > 0 then
            self:set_robot_stack()
        else
            self.can_construct = false
        end
    else
        self:clear_robots()
		self:return_to_player()
    end

    self.can_attack = false
    for k, equipment in pairs (grid.equipment) do
        if equipment.type == "active-defense-equipment" then
            self.can_attack = true
            break
        end
    end
end

function Companion:robot_spawned(robot)
    if not (robot and robot.valid) then return end
    local id = robot.unit_number
    self:set_active()
    self.robots[id] = robot
    if robot.valid then
        robot.destructible = false
        robot.minable_flag = false -- 2.1: .minable write removed
    end
    if self.entity and self.entity.valid and robot.valid then
        self.entity.surface.create_entity{
            name = "inserter-beam",
            position = self.entity.position,
            target = robot,
            source = self.entity,
            force = self.entity.force,
            source_offset = {0, 0}
        }
    end
    self:move_to_robot_average()
end

function Companion:clear_robots()
    for k, robot in pairs(self.robots) do
        local r = robot
        if r and r.valid then
            local ok = pcall(function()
                r.mine{
                    inventory      = self:get_inventory(),
                    force          = true,
                    ignore_minable = true
                }
            end)
            if not ok and r.valid then
                r.destroy()
            end
        end
        local beam_ok, beam = pcall(function() return robot.beam end)
        if beam_ok and beam and beam.valid then
            beam.destroy()
        end
        self.robots[k] = nil
    end
    self:clear_robot_stack()
end

function Companion:move_to_robot_average()
    if not next(self.robots) then return false end

    -- FIX (stuck-mid-job bug): this function runs every single tick via
    -- update_state_flags(). It used to unconditionally overwrite
    -- entity.autopilot_destination with the current robot average position,
    -- even while the drone was already actively flying somewhere else via
    -- set_job_destination (moving_to_destination == true). Since the robots
    -- drift slightly every tick, this meant the autopilot target changed
    -- every tick too, which repeatedly cancels/restarts spidertron pathing
    -- and can leave the drone stuck in place indefinitely. Now: if we're
    -- already navigating to a staged job position, leave that path alone.
    if self.moving_to_destination then
        return true
    end

    local position = { x = 0, y = 0 }
    local count = 0
    for k, robot in pairs(self.robots) do
        if robot and robot.valid then
            local rp = robot.position
            position.x = position.x + rp.x
            position.y = position.y + rp.y
            count = count + 1
        else
            self.robots[k] = nil
        end
    end
    if count == 0 then return false end

    position.x = position.x / count
    position.y = position.y / count

    -- FIX (micro-stutter): only actually redirect the drone if it has
    -- drifted meaningfully from its robots. Previously this reassigned
    -- autopilot_destination every tick to a slightly different point,
    -- forcing constant deceleration/reacceleration even at a standstill.
    local self_pos = self.entity.position
    local ddx = position.x - self_pos.x
    local ddy = position.y - self_pos.y
    if (ddx * ddx + ddy * ddy) > (4 * 4) then
        self.entity.autopilot_destination = position
    end

    return true
end

function Companion:try_to_refuel()
    if not self:get_fuel_inventory().is_empty() or self.entity.energy > 0 then return end
	self:say("Refueling...")
    if self:distance(self.player.physical_position) <= follow_range then
        for k, item in pairs (get_fuel_items(self.player)) do
            if self:find_and_take_from_player({name = item.name, count = item.count}) then
                return
            end
        end
    end
    return true
end

function Companion:update_state_flags()
    self.out_of_energy = self:try_to_refuel()
    self.is_in_combat = (game.tick - self.last_attack_tick) < 60
    self.is_on_low_health = self.entity.get_health_ratio() < 0.7
    self.is_busy_for_construction = not not (self.is_in_combat or self:move_to_robot_average() or self.moving_to_destination)
    -- "not not" coerces it into a strict true/false result, never just truthy or falsey
    -- FIX (wasted cargo capacity): cargo lives in slots 1-20 (slot 21 is the
    -- robot reserve, see set_robot_stack()). This used to trigger the full-
    -- cargo recall at slot 16 (4 of 20 slots still empty), which was overly
    -- conservative: a robot that can't deliver its result because the
    -- companion is full just holds onto it and retries once a slot frees up
    -- (nothing gets dropped/lost), so there's little real risk in running
    -- closer to the edge. Slot 19 leaves one slot of headroom for whatever
    -- lands the same tick this flips true, while still using effectively all
    -- of the companion's storage before heading home to unload.
    self.is_getting_full = self:get_inventory()[19].valid_for_read
end

-- FIX (multi-companion duplicate/overlapping routes): without this, two
-- companions independently searching the same area could both pick the same
-- nearest ghost/decon-marked entity as their current_job_target, since
-- neither has real robots dispatched yet at pick time (bots_claimed() only
-- catches an entity once vanilla's logistic network has actually claimed it
-- for construction/repair/etc, which happens after the companion is already
-- in range -- not during the "flying there" window). Records which companion
-- has which entity as its live target so other companions' searches skip it
-- in the meantime. Always route new current_job_target assignments through
-- this (see try_to_find_work's pick()) and always release via claim_entity(nil)
-- everywhere current_job_target gets cleared, or the two can drift out of
-- sync and either strand a stale claim forever or let it slip and stop
-- protecting anything.
function Companion:claim_entity(entity)
    if self.claimed_unit_number then
        if script_data.claimed_entities[self.claimed_unit_number] == self.unit_number then
            script_data.claimed_entities[self.claimed_unit_number] = nil
        end
        self.claimed_unit_number = nil
    end
    -- kept as a direct LuaEntity reference (not just the unit_number) so
    -- return_to_player() can cheaply check .valid to tell a genuinely
    -- unfinished job apart from a stale current_job_target pointing at an
    -- entity that's already been completed/destroyed by the time the
    -- companion is free to resume it -- see the FIX note in return_to_player().
    self.claimed_target_entity = (entity and entity.valid) and entity or nil
    -- FIX (pre_recall_position never clearing for entities without a
    -- unit_number, e.g. corpses/some neutral decon entities): this used to
    -- live inside the `if uid then` block below, so any pick of a
    -- unit_number-less entity left the stale pre-recall bias in place
    -- indefinitely (confirmed live via the RCON test harness -- a companion
    -- kept reporting a non-nil pre_recall after already resuming real work).
    -- Any valid entity pick means the companion is genuinely back at work,
    -- regardless of whether that entity happens to have a unit_number.
    if entity and entity.valid then
        self.pre_recall_position = nil
    end
    local uid = entity and entity.valid and entity.unit_number
    if uid then
        script_data.claimed_entities[uid] = self.unit_number
        self.claimed_unit_number = uid
    end
end

function Companion:is_claimed_by_other(entity)
    local uid = entity.unit_number
    if not uid then return false end
    local owner_uid = script_data.claimed_entities[uid]
    if not owner_uid or owner_uid == self.unit_number then return false end
    local owner = get_companion(owner_uid)
    if not owner or not owner.entity or not owner.entity.valid then
        script_data.claimed_entities[uid] = nil
        return false
    end
    return true
end

-- FIX (zone assignment getting drowned out by opportunistic local search):
-- job_zones (see dissect_and_queue_area()/process_job_zones()) only decides
-- a companion's very first pick when it goes from idle to working. Once it
-- has real robots out, both search_for_nearby_work() and the "finish
-- everything in range" continuation in Companion:update() used to search a
-- full storage.max_distance (100 tile) radius around the companion's
-- current position on every relevant tick -- which fires far more often
-- than process_job_zones() ever runs, so it dominated actual movement and
-- let a companion wander into any nearby zone regardless of which one it
-- owns, making the zone assignment barely visible in practice (confirmed by
-- the user: only "minimal" signs of the zones, otherwise flying the same
-- crisscrossing pattern as before). If this companion currently owns an
-- unfinished job zone, constrain the search to just its zone's next chunk
-- (plus a small margin for entities straddling the chunk edge) instead of
-- the wide radius, so it can't stray outside its own lane while working
-- through it. Falls back to the old wide-radius search once its zone is
-- exhausted (or it never had one), matching the "help elsewhere" fallback
-- process_job_zones() already uses.
function Companion:get_local_search_area()
    local zone_state = script_data.job_zones[self.player.index]
    if zone_state then
        local own_chunk
        for _, zone in ipairs(zone_state.zones) do
            if zone.owner == self.unit_number and #zone.chunks > 0 then
                own_chunk = zone.chunks[1]
                break
            end
        end
        -- FIX (wide search reappearing during the "help elsewhere" phase):
        -- this used to only check zone.owner, so once a companion finished
        -- its own zone and started helping another one (self.adopted_zone,
        -- see process_job_zones()), it wasn't the owner of that zone and
        -- fell straight through to the wide radius search below anyway --
        -- silently undoing the chunk confinement for the entire help phase,
        -- not just the initial "own zone" phase.
        if not own_chunk and self.adopted_zone and #self.adopted_zone.chunks > 0 then
            own_chunk = self.adopted_zone.chunks[1]
        end
        if own_chunk then
            local margin = 4
            return {
                {own_chunk[1][1] - margin, own_chunk[1][2] - margin},
                {own_chunk[2][1] + margin, own_chunk[2][2] + margin}
            }
        end
    end
    local radius = storage.max_distance or 100
    -- search around where the companion was working before a full-cargo
    -- recall, not its current (post-unload, near-base) position -- see the
    -- FIX note on pre_recall_position in Companion:update().
    local origin = self.pre_recall_position or self.entity.position
    return {{origin.x - radius, origin.y - radius}, {origin.x + radius, origin.y + radius}}
end

function Companion:search_for_nearby_work()
    if not self:player_wants_construction() or not self.can_construct then return end
    if self.entity.surface ~= self.player.physical_surface then return end
	local area = self:get_local_search_area()

    -- FIX (queued task abandoned after finishing a local piece of it): this
    -- used to always tag the pick as an ad-hoc find (from_queue = nil), even
    -- though this function only ever runs right after finishing a job that
    -- came from the explicit task queue. That silently dropped the leash
    -- exemption the moment the drone picked up the next entity right next
    -- to it, so it would immediately get abandoned again on the very next
    -- tick's leash check if the player was elsewhere. Propagate whatever the
    -- just-finished job's origin was instead of resetting it.
	local found = self:try_to_find_work(area, self.current_job_from_queue)

    -- FIX (return-to-player/resume-job oscillation): current_job_target used
    -- to linger forever once a job was finished and nothing new was found
    -- nearby, still pointing at the now-completed spot. return_to_player()'s
    -- redirect branch doesn't verify the target still has real work at it --
    -- it just checks distance -- so it would keep trying to fly the
    -- companion back to that stale point every time it drifted outside
    -- job_engage_range on its way to the player, then "arrive" at a spot
    -- with nothing to do, drift out of range again, and repeat forever, even
    -- with the whole task long since complete. Clear it here: this function
    -- only ever runs right after finishing a job, so if it can't find
    -- anything else in range either, that job is genuinely done.
    if not found then
        self.current_job_target = nil
        self.current_job_from_queue = nil
        self:claim_entity(nil)
        self.pre_recall_position = nil
    end
end

function Companion:search_for_nearby_targets()
    if not self:player_wants_attack() then return end
    if not self.can_attack then return end
    if self.entity.surface ~= self.player.physical_surface then return end
    local range = 32
    local origin = self.entity.position
    local area = {{origin.x - range, origin.y - range}, {origin.x + range, origin.y + range}}
    --self:say("NICE")
    self:try_to_find_targets(area)
end

function Companion:is_idle()
    -- are we currently working?
    return not self.is_in_combat or not self.is_busy_for_construction
end

function Companion:is_busy()
    -- are we doing ANYthing at all?
    return self.is_in_combat or self.is_busy_for_construction or self.moving_to_destination
end

function Companion:say(text)
	if not settings.startup["companion-voice-lines"].value then return end
    local tick_value = 0
    local live_value = 0
    if debug_mode then -- when debugging, text is short lived and rapid firing
        tick_value = 1 
        live_value = 30 
    else -- otherwise text lasts 4 seconds and can only fire twice per second
        tick_value = 30 
        live_value = 240 
    end
    if (game.tick - (self.last_spoken_tick or 0)) <= tick_value then return end 
    self.last_spoken_tick = game.tick
    self.player.create_local_flying_text{
        position = {x = self.entity.position.x, y = self.entity.position.y - 2.5},
        text = text or "Error",
        color = {r = 0.4, g = 0.8, b = 1},
		time_to_live = live_value,
		speed = 0.5
    }
end

function Companion:on_destroyed()
    if not script_data.companions[self.unit_number] then
        --On destroyed has already been called.
        return
    end

	for k, robot in pairs(self.robots) do
		local r = robot
		if r and r.valid then 
            r.destroy() 
        end
	end

    script_data.companions[self.unit_number] = nil
    local player_data = script_data.player_data[self.player.index]

    player_data.companions[self.unit_number] = nil

    if not next(player_data.companions) then
        script_data.player_data[self.player.index] = nil
        self.player.set_shortcut_available("companion-attack-toggle", false)
        self.player.set_shortcut_available("companion-construction-toggle", false)
    end

    adjust_follow_behavior(self.player)
end

function Companion:distance(position)
    local source = self.entity.position
    local x2 = position[1] or position.x
    local y2 = position[2] or position.y
    return (((source.x - x2) ^ 2) + ((source.y - y2) ^ 2)) ^ 0.5
end

function Companion:get_inventory()
    local inventory = self.entity.get_inventory(defines.inventory.spider_trunk)
    inventory.sort_and_merge()
    return inventory
end

function Companion:get_fuel_inventory()
    local inventory = self.entity.get_fuel_inventory()
    inventory.sort_and_merge()
    return inventory
end

function Companion:insert_to_player_or_vehicle(stack)

    local inserted = self.player.insert(stack)
    if inserted > 0 then return inserted end

    if self.player.vehicle then
        inserted = self.player.vehicle.insert(stack)
        if inserted > 0 then return inserted end
        if self.player.vehicle.train then
            inserted = self.player.vehicle.train.insert(stack)
            if inserted > 0 then return inserted end
        end
    end

    return 0

end

function Companion:try_to_shove_inventory()
    local inventory = self:get_inventory()
    local total_inserted = 0
    for k = 1, 20 do
        local stack = inventory[k]
        if not (stack and stack.valid_for_read) then break end
        local inserted = self:insert_to_player_or_vehicle(stack)
        if inserted == 0 then
            self.player.print({"inventory-restriction.player-inventory-full", stack.prototype.localised_name, {"inventory-full-message.main"}})
            break
        else
            total_inserted = total_inserted + inserted
            if inserted == stack.count then
                stack.clear()
            else
                stack.count = stack.count - inserted
            end
        end
    end

    if total_inserted > 0 then
        self.entity.surface.create_entity
        {
            name = "inserter-beam",
            source = self.entity,
            target = self.player.character,
            target_position = self.player.physical_position,
            force = self.entity.force,
            position = self.entity.position,
            duration = math.min(math.max(math.ceil(total_inserted / 5), 10), 60),
            max_length = follow_range + 4
        }
    end

end

function Companion:has_items()
    return self:get_inventory()[1].valid_for_read
end

function Companion:can_go_inactive()
    if self.out_of_energy then return end
    if self:is_busy() then return end
    if self:has_items() then return end
    if self:distance(self.player.physical_position) > follow_range then return end
    return true
end

-- Dedicated unconditional path home used only for the full-inventory
-- recall. return_to_player() below is written for the "job finished,
-- casually follow/idle" case and has a branch that redirects the
-- companion straight back to current_job_target whenever it isn't
-- currently standing inside the job zone's margin -- which is exactly
-- backwards for this case: the whole point of calling it is that the
-- companion is full and must go unload, no matter where its job target
-- is. It also never bailed early on is_busy_for_construction, which
-- return_to_player() does, and that flag can still read true for a
-- tick or two after clear_robots() while stale state catches up. This
-- function skips both hazards entirely so a full companion always
-- heads home immediately.
function Companion:force_return_to_player()
    if not self.player.valid then return end
    if self.player.physical_surface ~= self.entity.surface then return end

    local distance = self:distance(self.player.physical_position)

    if distance <= follow_range then
        self:try_to_shove_inventory()
        if not self.entity.valid then return end
    end

    if distance > 500 then
        self:teleport(self.player.physical_position, self.entity.surface)
        return
    end

    -- Full working speed, not the casual 0.8x follow pace return_to_player()
    -- uses when it's just idly tagging along: this is an urgent supply-run
    -- interrupting real work, not a leisurely stroll back to the player.
    self:set_speed(math.max((eff_base() * 1.2) * get_speed_boost(self.entity.burner), get_player_speed(self.player, 1.0)))
    if self.player.character then
        self.entity.follow_target = self.player.character
    else
        self.entity.autopilot_destination = self.player.physical_position
    end
end

function Companion:return_to_player()

    if not self.player.valid then return end
    if self.is_busy_for_construction then return end
    if self.player.physical_surface ~= self.entity.surface then
        return
    end

    self.moving_to_destination = nil
    local distance = self:distance(self.player.physical_position)

    if distance <= follow_range then
        self:try_to_shove_inventory()
        if not (self.entity.valid) then return end
    end

    if distance > 500 then
        self:teleport(self.player.physical_position, self.entity.surface)
    end
    
    -- FIX (companions flying back to/converging on already-finished work):
    -- current_job_target is deliberately left set through a full-cargo
    -- supply run (see the is_getting_full branch in Companion:update()) so
    -- the companion resumes the same task once it's emptied out, rather
    -- than abandoning it. But nothing re-validates that target in the
    -- meantime -- if the specific entity it pointed at gets finished
    -- (destroyed) by another companion, or by this companion's own robots
    -- right before recalling, while this companion is away unloading, this
    -- redirect used to fly it straight back to that now-empty spot anyway.
    -- Visually this reads as companions "following"/converging on each
    -- other or one companion flying back toward where a teammate is
    -- already working, and it also raced against process_job_zones
    -- reassigning the same now-free companion to a genuinely nearest
    -- unclaimed chunk -- whichever ran first for a given tick "won",
    -- producing inconsistent behavior (sometimes the companions spread out
    -- correctly, sometimes one doubles back). claimed_target_entity (see
    -- Companion:claim_entity()) is the actual entity this current_job_target
    -- was picked for, if any single-entity claim is still associated with
    -- it, so check it's still real before flying back to it -- if it's not,
    -- drop the stale target instead of chasing it, and fall through to the
    -- normal idle/follow-player path so the next queue pass reassigns this
    -- companion fresh instead of racing a dead redirect.
    if self.current_job_target
    and self:player_wants_construction()
    and self.can_construct
    and (not self.claimed_target_entity or self.claimed_target_entity.valid)
    and not self:_inside_job_zone() then
        if not self.moving_to_destination then
            self:set_job_destination(self.current_job_target)
        end
        return
    elseif self.current_job_target and self.claimed_target_entity and not self.claimed_target_entity.valid then
        self.current_job_target = nil
        self.current_job_from_queue = nil
        self:claim_entity(nil)
    end

    if self:can_go_inactive() then
        self:clear_active()
        return
    end

    self:set_speed(math.max(eff_base() * 0.8, get_player_speed(self.player, 1.0)))

    if self.player.character then
        self.entity.follow_target = self.player.character
        return
    end
    self.entity.autopilot_destination = self.player.physical_position
end

function Companion:take_item(item, target)
    local target_inventory = get_inventory(target)
    if not target_inventory then return end

    while true do
        local stack = target_inventory.find_item_stack({ name = item.name, quality = item.quality })
        if not stack then break end

        local given = self.entity.insert(stack)
        if given == 0 then break end
        if given == stack.count then
            stack.clear()
        else
            stack.count = stack.count - given
        end
        item.count = item.count - given
        if item.count <= 0 then break end
    end

    if item.count <= 0 then
        local extra_stacks = 2 -- how much extra material the companion grabs in anticipation of more work
        local stack_size = (prototypes.item[item.name] and prototypes.item[item.name].stack_size) or 100
        local extra_to_take = extra_stacks * stack_size
        local taken_extra = 0

        while taken_extra < extra_to_take do
            local stack = target_inventory.find_item_stack({ name = item.name, quality = item.quality })
            if not stack then break end
            local given = self.entity.insert(stack)
            if given == 0 then break end
            if given == stack.count then
                stack.clear()
            else
                stack.count = stack.count - given
            end
            taken_extra = taken_extra + given
        end
    end

    self.entity.surface.create_entity{
        name = "inserter-beam",
        source = self.entity,
        target = (target.is_player() and target.character) or nil,
        target_position = target.position,
        force = self.entity.force,
        position = self.entity.position,
        duration = math.min(math.max(math.ceil(item.count / 5), 10), 60),
        max_length = follow_range + 4
    }

    return item.count <= 0
end

function Companion:take_item_from_train(item, train)
    for k, wagon in pairs(train.cargo_wagons) do
        if self:take_item(item, wagon) then
            return true
        end
    end
    return false
end

local angle = function(position_1, position_2)
    local d_x = (position_2[1] or position_2.x) - (position_1[1] or position_1.x)
    local d_y = (position_2[2] or position_2.y) - (position_1[2] or position_1.y)
    return math.atan2(d_y, d_x)
end

function Companion:get_offset(target_position, length, angle_adjustment)
        local angle = angle(self.entity.position, target_position)
        angle = angle + (math.pi / 2) + (angle_adjustment or 0)
        local x1 = (length * math.sin(angle))
        local y1 = (-length * math.cos(angle))
        return {x1 / 10, y1 / 10}
end

function Companion:set_attack_destination(position)
    -- FIX (companion "cooked alive" standing in fire during a fight):
    -- vanilla's own equipment cooldown calls this on its own schedule,
    -- completely independent of Companion:update()'s hazard scan -- so even
    -- when update() correctly issued a retreat away from nearby fire, a
    -- combat attack cycle landing on a later tick could immediately
    -- overwrite that with a kite/hold destination that put the companion
    -- right back in the hazard, since the two systems didn't know about
    -- each other. Escaping fire/acid always wins over combat positioning
    -- for this attack cycle; the companion keeps firing at its target
    -- regardless of where it's currently moving (vanilla auto-fires within
    -- range independent of movement), so nothing is lost by not
    -- repositioning for it this tick.
    if self:dodge_ground_hazard() then
        self.last_attack_tick = game.tick
        self.is_in_combat = true
        return
    end

    local self_position = self.entity.position
    local real_distance = self:distance(position)

    local tier = get_best_defense_tier(self)
    local weapon_range = defense_tier_range[tier] or defense_tier_range[2]
    local kite_min_range = math.max(weapon_range - kite_band, 1)

    if real_distance < kite_min_range then
        -- KITE: the target has closed past our comfortable engagement band --
        -- hop straight away from it instead of holding ground or (worse)
        -- closing the rest of the way in, so the companion keeps landing
        -- shots while taking as little incoming damage as possible.
        self:step_away_from(position, kite_retreat_step)
    else
        -- Already at or beyond kiting range: hold position rather than
        -- creeping closer -- vanilla only fires this equipment when the
        -- target is within attack_parameters.range in the first place, so
        -- there's nothing to gain by closing distance mid-fight.
        local distance = real_distance + dist_bonus
        if math.abs(distance) > 2 then
            local offset = self:get_offset(position, distance, (distance < 0 and math.pi/4) or 0)
            self_position.x = self_position.x + offset[1]
            self_position.y = self_position.y + offset[2]
            self.moving_to_destination = true
            self.entity.autopilot_destination = self_position
        end
    end

    self.last_attack_tick = game.tick
    self.is_in_combat = true
    self:set_active()
end

function Companion:set_job_destination(position)
    local self_pos = self.entity.position
    local tx = position.x or position[1]
    local ty = position.y or position[2]
    local dx = tx - self_pos.x
    local dy = ty - self_pos.y
    local d  = math.sqrt(dx*dx + dy*dy)

    self.current_job_target = position

    if d <= 2 then
        self.moving_to_destination = nil
        return
    end

    local _, reach = self:_job_distance_and_range(position)
    local safe_reach = math.max(0, reach - inner_margin)

    -- FIX (performance/creep bug): previously this function forced a minimum
    -- "staging_step" hop of 2 tiles even when we were already comfortably
    -- inside our working range of the target. That caused the drone to keep
    -- taking tiny extra hops toward jobs it could already work on, braking
    -- and re-accelerating over and over ("hovering" / creeping instead of
    -- flying properly). Now: if we're already within working range, don't
    -- move at all.
    if d <= safe_reach then
        self.moving_to_destination = nil
        return
    end

    local inner_needed = d - safe_reach
    local step = math.min(inner_needed, d - 1)

    local nx, ny = dx / d, dy / d
    local dest = { x = self_pos.x + nx * step, y = self_pos.y + ny * step }

    self.moving_to_destination = true
    self.entity.follow_target = nil
    self.entity.autopilot_destination = dest
    self.is_busy_for_construction = true
    self:set_active()
end

function Companion:player_wants_attack()
    return self.player.is_shortcut_toggled("companion-attack-toggle")
end

function Companion:player_wants_construction()
    return self.player.is_shortcut_toggled("companion-construction-toggle")
end

function Companion:attack(entity, projectile_count)
    if not self:player_wants_attack() then return end

    projectile_count = projectile_count or 3  -- default if not provided

    local position = self.entity.position
    for i = 1, projectile_count do
        local offset = (math.random() * 0.5) - 0.25

        local projectile = self.entity.surface.create_entity{
            name = "companion-projectile",
            position = {position.x, position.y - 1.5},
            speed = 0.05,
            force = self.entity.force,
            target = entity,
            max_range = 55
        }

        projectile.orientation = projectile.orientation + offset

        local beam = self.entity.surface.create_entity{
            name = "inserter-beam",
            source = self.entity,
            target = self.entity,
            position = {0, 0}
        }
        beam.set_beam_target(projectile)
    end

    self:set_attack_destination(entity.position)
    self.last_attack_tick = game.tick
end

local ghost_types =
{
    ["entity-ghost"] = true,
    ["tile-ghost"] = true
}

local item_request_types =
{
    ["entity-ghost"] = true,
    ["item-request-proxy"] = true

}

function Companion:try_to_find_targets(search_area)

    local entities = self.entity.surface.find_entities_filtered
    {
        area = search_area,
        is_military_target = true
    }

    local our_force = self.entity.force
    for k, entity in pairs (entities) do
        if not entity.valid then break end
        if entity.destructible then
            local force = entity.force
            if not (force == our_force or force.name == "neutral" or our_force.get_cease_fire(entity.force)) then
                self:set_attack_destination(entity.position)
                return
            end
        end
    end

end

function get_inventory(entity)
    if entity.is_player() then
        if not entity.controller_type or entity.controller_type ~= defines.controllers.character then return end
        return entity.get_main_inventory() or entity.get_output_inventory()
    end

    if entity.type == "spider-vehicle" then
        return entity.get_inventory(defines.inventory.spider_trunk)
    elseif entity.type == "car" then
        return entity.get_inventory(defines.inventory.car_trunk)
    elseif entity.type == "cargo-wagon" then
        return entity.get_inventory(defines.inventory.cargo_wagon)
    else
		return entity.get_main_inventory() or entity.get_output_inventory()
	end
end

function Companion:find_and_take_from_player(item)
    local count = self.player.get_item_count{ name = item.name, quality = (item.quality or "normal") }
    if count >= item.count then
        if self:take_item(item, self.player) then
            return true
        end
    end

    local vehicle = self.player.vehicle
    if vehicle then
        local train = vehicle.train
        if not train then
            local target_inventory = get_inventory(vehicle)
            local count = target_inventory.get_item_count{ name = item.name, quality = (item.quality or "normal") }
            if count >= item.count then
                if self:take_item(item, vehicle) then
                    return true
                end
            end
        else
            local train_contents = train.get_contents()

            local count = 0

            for _, item_in_train in pairs(train_contents) do
                if (item_in_train.name == item.name and item_in_train.quality == item.quality) then
                    count = item_in_train.count
                    break
                end
            end

            if count >= item.count then
                if self:take_item_from_train(item, train) then
                    return true
                end
            end
        end
    end
end

function Companion:on_player_placed_equipment(event)
    self:set_active()
    --self:say("Equipment added")
end

function Companion:on_player_removed_equipment(event)
    self:set_active()
    --self:say("Equipment removed")
end

function Companion:teleport(position, surface)
    self:clear_robots()
    self:clear_speed_sticker()
    self:clear_speed_fx()  
    self.entity.teleport(position, surface)
    self:set_active()
end

function Companion:change_force(force)

    self.entity.force = force
    for k, robot in pairs (self.robots) do
        if robot.valid then
            robot.force = force
        end
    end

    self:check_equipment()

end

local on_built_entity = function(event)
    local entity = event.entity
    if not (entity and entity.valid) then return end

    if entity.name ~= "companion" then
        return
    end

    local player = event.player_index and game.get_player(event.player_index)
    if not player then return end

    Companion.new(entity, player)

end

local on_entity_destroyed = function(event)
    local companion = get_companion(event.unit_number)
    if not companion then return end
    companion:on_destroyed()
end

local search_offsets = {}
local search_distance = 100
local search_divisions = 7

local setup_search_offsets = function()
    local r = search_distance / search_divisions
    search_offsets = {}
    for y = 0, (search_divisions - 1) do
        local offset_y = (y - (search_divisions / 2)) * r
        for x = 0, (search_divisions - 1) do
            local offset_x = (x - (search_divisions / 2)) * r
            local area = {{offset_x, offset_y}, {offset_x + r, offset_y + r}}
            table.insert(search_offsets, area)
        end
    end

    --table.sort(search_offsets, function(a, b) return distance(a[1], {0,0}) < distance(b[1], {0,0}) end)

    for k, v in pairs (search_offsets) do
        local i = (((k * 87)) % #search_offsets) + 1
        search_offsets[k], search_offsets[i] = search_offsets[i], search_offsets[k]
    end
end
setup_search_offsets()

local get_free_companion_for_construction = function(player_data, exclude)
    -- FIX (far queued tasks stall between chunks): this used to require
    -- `not companion.active` to consider a companion free for the next job.
    -- A companion only ever goes inactive by getting back within follow_range
    -- of the player (see can_go_inactive()), so once current_job_from_queue
    -- jobs stopped being abandoned for being far from the player, this would
    -- have forced the drone to fly all the way back to the player between
    -- every single chunk of a big far-off task before it could be handed the
    -- next one, defeating the point. What actually matters is whether the
    -- companion is currently doing anything (fighting, flying to a job, or
    -- has robots out) -- is_busy_for_construction already tracks exactly
    -- that, independent of distance to the player.
    for unit_number, bool in pairs (player_data.companions) do
        local companion = get_companion(unit_number)
        -- also skip a companion that's full and heading home to unload
        -- (is_getting_full): otherwise it'd get handed a fresh chunk the
        -- instant its robots come back in, before it ever actually drops off
        -- its cargo, undoing the point of the full-inventory return.
        --
        -- FIX (companions bounced across distant zones within one stride
        -- burst): is_busy_for_construction only gets refreshed once per
        -- tick, by Companion:update() (which runs before check_job_search
        -- in on_tick). process_job_zones() calls this function up to
        -- storage.queue_stride (default 8) times per tick, and a companion
        -- whose pick this same burst lands already inside its
        -- construction_radius (no movement needed, so moving_to_destination
        -- stays nil) with no robot spawned yet (self.robots only fills in
        -- once the engine's own dispatch catches up, not synchronously)
        -- would still read as "free" here on the very next iteration of the
        -- SAME burst -- handing it a second, often completely unrelated
        -- assignment (including a tier-3 "help elsewhere" jump to a distant
        -- zone) before its first pick this tick ever had a chance to
        -- matter. Confirmed live via RCON instrumentation: ~40% of picks in
        -- one multi-companion test run were same-tick repicks of a
        -- companion still showing moving=nil/robots=0 from its first pick
        -- that same burst, and the resulting huge (50-130+ tile) same-tick
        -- reassignment jumps matched exactly the "flying side to side"
        -- symptom. `exclude` is the set of unit_numbers already handed a
        -- job earlier in this same stride burst (see check_job_search()) --
        -- skip them so each companion gets at most one assignment per burst.
        if companion and companion.can_construct and not companion.is_busy_for_construction
           and not companion.is_getting_full and not companion:move_to_robot_average()
           and not (exclude and exclude[unit_number]) then
            return companion
        end
    end
end

function Companion:escape_danger(threat_pos)
    if self:distance(self.player.physical_position) > abandon_job_distance then
        self.current_job_target = nil
        self.current_job_from_queue = nil
        self:claim_entity(nil)
        self.moving_to_destination = nil
        self.entity.autopilot_destination = nil
        self:clear_robots()
        self:return_to_player()
        return
    end

    if not threat_pos or not threat_pos.x then
        self.current_job_target = nil
        self.current_job_from_queue = nil
        self:claim_entity(nil)
        self.moving_to_destination = nil
        self.entity.autopilot_destination = nil
        self:return_to_player()
        return
    end

    local self_pos = self.entity.position
    local dx = self_pos.x - threat_pos.x
    local dy = self_pos.y - threat_pos.y
    local d  = math.sqrt(dx*dx + dy*dy)
    if d < 0.001 then d = 0.001 end

    local retreat = 8
    local dest = { x = self_pos.x + (dx/d) * retreat, y = self_pos.y + (dy/d) * retreat }

    self.current_job_target = nil
    self.current_job_from_queue = nil
    self:claim_entity(nil)
    self.moving_to_destination = true
    self.entity.follow_target = nil
    self.entity.autopilot_destination = dest

    self:set_active()
end


-- FIX (retreat ping-ponging between multiple fires): originally retreated
-- from whichever single fire entity happened to be nearest. In a spreading
-- forest fire or a dense multi-tree burn, that let the companion bounce
-- back and forth -- step away from fire A lands it closer to fire B, next
-- check steps away from B back toward A -- reading as "stuck looping
-- pathfinding back and forth even with a wide gap available." Averaging
-- the position of every fire found in range gives one stable retreat
-- direction pointing away from the hazard as a whole instead.
function Companion:find_fire_hazard_centroid(radius)
    local pos = self.entity.position
    local area =
    {
        {pos.x - radius, pos.y - radius},
        {pos.x + radius, pos.y + radius},
    }
    local fires = self.entity.surface.find_entities_filtered{area = area, type = "fire"}
    if not fires[1] then return nil end

    local sum_x, sum_y, count = 0, 0, 0
    for _, fire in pairs(fires) do
        if fire.valid then
            sum_x = sum_x + fire.position.x
            sum_y = sum_y + fire.position.y
            count = count + 1
        end
    end
    if count == 0 then return nil end
    return { x = sum_x / count, y = sum_y / count }
end

-- Shared by every "hop directly away from this point" behavior (ground
-- hazard dodge, kiting retreat, danger escape) so the away-vector math and
-- the standing-on-top-of-it degenerate case only live in one place. Doesn't
-- touch current_job_target/robots/claims -- callers that need to abandon a
-- job do that themselves before/after calling this.
function Companion:step_away_from(position, step)
    local self_position = self.entity.position
    local dx = self_position.x - (position.x or position[1])
    local dy = self_position.y - (position.y or position[2])
    local d = math.sqrt(dx * dx + dy * dy)
    local nx, ny
    if d < 0.001 then
        -- Degenerate case: standing exactly on the point. Pick an arbitrary
        -- retreat direction rather than dividing by ~0.
        nx, ny = 1, 0
    else
        nx, ny = dx / d, dy / d
    end
    local dest = { x = self_position.x + nx * step, y = self_position.y + ny * step }

    self.moving_to_destination = true
    self.entity.follow_target = nil
    self.entity.autopilot_destination = dest
    self:set_active()
end

-- Steps the companion directly away from the combined center of any
-- lingering ground fire (acid spit puddle or otherwise) within
-- hazard_scan_radius, if any. Doesn't touch current_job_target/robots/
-- claims -- this is a transient nudge, not an abandonment, so the job
-- resumes on its own once the hazard is behind it. Returns true if it
-- found and dodged a hazard this tick.
--
-- FIX (companion permanently stuck dodging, never reaches the player/job):
-- if fire keeps being found on every check -- a wide/spreading fire, or one
-- sitting directly between the companion and wherever it actually needs to
-- go -- this used to retreat forever with no other outcome possible.
-- hazard_dodge_streak counts consecutive dodges; once it crosses
-- hazard_dodge_streak_limit, dodging is suppressed for
-- hazard_dodge_suppress_ticks so the companion's real movement goal
-- (defend_player_until_tick / current_job_target, both checked right after
-- this in Companion:update()) gets a real chance to make progress instead
-- of being blocked by this check every single tick.
function Companion:dodge_ground_hazard()
    if self._hazard_dodge_suppress_until and game.tick < self._hazard_dodge_suppress_until then
        return false
    end

    local centroid = self:find_fire_hazard_centroid(hazard_scan_radius)
    if not centroid then
        self._hazard_dodge_streak = 0
        return false
    end

    self._hazard_dodge_streak = (self._hazard_dodge_streak or 0) + 1
    if self._hazard_dodge_streak > hazard_dodge_streak_limit then
        self._hazard_dodge_streak = 0
        self._hazard_dodge_suppress_until = game.tick + hazard_dodge_suppress_ticks
        return false
    end

    self:step_away_from(centroid, hazard_retreat_step)
    return true
end

-- Fallback for on_entity_damaged's fire/acid branch when there's no
-- lingering fire entity to dodge AND event.cause came back nil (observed
-- live: a direct spitter/worm hit landing on a companion over water, where
-- the game's own tile_collision_mask stops the splash fire from spawning in
-- the first place -- the area-effect damage delivery apparently doesn't
-- always populate `cause` the way a direct attack would). Finds the nearest
-- enemy-force entity instead so there's still something to retreat from.
function Companion:find_nearest_enemy_position(radius)
    local pos = self.entity.position
    local area =
    {
        {pos.x - radius, pos.y - radius},
        {pos.x + radius, pos.y + radius},
    }
    local enemies = self.entity.surface.find_entities_filtered{area = area, force = "enemy"}
    if not enemies[1] then return nil end

    local nearest, nearest_d
    for _, enemy in pairs(enemies) do
        if enemy.valid then
            local dx = enemy.position.x - pos.x
            local dy = enemy.position.y - pos.y
            local d = dx * dx + dy * dy
            if not nearest_d or d < nearest_d then
                nearest, nearest_d = enemy, d
            end
        end
    end
    return nearest and nearest.position or nil
end

--------------------------- Core Logic ---------------------------

function Companion:update()
    if self.flagged_for_equipment_changed then
        self:check_equipment()
    end
    
    do
        local pos = self.entity.position
        if self.moving_to_destination then
            local lp = self._last_auto_pos or pos
            if (math.abs(pos.x - lp.x) + math.abs(pos.y - lp.y)) < 0.05 then
                self._stalled_ticks = (self._stalled_ticks or 0) + 1
            else
                self._stalled_ticks = 0
            end
            self._last_auto_pos = pos
            -- FIX (infinite stall/redirect loop): clearing only
            -- moving_to_destination here used to let return_to_player()'s
            -- job-zone redirect branch immediately re-issue
            -- set_job_destination() at the exact same current_job_target
            -- the very next tick (it doesn't know the point turned out to
            -- be unreachable), which would just get stuck again -- stall,
            -- clear, redirect, stall, forever, with the companion barely
            -- moving and is_busy_for_construction flickering true/nil every
            -- ~120 ticks (visible via the debug hotkey's "is_busy" flipping
            -- while "pos" stays nearly frozen). A target that couldn't be
            -- reached by direct autopilot for 120 straight ticks is treated
            -- as abandoned, not just paused, so the next search picks
            -- something else instead of retrying the same stuck point.
            if (self._stalled_ticks or 0) > 120 then
                self.moving_to_destination = nil
                self.entity.autopilot_destination = nil
                self.current_job_target = nil
                self.current_job_from_queue = nil
                self:claim_entity(nil)
                self._stalled_ticks = 0
            end
        else
            self._stalled_ticks = 0
            self._last_auto_pos = pos
        end
    end

    local was_busy = self.is_busy_for_construction
    local was_in_combat = self.is_in_combat

    self:update_state_flags()

    -- Ground hazard dodge takes priority over everything else this tick --
    -- standing in acid/fire is actively lethal, and the companion flies
    -- (see hazard_scan_radius comment above) so nothing physically stops it
    -- from just sitting in a hazard tile without this check. Doesn't clear
    -- current_job_target/robots, so whatever it was doing resumes on its
    -- own once it's clear.
    if self:dodge_ground_hazard() then
        return
    end

    -- Preserve player life: while the player has taken a hit within the
    -- last defend_player_duration ticks, keep beelining for them instead of
    -- letting normal job logic below re-claim the tick and resume whatever
    -- was interrupted. See the on_entity_damaged FIX comment for why this
    -- has to be a persisted deadline checked every update, not a one-shot
    -- call from the damage event alone -- without it, the companion visibly
    -- turned back to its old job mid-flight while the player was still
    -- under fire.
    if self.defend_player_until_tick and game.tick < self.defend_player_until_tick then
        self:force_return_to_player()
        return
    end

    -- FIX (companion reassigned near the base instead of resuming the
    -- frontier): once a companion flies home to unload, its own position is
    -- the base/player, not wherever the rest of the task actually is. Any
    -- reassignment that measures "nearest" from the companion's CURRENT
    -- position (process_job_zones's nearest-chunk pick,
    -- search_for_nearby_work()'s search-area origin) would then naturally
    -- send it to whatever leftover work is nearest the base -- which can
    -- read as the companion "flying backward" away from where its teammates
    -- are still working the actual frontier, purely because that's where it
    -- physically stands right after unloading. Remember where it was
    -- working right before the recall (only the first time it goes full,
    -- not overwritten on every full tick), so those distance calculations
    -- can measure from there instead. Cleared the moment a fresh job is
    -- actually claimed (see Companion:claim_entity()), so this doesn't bias
    -- anything once the companion is genuinely back at work.
    if self.is_getting_full and not self.pre_recall_position then
        self.pre_recall_position = self.entity.position
    end

    -- FIX (drone freezes full mid-task): entities like trees/stumps don't
    -- need a has_or_can_take() item check to be picked, so nothing below
    -- ever stopped the companion from sending robots after more and more
    -- work once its cargo was already completely full -- it would just keep
    -- clear-cutting indefinitely with nowhere to put the loot instead of
    -- ever pausing to unload. The moment storage starts filling up, stop
    -- taking on new work and recall any robots already out, then head home
    -- to unload. current_job_target/current_job_from_queue are left alone
    -- so return_to_player() sends it straight back to the same task once
    -- it's emptied out (see the current_job_target branch in return_to_player()).
    if self.is_getting_full then
        self.moving_to_destination = nil
        self:clear_robots()
        self:force_return_to_player()
        return
    end

    -- Jobs picked up from an explicit player-issued task (a deconstruction
    -- order or blueprint the player queued up) are exempt from the
    -- follow-the-player leash below: those tasks are meant to be handed off
    -- and worked through on their own, not abandoned the moment the player
    -- wanders off to do something else. Opportunistic/ad-hoc jobs found
    -- incidentally nearby still respect the leash, since those were never
    -- something the player explicitly asked the companion to travel for.
    if self.current_job_target and not self.current_job_from_queue then
    -- if the player is too far from the job, ignore it and follow player
        local p = self.player.physical_position
        local t = self.current_job_target
        local tx = t[1] or t.x
        local ty = t[2] or t.y
        local dx = p.x - tx
        local dy = p.y - ty
        local d = (dx * dx + dy * dy) ^ 0.5
        if d > abandon_job_distance then
            self.moving_to_destination = nil
            self.current_job_target = nil
            self:claim_entity(nil)
            self.entity.autopilot_destination = nil
            self:clear_robots()
            self:return_to_player()
            return
        end
    end
    
    if self:player_wants_construction()
    and self.can_construct
    and next(self.robots)
    and not self.moving_to_destination
    then -- ensures we complete all jobs in range before moving on to the next location
        -- see Companion:get_local_search_area() -- constrains this to the
        -- companion's own zone chunk while it still has one, instead of a
        -- blanket max_distance radius that let this per-tick continuation
        -- (which fires far more often than a fresh zone pick) wander
        -- anywhere nearby regardless of zone ownership.
        local area = self:get_local_search_area()
        local hold = self.moving_to_destination
        self.moving_to_destination = true
        -- propagate the current job's origin rather than resetting it, for
        -- the same reason as in search_for_nearby_work() above.
        self:try_to_find_work(area, self.current_job_from_queue)
        self.moving_to_destination = hold
    end
    
    -- FIX (current_job_target wiped out after a fight, companion stuck
    -- idling near the player instead of resuming): is_busy_for_construction
    -- is is_in_combat OR move_to_robot_average() OR moving_to_destination --
    -- so "was_busy and not is_busy_for_construction" doesn't only mean
    -- "construction just finished," it also fires the instant combat ends
    -- while a job was still interrupted mid-flight. search_for_nearby_work()
    -- assumes it only ever runs right after a genuinely finished job and
    -- clears current_job_target if nothing new turns up nearby -- which,
    -- right after a fight (companion now far from the actual job site, mid
    -- chase or defending the player), is exactly what happened: the real
    -- job got silently discarded, leaving nothing for the later idle/
    -- return_to_player() path to resume. Only treat this as "construction
    -- finished" when combat wasn't the reason the busy flag just dropped.
    if was_busy and not self.is_busy_for_construction and not was_in_combat then
        -- So we were building, and now we are finished, lets try to find some work nearby
        self:search_for_nearby_work()
    end

    if was_in_combat and not self.is_in_combat then
        -- Same as above
        --
        -- FIX (job doesn't resume automatically after a fight -- needed a
        -- manual nudge like the player moving): moving_to_destination can
        -- be left stale true from the last kite/attack-cycle destination
        -- (set_attack_destination keeps re-issuing a new destination every
        -- combat cycle, so on_spider_command_completed -- the event that
        -- would normally clear this -- doesn't reliably fire while a fight
        -- is still ongoing). return_to_player()'s job-resume branch below
        -- only re-issues set_job_destination() when moving_to_destination
        -- is already false, so a stale true here silently blocked automatic
        -- resumption until something else (unrelated to this companion)
        -- happened to clear it. Clear it explicitly the instant combat
        -- ends instead of waiting on that event.
        self.moving_to_destination = nil
        self:search_for_nearby_targets()
    end

    -- FIX (permanent freeze after finishing a big task): a previous version
    -- of this fix gated the call below on "does this player's task queue
    -- still have pending chunks", to avoid flying home while queued work
    -- remained. That introduced a real deadlock risk: if the queue table
    -- ever lingers non-nil (e.g. chunks still awaiting their turn to be
    -- drained by process_job_zones) after all the *real* work in
    -- them is actually done, this condition would never fire again and the
    -- companion would sit frozen forever with nothing left to trigger a
    -- move -- exactly what "toggle construction off/on" was papering over,
    -- since that toggle force-clears the queue (clear_job_zones).
    -- The queue doesn't need this gate to protect unfinished work: a
    -- companion that's merely idle (not busy, not full) still satisfies
    -- get_free_companion_for_construction while it's on its way back to the
    -- player (follow_target/autopilot movement here doesn't set
    -- moving_to_destination), so process_job_zones can -- and does
    -- -- reassign it to the next chunk mid-flight before it ever arrives.
    -- Always calling return_to_player() when idle is therefore both safe
    -- (it can get redirected immediately if there's still real work) and
    -- necessary (it guarantees the companion eventually goes properly idle
    -- once there truly is nothing left). is_getting_full is already handled
    -- by the early return above.
    if self.is_on_low_health or not self:is_busy() then
        self.moving_to_destination = nil
        self:return_to_player()
    end
end

function Companion:try_to_find_work(search_area, from_queue)
    local force   = self.entity.force
    local surface = self.entity.surface

    local current_items = self:get_inventory().get_contents()
    local can_take_from_player = self:distance(self.player.physical_position) <= follow_range
        and self.entity.surface == self.player.physical_surface

    local function has_or_can_take(item)
        if self:get_inventory().get_item_count{
            name    = item.name,
            quality = (item.quality or "normal")
        } >= (item.count or 1) then
            return true
        end
        if not can_take_from_player then return false end
        return self:find_and_take_from_player{
            name    = item.name,
            count   = (item.count or 1),
            quality = (item.quality or "normal")
        }
    end

    local attempted_ghost_names   = {}
    local attempted_upgrade_names = {}
    local attempted_proxy_items   = {}
    local repair_attempted        = false
    local deconstruction_attempted = false
    local max_item_type_count     = 10

    local function pick(pos, entity)
        if not self.moving_to_destination then
            -- tags whether this job came from an explicit player-issued task
            -- (deconstruction/blueprint order queue) as opposed to opportunistic
            -- work found incidentally nearby, so Companion:update() can tell
            -- the two apart when deciding whether the player-distance leash
            -- should apply (see current_job_from_queue).
            self.current_job_from_queue = from_queue
            self:set_job_destination(pos)
            self:claim_entity(entity)
            return true
        end
    end

    local function bots_claimed(entity, kind)
        -- also treat an entity another companion already has as its live
        -- current_job_target as "claimed", so two companions don't race for
        -- the same nearest pick before either has real robots dispatched --
        -- see Companion:is_claimed_by_other().
        if self:is_claimed_by_other(entity) then
            return true
        end

        local claimed =
            (kind == "construct"   and entity.is_registered_for_construction and entity.is_registered_for_construction())
         or (kind == "upgrade"     and entity.is_registered_for_upgrade      and entity.is_registered_for_upgrade())
         or (kind == "repair"      and entity.is_registered_for_repair       and entity.is_registered_for_repair())
         or (kind == "decon"       and entity.is_registered_for_deconstruction and entity.is_registered_for_deconstruction(force))
         or false

        if not claimed then
            return false
        end

        local net = surface.find_logistic_network_by_position(entity.position, force)
        if not net then
            return false
        end

        if (net.available_construction_robots or 0) <= 0 then
            return false
        end

        return true
    end

    -- FIX ("ADHD" chunk-hopping, part 2): find_entities_filtered() makes no
    -- promise about result order -- it's whatever order the game's spatial
    -- index happens to return, not proximity. Picking the first entity in
    -- that list meant the companion could jump to a far corner of its own
    -- search_area while genuinely closer, equally-valid work sat right next
    -- to it (this is on top of, and independent from, the queue-level
    -- nearest-chunk fix in process_job_zones -- that fix only
    -- covers which 32x32 chunk gets assigned; this one covers which entity
    -- gets picked once inside a chunk/local search). Sort candidates by
    -- distance to the companion first so the nearest valid one wins.
    --
    -- FIX (FPS drop from the above): a naive table.sort() with a comparator
    -- that reads `.valid`/`.position` on every comparison touches those
    -- (relatively expensive, cross the Lua/engine boundary) properties
    -- O(n log n) times instead of O(n) -- this function runs every tick a
    -- companion has robots out (see the "finish everything in range"
    -- continuation in Companion:update()) over a search area up to 200x200
    -- tiles across, so that added up fast even with only a few dozen
    -- entities actually near the companion, since everything in that whole
    -- area gets touched. Read position/validity exactly once per entity
    -- into a plain-number distance table first, then sort indices by those
    -- cached numbers -- comparisons become cheap numeric compares instead of
    -- repeated engine calls.
    local self_pos = self.entity.position
    local function sort_by_distance(entities)
        local n = #entities
        if n <= 1 then return entities end
        local dist = {}
        for i = 1, n do
            local e = entities[i]
            if e.valid then
                local ep = e.position
                local dx, dy = ep.x - self_pos.x, ep.y - self_pos.y
                dist[i] = dx * dx + dy * dy
            else
                dist[i] = math.huge
            end
        end
        local order = {}
        for i = 1, n do order[i] = i end
        table.sort(order, function(a, b) return dist[a] < dist[b] end)
        local sorted = {}
        for i = 1, n do sorted[i] = entities[order[i]] end
        return sorted
    end

    -- FIX (small unclean zigzag within a single zone chunk): sort_by_distance()
    -- above is greedy nearest-to-companion, which is the right call for a
    -- wide opportunistic search (nearest broken thing, nearest ghost
    -- anywhere nearby) but produces a slightly backtrack-y pick order in a
    -- dense, small area -- specifically a companion's own zone chunk (see
    -- Companion:get_local_search_area()) -- since "nearest" keeps shifting
    -- as the companion's own position drifts between picks, letting it
    -- leave a stray entity behind and double back for it later (confirmed
    -- live: zones themselves worked, but local pick order inside one still
    -- looked messy). For a chunk-scale search, sort in fixed row bands
    -- anchored to the search area's own bounds (not the companion's
    -- position, so the order stays stable call to call) with alternating
    -- left-right/right-left direction per band -- the same serpentine idea
    -- dissect_and_queue_area() already uses to order zones/chunks, just one
    -- level finer. Falls back to nearest-first for anything wider than
    -- chunk-scale (the opportunistic/"help elsewhere" searches), decided
    -- from the search area's own size so no extra flag needs threading
    -- through every call site.
    local grid_row_height = 6
    local function sort_by_grid(entities, area)
        local n = #entities
        if n <= 1 then return entities end
        local ymin = area[1][2]
        local row, xcoord = {}, {}
        for i = 1, n do
            local e = entities[i]
            if e.valid then
                local ep = e.position
                row[i] = math.floor((ep.y - ymin) / grid_row_height)
                xcoord[i] = ep.x
            else
                row[i] = math.huge
                xcoord[i] = math.huge
            end
        end
        local order = {}
        for i = 1, n do order[i] = i end
        table.sort(order, function(a, b)
            if row[a] ~= row[b] then return row[a] < row[b] end
            if row[a] % 2 == 0 then return xcoord[a] < xcoord[b] end
            return xcoord[a] > xcoord[b]
        end)
        local sorted = {}
        for i = 1, n do sorted[i] = entities[order[i]] end
        return sorted
    end

    local search_width = search_area[2][1] - search_area[1][1]
    local sort_candidates = sort_by_distance
    if search_width <= 48 then
        sort_candidates = function(entities) return sort_by_grid(entities, search_area) end
    end

    local decon = sort_candidates(surface.find_entities_filtered{
        area                = search_area,
        force               = force,
        to_be_deconstructed = true
    })
    for _, entity in pairs(decon) do
        if not entity.valid then break end
        if (entity.type ~= "vehicle") or (entity.speed and entity.speed < 0.4) then
            if not bots_claimed(entity, "decon") then
                deconstruction_attempted = true
                if pick(entity.position, entity) then return true end
            end
        end
    end

    local ghosts = sort_candidates(surface.find_entities_filtered{
        area  = search_area,
        force = force,
        type  = {"entity-ghost", "tile-ghost"}
    })
    for _, entity in pairs(ghosts) do
        if (max_item_type_count or 0) <= 0 then return false end
        if not entity.valid then break end

        if bots_claimed(entity, "construct") then goto continue_ghost end

        local entity_type = entity.type
        local quality     = (entity.quality and entity.quality.name) or "normal"

        if ghost_types[entity_type] then
            local ghost_name = entity.ghost_name
            if not attempted_ghost_names[ghost_name] then
                local proto = entity.ghost_prototype
                local items = proto and proto.items_to_place_this
                local item  = items and items[1]
                if item then
                    item.quality = quality
                    if has_or_can_take(item) then
                        if pick(entity.position, entity) then return true end
                        max_item_type_count = max_item_type_count - 1
                        attempted_ghost_names[ghost_name] = 1
                    else
                        attempted_ghost_names[ghost_name] = 0
                    end
                else
                    attempted_ghost_names[ghost_name] = 0
                end
            end
            if item_request_types[entity_type] and attempted_ghost_names[ghost_name] == 1 then
                local items = entity.item_requests
                for _, item in pairs(items) do
                    if not attempted_proxy_items[item.name] then
                        attempted_proxy_items[item.name] = true
                        if has_or_can_take(item) then
                            max_item_type_count = max_item_type_count - 1
                        end
                    end
                end
            end
        end
        ::continue_ghost::
    end

    local upgrades = sort_candidates(surface.find_entities_filtered{
        area           = search_area,
        force          = force,
        to_be_upgraded = true
    })
    for _, entity in pairs(upgrades) do
        if not entity.valid then break end
        if bots_claimed(entity, "upgrade") then goto continue_upgrade end

        local quality        = (entity.quality and entity.quality.name) or "normal"
        local upgrade_target = entity.get_upgrade_target()
        if upgrade_target and not attempted_upgrade_names[upgrade_target.name] then
            if upgrade_target.name == entity.name then
                if pick(entity.position, entity) then return true end
            else
                local items = upgrade_target.items_to_place_this
                local item  = items and items[1]
                if item then
                    item.quality = quality
                    if has_or_can_take(item) then
                        if pick(entity.position, entity) then return true end
                        max_item_type_count = max_item_type_count - 1
                    end
                end
            end
            attempted_upgrade_names[upgrade_target.name] = true
        end
        ::continue_upgrade::
    end

    if not repair_attempted and not self.moving_to_destination then
        local candidates = surface.find_entities_filtered{
            area  = search_area,
            force = force,
            limit = 200
        }
        for _, entity in pairs(candidates) do
            local needs_repair = (entity.get_health_ratio and ((entity.get_health_ratio() or 1) < 1)) or false
            if needs_repair and not bots_claimed(entity, "repair") then
                for name in pairs(get_repair_tools()) do
                    if has_or_can_take({name = name, count = 1}) then
                        if pick(entity.position, entity) then return true end
                        break
                    end
                end
                break
            end
        end
    end

    local proxies = surface.find_entities_filtered{
        area  = search_area,
        force = force,
        type  = "item-request-proxy"
    }
    for _, entity in pairs(proxies) do
        if not entity.valid then break end
        if bots_claimed(entity, "construct") then goto continue_proxy end
        local items = entity.item_requests
        for _, item in pairs(items) do
            if not attempted_proxy_items[item.name] then
                attempted_proxy_items[item.name] = true
                if has_or_can_take(item) then
                    if pick(entity.position, entity) then return true end
                    max_item_type_count = max_item_type_count - 1
                end
            end
        end
        ::continue_proxy::
    end

    local attempted_cliff_names = {}
    local neutral_entities = surface.find_entities_filtered{
        area                = search_area,
        force               = "neutral",
        to_be_deconstructed = true
    }
    for _, entity in pairs(neutral_entities) do
        if not entity.valid then break end
        if entity.type == "cliff" then
            local claimed = bots_claimed(entity, "decon")
            if not attempted_cliff_names[entity.name] and not claimed then
                local item_name = entity.prototype.cliff_explosive_prototype
                if has_or_can_take({name = item_name, count = 1}) then
                    if pick(entity.position, entity) then return true end
                    max_item_type_count = max_item_type_count - 1
                end
                attempted_cliff_names[entity.name] = true
            end
        elseif not deconstruction_attempted and not bots_claimed(entity, "decon") then
            deconstruction_attempted = true
            if pick(entity.position, entity) then return true end
        end
    end

    return false
end

local perform_job_search = function(player, player_data)

    if not player.is_shortcut_toggled("companion-construction-toggle") then return end
    local free_companion = get_free_companion_for_construction(player_data)
    if not free_companion then return end

    if not player.controller_type or player.controller_type    ~= defines.controllers.character then return end

    player_data.last_job_search_offset = player_data.last_job_search_offset + 1
    local area = search_offsets[player_data.last_job_search_offset]
    if not area then
        player_data.last_job_search_offset = 0
        return
    end

    local position = player.physical_position
    local search_area = {{area[1][1] + position.x, area[1][2] + position.y}, {area[2][1] + position.x, area[2][2] + position.y}}

    free_companion:try_to_find_work(search_area)
end

local perform_attack_search = function(player, player_data)

    if not player.is_shortcut_toggled("companion-attack-toggle") then return end

    if not player.controller_type or player.controller_type    ~= defines.controllers.character then return end

    local free_companion
    for unit_number, bool in pairs (player_data.companions) do
        local companion = get_companion(unit_number)
        if companion and not companion.active and companion.can_attack then
            free_companion = companion
            break
        end
    end
    if not free_companion then return end

    player_data.last_attack_search_offset = player_data.last_attack_search_offset + 1
    local area = search_offsets[player_data.last_attack_search_offset]
    if not area then
        player_data.last_attack_search_offset = 0
        return
    end

    local position = player.physical_position
    local search_area = {{area[1][1] + position.x, area[1][2] + position.y}, {area[2][1] + position.x, area[2][2] + position.y}}

    free_companion:try_to_find_targets(search_area)
end

local function job_zone_chunk_key(a)
    return a[1][1] .. ":" .. a[1][2]
end

local function job_zone_area_still_has_work(surface, force, area)
    return next(surface.find_entities_filtered{area = area, force = force, to_be_deconstructed = true}) ~= nil
        or next(surface.find_entities_filtered{area = area, force = force, type = {"entity-ghost", "tile-ghost"}}) ~= nil
        or next(surface.find_entities_filtered{area = area, force = force, to_be_upgraded = true}) ~= nil
end

-- FIX (companions crisscrossing/re-treading each other's routes instead of
-- each sweeping its own patch): the old flat nearest-chunk-to-whoever queue
-- (see git history / changelog for the old process_specific_job_queue) let
-- every free companion independently grab whatever queued chunk was nearest to
-- IT, with no persistent notion of "territory" -- companions could and did
-- weave in and out of each other's areas over the course of a big task,
-- even with the chunk-claim bias in place (that only stops two companions
-- picking the literal same chunk at the same moment, not the general
-- crisscrossing pattern). Companions now each own a persistent zone (a
-- contiguous vertical strip, see dissect_and_queue_area()) and work it in
-- a fixed serpentine order -- not nearest-first -- so a single companion's
-- path reads as one clean sweep. Once a companion's own zone is exhausted,
-- it falls back to helping whichever remaining zone is furthest left (not
-- nearest-to-companion -- see tier 3 below), so the task as a whole reads
-- as one left-to-right sweep instead of finishing unevenly by whichever
-- area happened to be denser/closer, and nobody sits idle just because its
-- own strip happened to be smaller/finished first.
local process_job_zones = function(player_index, player_data)

    local player = game.players[player_index]
    if not player.is_shortcut_toggled("companion-construction-toggle") then
        script_data.job_zones[player_index] = nil
        script_data.claimed_chunks[player_index] = nil
        return
    end

    local zone_state = script_data.job_zones[player_index]
    if not zone_state then return end

    for i = #zone_state.zones, 1, -1 do
        if #zone_state.zones[i].chunks == 0 then
            table.remove(zone_state.zones, i)
        end
    end
    if #zone_state.zones == 0 then
        script_data.job_zones[player_index] = nil
        script_data.claimed_chunks[player_index] = nil
        return
    end

    -- FIX (companions bounced across distant zones within one stride
    -- burst -- see the long comment on get_free_companion_for_construction()):
    -- pass the set of companions already assigned earlier in this same
    -- check_job_search() stride burst so a companion whose
    -- is_busy_for_construction/robots state hasn't caught up yet within the
    -- same tick doesn't get handed a second, unrelated assignment before
    -- its first one this tick ever had a chance to matter.
    local free_companion = get_free_companion_for_construction(player_data, script_data.stride_assigned)
    if not free_companion then
        return
    end
    if script_data.stride_assigned then
        script_data.stride_assigned[free_companion.unit_number] = true
    end

    -- 1) work this companion's own zone, front chunk first (fixed
    -- serpentine order, not a nearest search) -- this is what keeps its
    -- path a clean sweep instead of jumping around.
    local zone, area, area_index
    for _, z in ipairs(zone_state.zones) do
        if z.owner == free_companion.unit_number and #z.chunks > 0 then
            zone = z
            area = z.chunks[1]
            area_index = 1
            break
        end
    end

    -- 2) own zone empty or never had one, but already helping a specific
    -- other zone: keep working THAT one instead of re-picking "nearest
    -- across everything" from scratch. FIX (companions oscillating side to
    -- side once mop-up help starts): re-running the nearest-scan below
    -- after every single chunk let a companion's own position drift just
    -- enough between picks that two roughly-equidistant leftover zones
    -- could alternate which one looked "nearest" pick to pick -- visible as
    -- a companion ping-ponging between two distant spots instead of
    -- finishing one before moving to the other. Once tier 3 below adopts a
    -- zone to help, stick with it (like an owned zone) until it's actually
    -- empty.
    if not zone and free_companion.adopted_zone and #free_companion.adopted_zone.chunks > 0 then
        zone = free_companion.adopted_zone
        area = zone.chunks[1]
        area_index = 1
    end

    -- 3) no own zone, no zone currently being helped: adopt whichever
    -- zone with remaining work is furthest LEFT (zone.min_x, see
    -- partition_columns_into_zones()) rather than nearest-to-companion --
    -- see the FIX note on dissect_and_queue_area()'s vertical-strip zones
    -- above. This is what actually makes the "help elsewhere" phase read as
    -- one left-to-right sweep instead of finishing unevenly by whichever
    -- area happened to be denser/closer: nearest-to-companion could (and
    -- did, confirmed via screenshots) let a companion mop up a nearby,
    -- already-mostly-done area repeatedly while a distant unfinished one on
    -- the far side sat untouched. Still bias-away-from-claimed-chunks
    -- (checked on the zone's front chunk only, consistent with tier 2
    -- above always resuming from index 1) so two companions both
    -- "helping" still don't pile onto the exact same chunk. Remembers the
    -- chosen zone as adopted_zone (tier 2 above) so the next call sticks
    -- with it instead of re-scanning immediately.
    if not zone then
        local claims = script_data.claimed_chunks[player_index]
        if not claims then
            claims = {}
            script_data.claimed_chunks[player_index] = claims
        end

        local function chunk_claimed_by_other(key)
            local owner_uid = claims[key]
            if not owner_uid or owner_uid == free_companion.unit_number then return false end
            local owner = get_companion(owner_uid)
            if not owner or not owner.entity or not owner.entity.valid then
                claims[key] = nil
                return false
            end
            -- self-heals once the claiming companion stops actively working
            -- (finished, abandoned, or recalled) instead of needing an
            -- explicit release call at every job-abandonment site the way
            -- claim_entity() does -- a chunk claim only exists to bias
            -- picking, not to guard correctness, so a stale claim is
            -- harmless beyond one wasted comparison.
            return owner.is_busy_for_construction
        end

        local best_zone, best_min_x = nil, math.huge
        local fallback_zone, fallback_min_x = nil, math.huge
        for _, z in ipairs(zone_state.zones) do
            if z.min_x < fallback_min_x then
                fallback_min_x = z.min_x
                fallback_zone = z
            end
            if not chunk_claimed_by_other(job_zone_chunk_key(z.chunks[1])) and z.min_x < best_min_x then
                best_min_x = z.min_x
                best_zone = z
            end
        end
        zone = best_zone or fallback_zone
        if not zone then return end
        area_index = 1
        area = zone.chunks[1]
        free_companion.adopted_zone = zone
    end

    -- FIX (owner's own front chunk invisible to other companions' claim
    -- checks): tier 1 (own zone) used to never register a claim at all --
    -- since chunk_claimed_by_other() above only ever consults the claims
    -- table, that left an owner's actively-being-worked front chunk looking
    -- "unclaimed" to any other companion's tier 3 scan, which could then
    -- adopt and collide with it. Register the claim for whichever chunk was
    -- actually chosen here, once, regardless of which tier picked it, so
    -- every path is covered by the same mechanism.
    local claims = script_data.claimed_chunks[player_index]
    if not claims then
        claims = {}
        script_data.claimed_chunks[player_index] = claims
    end
    claims[job_zone_chunk_key(area)] = free_companion.unit_number

    -- FIX (task never finishes / stops after nearby area is done): measuring
    -- reach against storage.max_distance from the companion's CURRENT
    -- position (an older version of this check) breaks once the companion
    -- wanders back toward the player after finishing nearby work -- distant-
    -- but-still-valid chunks would fail forever. The leash is already
    -- enforced live against the player's current position elsewhere (the
    -- abandon_job_distance check in Companion:update()), so no extra
    -- distance check is needed here at all.
    free_companion:try_to_find_work(area, true)

    -- FIX ("islands" bug): try_to_find_work() only ever assigns a single job
    -- per call. A 32x32 chunk usually still has more entities left in it
    -- after just one pick, so only advance past this chunk (remove it from
    -- the zone/drop its claim) once it's actually fully drained -- otherwise
    -- leave it at the front to be picked again next time.
    local surface = free_companion.entity.surface
    local force   = free_companion.entity.force
    if not job_zone_area_still_has_work(surface, force, area) then
        table.remove(zone.chunks, area_index)
        local claims = script_data.claimed_chunks[player_index]
        if claims then claims[job_zone_chunk_key(area)] = nil end
    end
end

local check_job_search = function(event)
    if not next(script_data.player_data) then return end

    local job_zones = script_data.job_zones
    local players = game.players

    for player_index, player_data in pairs(script_data.player_data) do
        local player = players[player_index]
        if player.connected then
            local zone_state = job_zones[player_index]

            if zone_state then
                -- FIX (companions bounced across distant zones within one
                -- stride burst, visible in-game as "flying side to side" and
                -- as chunks getting abandoned partway through, needing a
                -- much later revisit): process_job_zones() calls
                -- get_free_companion_for_construction() up to
                -- storage.queue_stride (default 8) times per tick, but that
                -- function's "is this companion free" check
                -- (is_busy_for_construction) only gets refreshed once per
                -- tick, before check_job_search runs. A companion whose pick
                -- lands inside its already-in-range construction_radius (no
                -- movement needed) with no robot spawned yet still reads as
                -- "free" on the next iteration of the SAME burst, so it
                -- could get reassigned again -- including jumping to a
                -- distant tier-3 "help elsewhere" zone -- before its first
                -- pick this tick ever mattered. Confirmed live via RCON
                -- instrumentation: ~40% of picks in a multi-companion test
                -- were same-tick repicks, each showing the companion still
                -- at moving=nil/robots=0 from its earlier pick that same
                -- burst, with resulting 50-130+ tile same-tick jumps.
                -- stride_assigned tracks which companions already got an
                -- assignment this burst so each gets at most one.
                script_data.stride_assigned = {}
                for i = 1, (storage.queue_stride or 8) do
                    if not job_zones[player_index] then break end
                    process_job_zones(player_index, player_data)
                end
            else
                for i = 1, (storage.job_stride or 12) do
                    perform_job_search(player, player_data)
                end
            end
            for i = 1, (storage.attack_stride or 6) do
                perform_attack_search(player, player_data)
            end
        end
    end
end

local update_active_companions = function(event)
    local mod = event.tick % storage.companion_update_interval
    local list = script_data.active_companions[mod]
    if not list then return end
    for unit_number, bool in pairs (list) do
        local companion = get_companion(unit_number)
        if companion then
            companion:update()
        end
    end
end

local check_follow_update = function(event)
    if not next(script_data.player_data) then return end
    local players = game.players
    for player_index, player_data in pairs(script_data.player_data) do
        local player = players[player_index]
        if player.connected then
            adjust_follow_behavior(player)
        end
    end
end

local function check_and_restore_construction_bots()
    for unit_number, companion in pairs(script_data.companions) do
        if companion and companion.entity and companion.entity.valid then
            if companion:player_wants_construction() then
                local inventory = companion:get_inventory()
                if inventory and inventory[21] then
                    local stack = inventory[21]
                    if stack.valid_for_read then
                        if stack.name ~= "companion-construction-robot" or stack.count ~= 100 then
                            stack.set_stack({name="companion-construction-robot", count=100})
                        end
                    else
                        inventory[21].set_stack({name="companion-construction-robot", count=100})
                    end
                end
            end
        end
    end
end

local function check_inactive_idle_chatter(event)
    if not next(script_data.companions) then return end
    for unit_number, comp in pairs(script_data.companions) do
        if comp and comp.entity and comp.entity.valid and not comp.active then
            if not (comp.is_in_combat or comp.is_busy_for_construction) then
                local delay = settings.get_player_settings(comp.player)["companion-idle-chatter-delay"].value
                local minimum = math.max(1, math.floor(delay * 0.1))
                local maximum = math.ceil(delay)

                if not comp.next_idle_line_tick then
                    comp.next_idle_line_tick = event.tick + 60 * math.random(minimum, maximum)
                elseif event.tick >= comp.next_idle_line_tick then
                    comp:say_random("idle-line")
                    comp.next_idle_line_tick = event.tick + 60 * math.random(minimum, maximum)
                end
            else
                comp.next_idle_line_tick = nil
            end
        end
    end
end

-- FIX (crash on any save that had storage.companion written before the zone
-- system existed): script_data.job_zones/claimed_entities/claimed_chunks
-- used to only get their nil -> {} migration guard inside
-- script.on_configuration_changed(), but that event only fires when this
-- mod's OWN version number in info.json actually differs between the save
-- and what's currently installed -- redeploying the same dev version (as
-- this whole session did repeatedly, always staying on 1.2.1) onto an
-- existing save never re-triggers it. lib.on_load() re-binds script_data to
-- the old storage.companion table but can't apply this guard itself
-- (Factorio disallows writing to `storage` from on_load). Every direct
-- index of these three fields (get_local_search_area, check_job_search,
-- claim_entity, etc.) then throws "attempt to index ... (a nil value)" the
-- first time anything runs. on_tick fires every tick, can write storage,
-- and runs before every other per-tick companion function -- guarding here
-- guarantees these fields exist before anything downstream touches them,
-- regardless of whether on_configuration_changed ever ran this session.
local function ensure_job_search_tables()
    script_data.job_zones = script_data.job_zones or {}
    script_data.claimed_entities = script_data.claimed_entities or {}
    script_data.claimed_chunks = script_data.claimed_chunks or {}
end

local on_tick = function(event)
    ensure_job_search_tables()
    update_active_companions(event) -- must run every tick
	if event.tick % storage.companion_update_interval == 0 then 
    -- by default runs every 5 ticks, user configurable
        check_follow_update(event)
        check_and_restore_construction_bots()
		check_job_search(event)
        check_inactive_idle_chatter(event)
    end
end

--------------------------- Secondary Utilities ---------------------------

local on_spider_command_completed = function(event)
    local spider = event.vehicle
    local companion = get_companion(spider.unit_number)
    if not companion then return end
    companion:on_spider_command_completed()
end

function Companion:on_spider_command_completed()
    local t = self.current_job_target
    if t and not self.current_job_from_queue then
        local p = self.player.physical_position
        local tx = t[1] or t.x
        local ty = t[2] or t.y
        local dx = p.x - tx
        local dy = p.y - ty
        local d = (dx * dx + dy * dy) ^ 0.5
        if d > abandon_job_distance then
            self.moving_to_destination = nil
            self.current_job_target = nil
            self:claim_entity(nil)
            self.entity.autopilot_destination = nil
            self:clear_robots()
            self:return_to_player()
            return
        end
    end

    self.moving_to_destination = nil

    local distance = self:distance(self.player.physical_position)
    if not self.is_busy_for_construction and distance <= follow_range then
        self:try_to_shove_inventory()
    end

    if self.current_job_target and not next(self.robots)
       and self:player_wants_construction() and self.can_construct then
        self:set_job_destination(self.current_job_target)
        return
    end
end

-- Companion:attack() fires this many companion-projectile entities per
-- attack cycle, each dealing a flat 5 laser damage (see plasma_projectile
-- in data.lua) -- the equipped defense equipment's own attack_parameters
-- (cooldown, range) are real and vanilla-driven, but its damage_modifier
-- is never read anywhere, since the actual damage is delivered by this
-- custom script effect, not by the vanilla ammo damage system. This table
-- is what actually scales damage per tier instead. Chosen so 2 lasers of a
-- given tier kill that tier's matching worm turret (200/500/1500/3000 HP)
-- in about the same ~2.5s across all tiers.
local defense_tier_projectile_count =
{
    [1] = 4,
    [2] = 8,
    [3] = 18,
    [4] = 28,
}

-- Must match plasma_projectile's damage.amount in data.lua.
local companion_projectile_damage = 5

local function get_defense_projectile_count(companion, target_entity)
    local tier_count = defense_tier_projectile_count[get_best_defense_tier(companion)] or storage.attack_count

    -- Don't overkill: never fire more projectiles than it takes to finish
    -- off the target's current health, so a nearly-dead enemy doesn't eat
    -- a full mk4 salvo. A flat +2 projectile margin covers the gap between
    -- "health read right now" and "damage actually lands" -- projectiles
    -- travel (not instant), and in that window the target can regen
    -- (biters/spawners both have healing_per_tick) or eat a hit from
    -- another companion's already-in-flight volley we don't know about.
    -- Without the margin, a target can end up perpetually just barely
    -- alive instead of dying.
    if target_entity and target_entity.valid and target_entity.health then
        local needed = math.ceil(target_entity.health / companion_projectile_damage) + 2
        tier_count = math.min(tier_count, math.max(1, needed))
    end

    return tier_count
end

local companion_attack_trigger = function(event)

    local source_entity = event.source_entity
    if not (source_entity and source_entity.valid) then
        return
    end

    local target_entity = event.target_entity
    if not (target_entity and target_entity.valid) then
        return
    end

    local companion = get_companion(source_entity.unit_number)
    if companion then
        companion:attack(target_entity, get_defense_projectile_count(companion, target_entity))
    end
end

local companion_robot_spawned_trigger = function(event)
    local robot = event.target_entity or event.source_entity
    if not (robot and robot.valid) then return end
    if robot.type ~= "construction-robot" and robot.type ~= "logistic-robot" then return end

    local network = robot.logistic_network
    if not network or not network.cells or not network.cells[1] then return end
    local owner = network.cells[1].owner
    if not (owner and owner.valid and owner.name == "companion") then return end

    local companion = get_companion(owner.unit_number)
    if companion then
        companion:robot_spawned(robot)
    end
end

--[[effect_id :: string: The effect_id specified in the trigger effect.
surface_index :: uint: The surface the effect happened on.
source_position :: Position (optional)
source_entity :: LuaEntity (optional)
target_position :: Position (optional)
target_entity :: LuaEntity (optional)]]

local on_script_trigger_effect = function(event)
    local id = event.effect_id
    --game.print(id)
    if id == "companion-attack" then
        companion_attack_trigger(event)
        return
    end

    if id == "companion-robot-spawned" then
        companion_robot_spawned_trigger(event)
    end
end

local on_player_placed_equipment = function(event)

    local player = game.get_player(event.player_index)
    --if player.opened_gui_type ~= defines.gui_type.entity then return end


    local opened = player.opened
    if not (opened and opened.valid and opened.prototype.name == "companion") then return end

    local companion = get_companion(opened.unit_number)
    if not companion then return end

    companion:on_player_placed_equipment(event)

end

local on_player_removed_equipment = function(event)
    local player = game.get_player(event.player_index)
    if player.opened_gui_type ~= defines.gui_type.entity then return end

    local opened = player.opened
    if not (opened and opened.valid and opened.prototype.name == "companion") then return end

    local companion = get_companion(opened.unit_number)
    if not companion then return end

    companion:on_player_removed_equipment(event)

end

local on_entity_settings_pasted = function(event)

    local entity = event.destination
    if not (entity and entity.valid) then return end

    local companion = get_companion(entity.unit_number)
    if not companion then return end

    companion:set_active()

end

local on_player_changed_surface = function(event)
    local player_data = script_data.player_data[event.player_index]
    if not player_data then return end

    local player = game.get_player(event.player_index)
    if not player.character then
        --For the space exploration satellite viewer thing...
        --If there is no character, lets just not go with the player.
        return
    end
    local surface = player.physical_surface
    local position = player.physical_position

    for unit_number, bool in pairs (player_data.companions) do
        local companion = get_companion(unit_number)
        if companion then
            companion:teleport(position, surface)
        end
    end

end

local on_player_left_game = function(event)
    local player_data = script_data.player_data[event.player_index]
    if not player_data then return end

    local surface = get_secret_surface()
    local position = {x = 0, y = 0}

    for unit_number, bool in pairs (player_data.companions) do
        local companion = get_companion(unit_number)
        if companion then
            companion:teleport(position, surface)
        end
    end
end

function reschedule_companions(allow_prototype_access)
    script_data.active_companions = {}
    for k, companion in pairs(script_data.companions) do
        if companion.entity and companion.entity.valid then
            companion.moving_to_destination = nil
            if allow_prototype_access then
                companion:set_active()
            else
                companion.active = false
            end
        else
            script_data.companions[k] = nil
        end
    end
end

local on_player_joined_game = function(event)
    local player_data = script_data.player_data[event.player_index]
    if not player_data then return end

    local player = game.get_player(event.player_index)
    local surface = player.physical_surface
    local position = player.physical_position

    for unit_number, bool in pairs (player_data.companions) do
        local companion = get_companion(unit_number)
        if companion then
            companion:teleport({position.x + math.random(-20, 20), position.y + math.random(-20, 20)}, surface)
        end
    end
    reschedule_companions(true)
    adjust_follow_behavior(player)
end

local on_player_changed_force = function(event)
    local player_data = script_data.player_data[event.player_index]
    if not player_data then return end

    local player = game.get_player(event.player_index)
    local force = player.force
    for unit_number, bool in pairs (player_data.companions) do
        local companion = get_companion(unit_number)
        if companion then
            companion:change_force(force)
        end
    end
end

local on_player_driving_changed_state = function(event)
    local player = game.get_player(event.player_index)
    if not (player and player.valid) then return end
    if not player.vehicle then return end

    if player.vehicle.name == "companion" then
        player.driving = false
    end

    adjust_follow_behavior(player)

end

local rebukes =
-- picks one at random if you try to use a spidertron remote on the drone
{
    "You're not the boss of me",
    "Get lost",
    "Not me pal",
    "Maybe later, I mean never.",
    "Go bother someone else",
    "I do my own thing",
    "lol as if...",
    "What are you, nuts?",
    "I ain't goin' in there!",
    "lol. lmao, even",
    "Who do you think you are?",
    "Do I look like a friggin spider to you?",
    "What do I look like, a spidertron?",
    "That's really not necessary.",
    "Oh don't worry, I can take care of myself.",
    "You don't need to do that.",
    "Don't do that.",
    "No.",
    "Nope.",
    "Nuh uh.",
    "Not happening.",
    "In your dreams"
}

local on_player_used_spider_remote = function(event)
    local vehicle = event.vehicle
    if not (vehicle and vehicle.valid) then return end
    local companion = get_companion(vehicle.unit_number)
    if not companion then return end

    companion:say(rebukes[math.random(#rebukes)])
    companion.entity.follow_target = nil
    companion.entity.autopilot_destination = nil

end

local on_player_mined_entity = function(event)
    if event.entity and event.entity.valid and event.entity.name == "companion" then
        local player = game.get_player(event.player_index)
        player.remove_item{name = "companion-construction-robot", count = 1000}
    end
end

local recall_fighting_robots = function(player)
    local player_data = script_data.player_data[player.index]
    if not player_data then return end
    for unit_number, bool in pairs (player_data.companions) do
        local companion = get_companion(unit_number)
        if companion then
            if companion.is_in_combat then
                companion:return_to_player()
            end
        end
    end
end

local recall_constructing_robots = function(player)
    local player_data = script_data.player_data[player.index]
    if not player_data then return end
    for unit_number, bool in pairs (player_data.companions) do
        local companion = get_companion(unit_number)
        if companion then
            if next(companion.robots) then
                companion:clear_robots()
                companion:return_to_player()
            end
			if companion.moving_to_destination and not companion.is_in_combat then
                companion.moving_to_destination = nil
                companion:return_to_player()
            end
        end
    end
end

local clear_job_zones = function(player)
    script_data.job_zones[player.index] = nil
    script_data.claimed_chunks[player.index] = nil
end

local on_lua_shortcut = function(event)
    local player = game.get_player(event.player_index)
    local name = event.prototype_name
    if name == "companion-attack-toggle" then
        player.set_shortcut_toggled(name, not player.is_shortcut_toggled(name))
        recall_fighting_robots(player)
    end
	if name == "companion-construction-toggle" then
		player.set_shortcut_toggled(name, not player.is_shortcut_toggled(name))
		recall_constructing_robots(player)
		clear_job_zones(player)
		local player_data = script_data.player_data[player.index]
		if player_data then
			for unit_number in pairs(player_data.companions) do
				local companion = script_data.companions[unit_number]
				if companion then
					companion:set_robot_stack()
				end
			end
		end
	end
end

script.on_event("companion-attack-hotkey", function(event)
    local player = game.get_player(event.player_index)
    if player then
        player.set_shortcut_toggled("companion-attack-toggle", not player.is_shortcut_toggled("companion-attack-toggle"))
        recall_fighting_robots(player)
    end
end)

script.on_event("companion-construction-hotkey", function(event)
    local player = game.get_player(event.player_index)
    if player then
        player.set_shortcut_toggled("companion-construction-toggle", not player.is_shortcut_toggled("companion-construction-toggle"))
        recall_constructing_robots(player)
        clear_job_zones(player)
        local player_data = script_data.player_data[player.index]
        if player_data then
            for unit_number in pairs(player_data.companions) do
                local companion = script_data.companions[unit_number]
                if companion then
                    companion:set_robot_stack()
                end
            end
        end
    end
end)

script.on_event("companion-force-search", function(event)
    local player = game.get_player(event.player_index)
    if not player or not player.connected then return end

    local pd = script_data.player_data[player.index]
    if not pd then return end

    for unit_number in pairs(pd.companions) do
        local c = script_data.companions[unit_number]
        if c and c.can_construct and c:player_wants_construction() then
            c:search_for_nearby_work()
            c:search_for_nearby_targets()
            if c.debug_report_state then
                c:debug_report_state("force-search")
            end
        end
    end
end)

local dissect_area_size = 32

-- Builds the full chunk grid for `area` as columns (column = same x, chunks
-- top-to-bottom), so callers can both partition by column (zones, left to
-- right) and walk a column in a fixed order (serpentine sweep) without
-- re-deriving either from a flat list.
local function chunk_columns(xmin, xmax, ymin, ymax)
    local columns = {}
    for x = xmin, xmax, dissect_area_size do
        local column = {}
        for y = ymin, ymax, dissect_area_size do
            column[#column + 1] = {{x, y}, {x + dissect_area_size, y + dissect_area_size}}
        end
        columns[#columns + 1] = column
    end
    return columns
end

-- Flattens a set of columns into one boustrophedon ("lawnmower") path:
-- column 1 top-to-bottom, column 2 bottom-to-top, column 3 top-to-bottom,
-- and so on -- so working the resulting list front-to-back never
-- backtracks across the zone, unlike a plain nearest-chunk search.
local function serpentine_chunks_from_columns(columns)
    local chunks = {}
    for i, column in ipairs(columns) do
        if i % 2 == 0 then
            for j = #column, 1, -1 do chunks[#chunks + 1] = column[j] end
        else
            for j = 1, #column do chunks[#chunks + 1] = column[j] end
        end
    end
    return chunks
end

-- FIX (task finishing lopsidedly instead of visibly sweeping left to
-- right): zones used to be horizontal bands (top/middle/bottom), each
-- already spanning the full width -- confirmed via screenshots this let
-- one companion's band finish a dense cluster on one side of the map while
-- a *different* companion's band (covering the same rough area on the
-- other side) sat almost untouched for a long stretch, since which band
-- got attention first came down to whichever was nearest/denser, not
-- left-to-right order. Zones are now vertical strips (left to right) instead,
-- each spanning the full height, and paired with process_job_zones()'s
-- fallback now prioritizing the leftmost unfinished zone (see zone.min_x
-- below) instead of nearest-to-companion, so the whole task reads as one
-- sweep moving left to right instead of finishing unevenly by whichever
-- area happened to be denser or closer.
--
-- Splits `columns` into `num_zones` contiguous vertical strips (as equal as
-- possible; a task narrower than num_zones columns just produces fewer,
-- smaller zones -- some companions then have no zone of their own and go
-- straight to process_job_zones()'s "help elsewhere" fallback), each turned
-- into its own serpentine chunk list. Zones start unowned; see
-- assign_zone_owners().
local function partition_columns_into_zones(columns, num_zones)
    local total = #columns
    if total == 0 or num_zones <= 0 then return {} end
    num_zones = math.min(num_zones, total)
    local base = math.floor(total / num_zones)
    local extra = total % num_zones
    local zones = {}
    local idx = 1
    for z = 1, num_zones do
        local take = base + ((z <= extra) and 1 or 0)
        local zone_columns = {}
        for i = 1, take do
            zone_columns[#zone_columns + 1] = columns[idx]
            idx = idx + 1
        end
        local chunks = serpentine_chunks_from_columns(zone_columns)
        local min_x = math.huge
        for _, c in ipairs(chunks) do
            if c[1][1] < min_x then min_x = c[1][1] end
        end
        zones[#zones + 1] = { owner = nil, chunks = chunks, min_x = min_x }
    end
    return zones
end

local function zone_centroid(zone)
    local sx, sy, n = 0, 0, 0
    for _, a in ipairs(zone.chunks) do
        sx = sx + (a[1][1] + a[2][1]) / 2
        sy = sy + (a[1][2] + a[2][2]) / 2
        n = n + 1
    end
    if n == 0 then return 0, 0 end
    return sx / n, sy / n
end

-- Greedy nearest-zone-to-companion assignment: for each new zone (in band
-- order), hand it to whichever of this player's companions (not yet given
-- one of these new zones) is physically closest to that zone's centroid, so
-- a companion tends to start sweeping the band nearest to where it already
-- is rather than a random one. Companions beyond the zone count (or if the
-- task is smaller than the player's companion count) simply get no zone of
-- their own here and fall back to helping from the start.
local function assign_zone_owners(player_data, zones)
    local available = {}
    for unit_number in pairs(player_data.companions) do
        local c = get_companion(unit_number)
        if c then available[#available + 1] = c end
    end
    for _, zone in ipairs(zones) do
        if #zone.chunks > 0 and #available > 0 then
            local cx, cy = zone_centroid(zone)
            local best_i, best_dist = nil, math.huge
            for i, c in ipairs(available) do
                local p = c.entity.position
                local dx, dy = p.x - cx, p.y - cy
                local d = dx * dx + dy * dy
                if d < best_dist then
                    best_dist = d
                    best_i = i
                end
            end
            zone.owner = available[best_i].unit_number
            table.remove(available, best_i)
        end
    end
end

local dissect_and_queue_area = function(player_index, player_pos, area)
    -- FIX (wide/large tasks abandoned for good): this used to additionally
    -- clamp the queued chunks to a box within storage.max_distance of the
    -- player's position at the moment the order was given. Chunks outside
    -- that box weren't deferred, they were simply never queued at all, so
    -- on a task bigger than 2*max_distance across, the far side could only
    -- ever get picked up later by the generic proximity search once the
    -- player physically drove close enough to it themselves. The leash is
    -- already enforced live against the player's CURRENT position (see the
    -- abandon_job_distance check in Companion:update()), so re-checking it
    -- here against a stale snapshot position was redundant and wrong for
    -- the same reason the old per-chunk check in process_job_zones() (née
    -- process_specific_job_queue) was. Queue the whole selected area instead.
    local xmin = area.left_top.x
    local xmax = area.right_bottom.x
    local ymin = area.left_top.y
    local ymax = area.right_bottom.y

    local player_data = script_data.player_data[player_index]
    local num_zones = (player_data and table_size(player_data.companions)) or 1
    if num_zones < 1 then num_zones = 1 end

    local columns = chunk_columns(xmin, xmax, ymin, ymax)
    local new_zones = partition_columns_into_zones(columns, num_zones)
    if player_data then
        assign_zone_owners(player_data, new_zones)
    end

    local zone_state = script_data.job_zones[player_index]
    if not zone_state then
        zone_state = { zones = {} }
        script_data.job_zones[player_index] = zone_state
    end
    for _, zone in ipairs(new_zones) do
        if #zone.chunks > 0 then
            table.insert(zone_state.zones, zone)
        end
    end
end

local on_player_deconstructed_area = function(event)
    local player = game.get_player(event.player_index)
    if not player.is_shortcut_toggled("companion-construction-toggle") then return end
    dissect_and_queue_area(event.player_index, player.physical_position, event.area)
end

local function get_all_blueprint_entities(blueprint_record)
    local entities = {}

    if blueprint_record.type == "blueprint-book" and blueprint_record.object_name == "LuaItem" then
        blueprint_record = blueprint_record.get_inventory(defines.inventory.item_main)[blueprint_record.active_index]

        return get_all_blueprint_entities(blueprint_record)
    end

    -- Check if the item is a blueprint book
    if blueprint_record.type == "blueprint-book" then
        -- Recursively process each item inside the book
        for _, item in pairs(blueprint_record.contents) do
            local nested_entities = get_all_blueprint_entities(item)
            for _, nested_entity in pairs(nested_entities) do
                table.insert(entities, nested_entity)
            end
        end
    elseif blueprint_record.type == "blueprint" then
        -- Add entities if it's a single blueprint
        local blueprint_entities = blueprint_record.get_blueprint_entities()
        if blueprint_entities then
            for _, entity in pairs(blueprint_entities) do
                table.insert(entities, entity)
            end
        end
    end

    return entities
end

local get_blueprint_area = function(player, offset)
    local entities = {}
    local max = 0
    local x1, y1, x2, y2
    local position

    if player.cursor_stack and player.cursor_stack.valid_for_read then
        if player.cursor_stack.object_name == "LuaRecord" and player.cursor_stack.count > 0 then
            entities = get_all_blueprint_entities(player.cursor_stack)
        else
            entities = get_all_blueprint_entities(player.cursor_stack.item)
        end
    elseif player.cursor_record then
        entities = get_all_blueprint_entities(player.cursor_record)
    else
        max = 32
    end

    if entities and #entities > 0 then
        for _, entity in pairs (entities) do
            position = entity.position
            x1 = math.min(x1 or position.x, position.x)
            y1 = math.min(y1 or position.y, position.y)
            x2 = math.max(x2 or position.x, position.x)
            y2 = math.max(y2 or position.y, position.y)

            max = math.max(max, math.abs(x1), math.abs(x2), math.abs(y1), math.abs(y2))
        end
    end

    return {left_top = {x = offset.x - max, y = offset.y - max}, right_bottom = {x = offset.x + max, y = offset.y + max}}
end

local on_pre_build = function(event)
    local player = game.get_player(event.player_index)

    if not (player.is_cursor_blueprint()) then return end

    if not player.is_shortcut_toggled("companion-construction-toggle") then
        return
    end

    -- I am lazy, not going to bother with rotations and flips...
    local area = get_blueprint_area(player, event.position)
    dissect_and_queue_area(event.player_index, player.physical_position, area)


end

local on_player_created = function(event)
    local player = game.get_player(event.player_index)
    if not player then return end

    local surface = player.physical_surface
    local position = player.physical_position
	local entity = surface.create_entity
	{
	    name = "companion",
	    position = position,
	    force = player.force
	}
	entity.insert("wood")
	entity.color = player.color
	local grid = entity.grid
	grid.put{name = "companion-reactor-mk2"}
	grid.put{name = "companion-defense-mk2"}
	grid.put{name = "companion-defense-mk2"}
	grid.put{name = "companion-roboport-mk2"}
	grid.put{name = "companion-shield-mk2"}
    player.set_shortcut_available("companion-attack-toggle", true)
    player.set_shortcut_toggled("companion-attack-toggle", true)
	player.set_shortcut_available("companion-construction-toggle", true)
	player.set_shortcut_toggled("companion-construction-toggle", true)
	local companion = Companion.new(entity, player)
end

local function purge_illegal_companion_bots(player)
    if not (player and player.valid) then return end
    local cs = player.cursor_stack
    if cs and cs.valid_for_read and cs.name == "companion-construction-robot" then
        cs.clear()
    end
    local removed = player.remove_item{name = "companion-construction-robot", count = 1000000}
    if removed > 0 then
        local opened = player.opened
        if opened and opened.valid and opened.name == "companion" then
            local c = get_companion(opened.unit_number)
            if c then c:set_robot_stack() end
        end
    end
end

local on_player_main_inventory_changed = function(event)
    local player = game.get_player(event.player_index)
    purge_illegal_companion_bots(player)
end

local on_player_fast_transferred = function(event)
    local player = game.get_player(event.player_index)
    purge_illegal_companion_bots(player)
end

local on_player_cursor_stack_changed = function(event)
    local player = game.get_player(event.player_index)
    purge_illegal_companion_bots(player)
end

local function swap_equipment(grid, input, output) -- equipment literal names as strings, matches any arbitrary names. 
	if not grid or type(input) ~= "string" or type(output) ~= "string" then return nil end
	local target_positions = {} -- where on the grid each matching equipment is located
	for _, equipment in pairs(grid.equipment) do -- find the position of each equipment
		if equipment.name == input then 
			table.insert(target_positions, equipment.position)
		end 
	end
	for i = 1, #target_positions do -- remove "input" and replace with "output" equipment
		grid.take{position = target_positions[i]}
		grid.put{name = output, position = target_positions[i]}
	end
end

function Companion:get_random_localised(key)
    -- Looks in __root__/locale/en/locale.cfg and reads the first line in KEY, then uses that value as it's upper bounds for randomly picking between 1 and KEY. 
	-- In the locale file, the first line should always be the exact number of lines in that section
	-- too low (i.e. lines were added) won't do anything except not show the added lines but too high will just return the key itself
    local count = storage.dialogue_counts and storage.dialogue_counts[key]
    if not count then
        local translated = self.player.request_translation({key .. ".0"})
        count = tonumber(translated) or 1
        storage.dialogue_counts = storage.dialogue_counts or {}
        storage.dialogue_counts[key] = count
    end
    local index = math.random(1, count)
    return {key .. "." .. index}
end

function Companion:say_random(key) 
    -- this function used to do more than simply call that ^ function, just haven't bothered removing it from where it's spread
    self:say(self:get_random_localised(key))
end

local function reseed_defaults()
    set_defaults()
    if reschedule_companions then reschedule_companions(true) end
    game.print("Companion defaults re-seeded.")
end

local function reset_companions_for_player(player)
    local player_data = script_data.player_data and script_data.player_data[player.index]
    if not player_data or not next(player_data.companions) then
        player.print("No companion data found for this player.")
        return
    end

    local count = 0
    for unit_number in pairs(player_data.companions) do
        local companion = script_data.companions[unit_number]
        if companion then
            -- reset state
            companion:clear_robots()
            companion.is_busy_for_construction = false
            companion.is_in_combat = false
            companion.job_done_tick = nil
            companion.job_done_announced = false
            companion.out_of_energy = nil
            companion.moving_to_destination = nil
            companion.next_idle_line_tick = nil
            companion.test_idle_tick = nil
            companion.test_idle_fired = nil
            companion.defend_player_until_tick = nil
            companion._hazard_dodge_streak = nil
            companion._hazard_dodge_suppress_until = nil
            companion:clear_speed_sticker()
            companion:check_equipment()
            companion:try_to_refuel()
            companion:set_active()
            adjust_follow_behavior(player)
            companion:debug_report_state("RESET")

            count = count + 1
        end
    end

    game.print({"", "Reset ", count, " companions for ", player.name, "."})
end

local function on_entity_damaged(event)
    local ent = event.entity
    if not (ent and ent.valid) then return end

    -- Telemetry: shared damage snapshot recorded on whoever got hit (player
    -- or companion), read back by companion_test.dump_telemetry() for the
    -- LAN/RCON polling setup -- see CLAUDE.md's "Headless/RCON test harness".
    local damage_snapshot =
    {
        amount = event.final_damage_amount,
        dtype = event.damage_type and event.damage_type.name,
        cause = (event.cause and event.cause.valid) and event.cause.name or nil,
        tick = game.tick,
    }

    -- FEATURE (Preserve player life): if the player themselves takes a hit,
    -- every one of their companions that's actually armed (has at least one
    -- companion-defense-mkN equipped) and has the attack toggle on breaks
    -- off whatever it was doing and rushes back to the player at urgent
    -- speed, via the same force_return_to_player() primitive the full-cargo
    -- recall uses -- doesn't clear current_job_target/robots, so whatever
    -- it interrupted resumes on its own the same way a supply run does.
    -- Once close enough, the vanilla defense equipment (and the
    -- kiting/dodge logic above) takes over automatically; nothing further
    -- is needed here beyond getting it there fast.
    --
    -- FIX (companion abandoned the rush and resumed its old job while the
    -- player was still under fire): the original version only called
    -- force_return_to_player() once, here, with nothing persisted -- so on
    -- the very next Companion:update() tick (which runs on its own separate
    -- schedule), normal job logic saw current_job_target still set and
    -- immediately re-issued set_job_destination(), overwriting the rush
    -- before the companion had gotten anywhere close. defend_player_until_tick
    -- is a rolling deadline (refreshed on every hit, not just the throttled
    -- ones below) that Companion:update() now checks and re-commands
    -- force_return_to_player() against on every one of its own ticks, so
    -- the companion keeps beelining for the player for a few seconds after
    -- the last hit landed instead of bailing after one damage event.
    if ent.type == "character" and ent.player then
        local player = ent.player
        local player_data = script_data.player_data[player.index]
        if player_data then
            player_data.last_damage = damage_snapshot
            local until_tick = game.tick + defend_player_duration
            local do_instant_call = not player_data.last_defend_tick or (game.tick - player_data.last_defend_tick) >= 30
            if do_instant_call then
                player_data.last_defend_tick = game.tick
            end
            for unit_number in pairs(player_data.companions) do
                local companion = get_companion(unit_number)
                if companion and companion:player_wants_attack()
                   and get_best_defense_tier(companion) > 0 then
                    companion.defend_player_until_tick = until_tick
                    if do_instant_call then
                        companion:force_return_to_player()
                    end
                end
            end
        end
        return
    end

    if ent.name ~= "companion" then return end

    local c = get_companion(ent.unit_number)
    if not c then return end                                     -- uses your helper
    c.last_damage = damage_snapshot
    if c.entity.surface ~= c.player.physical_surface then return end

    -- FIX (companion standing in fire/acid, or eating spitter hits over
    -- water, never reacted): Companion:update() -- and with it, the
    -- proactive dodge_ground_hazard() scan -- only runs for companions in
    -- the active_companions list (see can_go_inactive()/clear_active()), so
    -- an idle companion parked near a forest fire or lingering acid puddle
    -- never noticed it was standing in one. Reacting here instead means it
    -- doesn't matter whether the companion is currently "active" -- taking
    -- fire/acid damage always re-triggers a dodge, and dodge_ground_hazard()
    -- ends by calling set_active() itself, so it also gets pulled back onto
    -- the update list going forward. This is intentionally NOT gated by
    -- player_wants_attack() like the enemy-threat branch below --
    -- environmental damage isn't "the player wants me to fight," it's just
    -- damage that shouldn't be tanked either way.
    --
    -- If there's no lingering fire entity to dodge (e.g. the companion is
    -- over water, where the game's own tile_collision_mask stops the spit's
    -- splash fire from ever spawning -- see acid_stream() in the base
    -- game's enemy-projectiles.lua), fall back to stepping away from
    -- whatever caused the hit instead of doing nothing. event.cause isn't
    -- always populated for this kind of area-effect damage (confirmed live:
    -- a direct spit hit over water came through with cause = nil), so fall
    -- back further to the nearest enemy-force entity if cause is missing.
    local dtype = event.damage_type and event.damage_type.name
    if dtype == "fire" or dtype == "acid" then
        if not c._last_hazard_dodge_tick or (game.tick - c._last_hazard_dodge_tick) >= 30 then
            c._last_hazard_dodge_tick = game.tick
            if not c:dodge_ground_hazard() then
                -- FIX (companion burned to death standing still): this
                -- fallback fires when there's no ground fire entity to dodge
                -- but something is still actively damaging the companion --
                -- confirmed live via a flamethrower: the hit also attaches a
                -- `fire-sticker` directly to the companion (see
                -- flamethrower-fire-stream in the base game), which deals its
                -- own periodic damage independent of any ground fire, so
                -- dodge_ground_hazard() correctly finds nothing to dodge every
                -- single time. Fleeing the attacker (event.cause, or the
                -- nearest enemy-force entity if cause is missing) is still the
                -- right response -- it just needs real distance to matter,
                -- the same as combat kiting uses, not hazard_retreat_step's
                -- 2 tiles (tuned for "step off a small ground puddle," a
                -- completely different physical situation from "get away
                -- from whatever is actively lighting me on fire").
                local cause_pos = (event.cause and event.cause.valid) and event.cause.position
                                   or c:find_nearest_enemy_position(hazard_scan_radius * 3)
                if cause_pos then
                    c:step_away_from(cause_pos, kite_retreat_step)
                end
            end
        end
        return
    end

    if c:player_wants_attack() then return end                    -- respect attack toggle

    if c._last_escape_tick and (game.tick - c._last_escape_tick) < 30 then return end
    c._last_escape_tick = game.tick

    local src = (event.cause and event.cause.valid) and event.cause.position or nil
    c:escape_danger(src)                                          -- flee from cause, or to player if nil
end


lib.events =
{
    [defines.events.on_built_entity]                  = on_built_entity,
    [defines.events.on_object_destroyed]              = on_entity_destroyed,
    [defines.events.on_tick]                          = on_tick,
    [defines.events.on_spider_command_completed]      = on_spider_command_completed,
    [defines.events.on_script_trigger_effect]         = on_script_trigger_effect,
    [defines.events.on_entity_settings_pasted]        = on_entity_settings_pasted,

    [defines.events.on_player_placed_equipment]       = on_player_placed_equipment,
    [defines.events.on_player_removed_equipment]      = on_player_removed_equipment,
    [defines.events.on_player_main_inventory_changed] = on_player_main_inventory_changed,
    [defines.events.on_player_fast_transferred]       = on_player_fast_transferred,
    [defines.events.on_player_cursor_stack_changed]   = on_player_cursor_stack_changed,

    [defines.events.on_player_changed_surface]        = on_player_changed_surface,
    [defines.events.on_player_left_game]              = on_player_left_game,
    [defines.events.on_player_joined_game]            = on_player_joined_game,
    [defines.events.on_player_created]                = on_player_created,
    [defines.events.on_player_changed_force]          = on_player_changed_force,
    [defines.events.on_player_driving_changed_state]  = on_player_driving_changed_state,
    [defines.events.on_player_used_spidertron_remote] = on_player_used_spider_remote,

    [defines.events.on_player_mined_entity]           = on_player_mined_entity,
    [defines.events.on_pre_player_mined_item]         = on_pre_player_mined_item,
    [defines.events.on_lua_shortcut]                  = on_lua_shortcut,
    [defines.events.on_player_deconstructed_area]     = on_player_deconstructed_area,
    [defines.events.on_pre_build]                     = on_pre_build,
    [defines.events.on_entity_damaged]                = on_entity_damaged,
}

---------------------------- Migrations ----------------------------------

local function migrate_companions()
    for unit_number, companion in pairs(script_data.companions) do
        companion.last_idle_line_tick = companion.last_idle_line_tick or game.tick
        companion.next_forced_idle_tick = companion.next_forced_idle_tick or (game.tick + 1800)
        companion.job_done_tick = companion.job_done_tick or nil
        companion.job_done_announced = companion.job_done_announced or false
    end
end

local string = string
local table = table

local version_pattern = "%d+"
local version_format = "%02d"

function format_version(version, format)
-- from FLIB
  if version then
    format = format or version_format
    local tbl = {}
    for v in string.gmatch(version, version_pattern) do
      tbl[#tbl + 1] = string.format(format, v)
    end
    if next(tbl) then
      return table.concat(tbl, ".")
    end
  end
  return nil
end

function is_newer_version(old_version, current_version, format)
-- from FLIB
  local v1 = format_version(old_version, format)
  local v2 = format_version(current_version, format)
  if v1 and v2 then
    if v2 > v1 then
      return true
    end
    return false
  end
  return nil
end

function run(old_version, migrations, format, ...)
-- from FLIB
  local migrate = false
  for version, func in pairs(migrations) do
    if migrate or is_newer_version(old_version, version, format) then
      migrate = true
      func(...)
    end
  end
end

function on_config_changed(e, migrations, mod_name, ...) 
-- from FLIB
-- only runs if THIS mod is what changed, rather than if ANY mod changed like vanilla on_configuration_changed()
  local changes = e.mod_changes[mod_name or script.mod_name]
  local old_version = changes and changes.old_version
  if old_version then
    if migrations then
      run(old_version, migrations, nil, ...)
    end
    return true
  end
  return false
end

-- FIX (companions silently reset on every version bump): this used to
-- carry a migrations["3.0.0"] entry (plus create_popup()/show_update_popup()/
-- on_gui_click() to display it) inherited from the original upstream
-- "Companion Drones" mod, which really did have its own 3.0.0 release at
-- some point in its history. This fork branched off long before that and
-- has used its own independent 1.x.x version numbering ever since, so that
-- migration key never actually corresponds to anything real here -- but
-- is_newer_version()'s zero-padded string comparison ("01.02.01" vs
-- "03.00.00") means old_version is *always* considered older than "3.0.0"
-- for any 1.x.x version this fork will ever have. Every single
-- on_configuration_changed (i.e. every time info.json's version is bumped
-- and the save reloaded, which includes ordinary dev testing, not just real
-- upstream-style migrations) re-ran reset_companions_for_player() on every
-- player's companions and popped a "MAJOR MOD UPDATE DETECTED! Companion
-- Drones 3.0" dialog -- clearing robots/jobs/moving_to_destination on
-- companions that may have been mid-task. If you ever add a real migration
-- here, key it to this fork's own version numbers, not a leftover upstream
-- milestone.
local migrations = {}

script.on_configuration_changed(function(e)
    bind_storage()
    local secret = game.surfaces["secret_companion_surface_please_don't_touch"]
    if secret then
        for _, force in pairs(game.forces) do
            force.set_surface_hidden(secret, true)
        end
    end
    storage.companion_update_interval = settings.startup["set-update-interval"].value or 5
    reseed_defaults()
    for player_index, player_data in pairs (script_data.player_data) do

        if player_data.last_search_offset then
            player_data.last_job_search_offset = player_data.last_search_offset
            player_data.last_attack_search_offset = player_data.last_search_offset
            player_data.last_search_offset = nil
        end

        local player = game.get_player(player_index)
        if player then
            local gui = player.gui.relative
            if gui.companion_gui then
                gui.companion_gui.destroy()
            end

            if not player.is_shortcut_available("companion-attack-toggle") then
                player.set_shortcut_available("companion-attack-toggle", true)
                player.set_shortcut_toggled("companion-attack-toggle", true)
            end

            if not player.is_shortcut_available("companion-construction-toggle") then
                player.set_shortcut_available("companion-construction-toggle", true)
                player.set_shortcut_toggled("companion-construction-toggle", true)
            end
        else
            script_data.player_data[player_index] = nil
        end

    end

    for k, companion in pairs (script_data.companions) do
        if (companion.player and companion.player.valid) then
            companion.speed = companion.speed or 0
            companion:clear_passengers()
            companion.entity.minable_flag = true -- 2.1: .minable write removed
        else
            companion.entity.destroy()
            script_data.companions[k] = nil
        end
    end

    if script_data.tick_updates then
        script_data.tick_updates = nil
    end

    script_data.job_zones = script_data.job_zones or {}
    script_data.claimed_entities = script_data.claimed_entities or {}
    script_data.claimed_chunks = script_data.claimed_chunks or {}

    reschedule_companions()
	migrate_companions()
	on_config_changed(e, migrations)
end)

lib.on_load = function()
    script_data = storage.companion or script_data
    for unit_number, companion in pairs(script_data.companions) do
        setmetatable(companion, Companion.metatable)
    end
end


----------------------------------- Commands and Remotes ------------------------------------

local jetpack_remote =
{
    on_character_swapped = function(event)
        local new_character = event.new_character
        if not (new_character and new_character.valid) then return end
        if new_character.player then
            adjust_follow_behavior(new_character.player)
        end
    end
}

script.on_event(defines.events.on_string_translated, function(event)
	local key = event.localised_string[1]
	if key and event.translated and key:match("^.+%.0$") then
		local base_key = key:match("^(.-)%.0$")
		storage.dialogue_counts = storage.dialogue_counts or {}
		storage.dialogue_counts[base_key] = tonumber(event.result) or 1
	end
end)

function Companion:debug_stats_state(prefix)
    local msg = string.format(
        "[%s] tick=%d unit=%s | speed=%s damage=%s range=%s count=%s",
        prefix or "",
        game.tick,
        tostring(storage.unit_number),
        tostring(storage.base_speed),
        tostring(storage.attack_count),
        tostring(storage.max_distance),
        tostring(storage.max_companions)
    )
    log(msg)
    self.player.print(msg)
end

function Companion:debug_report_state(prefix)
    local msg = string.format(
        "[%s] tick=%d unit=%s | wants=%s can_construct=%s surface_ok=%s cell=%s is_busy=%s robots=%d pos=(%.1f,%.1f) actv=%s itick=%s",
        prefix or "",
        game.tick,
        tostring(self.unit_number),
        tostring(self:player_wants_construction()),
        tostring(self.can_construct),
        tostring(self.entity.surface == self.player.physical_surface),
        tostring(self.entity.logistic_cell ~= nil),
        tostring(self:is_busy()),
        table_size(self.robots or {}),
        self.entity.position.x, self.entity.position.y,
        tostring(self.active),
        tostring(self.next_idle_line_tick)
    )
    log(msg)
    self.player.print(msg)
end

remote.add_interface("companion_speed", {
    set_factor = function(v)
        if type(v) == "number" and v > 0 then
            storage.companion_speed_factor = v
            for _, comp in pairs(script_data.companions) do
                if comp and comp.entity and comp.entity.valid then
                    comp._last_speed_factor = nil
                end
            end
        end
    end,
    get_factor = function() return storage.companion_speed_factor or 1.0 end,
})

remote.add_interface("companion_remote_for_jetpack", jetpack_remote)

-- Test-harness hook (see tools/ in the repo): storage is per-mod isolated,
-- so RCON's own "/c" console sandbox can't read script_data directly -- it
-- needs to go through a remote.call (which runs inside this mod's own
-- environment) to see real state. Returns a plain string instead of a table
-- since remote.call results cross the mod boundary via serialization, and a
-- flat string is trivial to print straight from an RCON "/c rcon.print(...)"
-- call with no extra decoding on the caller's side.
remote.add_interface("companion_test", {
    dump_state = function()
        local lines = {}
        lines[#lines + 1] = "tick=" .. game.tick

        for _, player in pairs(game.players) do
            local player_data = script_data.player_data[player.index]
            local companion_count = player_data and table_size(player_data.companions) or 0
            lines[#lines + 1] = string.format(
                "player index=%d name=%s pos=%.1f,%.1f companions=%d",
                player.index, player.name,
                player.physical_position.x, player.physical_position.y,
                companion_count
            )
        end

        for unit_number, companion in pairs(script_data.companions) do
            if companion.entity and companion.entity.valid then
                local pos = companion.entity.position
                local t = companion.current_job_target
                local target_str = "nil"
                if t then
                    local tx = t[1] or t.x
                    local ty = t[2] or t.y
                    target_str = string.format("%.1f,%.1f", tx, ty)
                end
                local pre_recall_str = "nil"
                if companion.pre_recall_position then
                    pre_recall_str = string.format("%.1f,%.1f", companion.pre_recall_position.x, companion.pre_recall_position.y)
                end
                lines[#lines + 1] = string.format(
                    "companion unit=%d player=%d pos=%.1f,%.1f target=%s from_queue=%s busy=%s full=%s robots=%d claimed_uid=%s pre_recall=%s",
                    unit_number,
                    companion.player and companion.player.index or -1,
                    pos.x, pos.y,
                    target_str,
                    tostring(companion.current_job_from_queue),
                    tostring(companion.is_busy_for_construction),
                    tostring(companion.is_getting_full),
                    table_size(companion.robots or {}),
                    tostring(companion.claimed_unit_number),
                    pre_recall_str
                )
            end
        end

        for player_index, zone_state in pairs(script_data.job_zones or {}) do
            local total_chunks = 0
            local zone_lines = {}
            for zi, zone in ipairs(zone_state.zones) do
                total_chunks = total_chunks + #zone.chunks
                zone_lines[#zone_lines + 1] = string.format("z%d:owner=%s:chunks=%d", zi, tostring(zone.owner), #zone.chunks)
            end
            lines[#lines + 1] = string.format("queue player=%d chunks_remaining=%d zones=%d [%s]",
                player_index, total_chunks, #zone_state.zones, table.concat(zone_lines, " "))
        end

        for player_index, claims in pairs(script_data.claimed_chunks or {}) do
            lines[#lines + 1] = string.format("claimed_chunks player=%d count=%d", player_index, table_size(claims))
        end

        lines[#lines + 1] = string.format("claimed_entities count=%d", table_size(script_data.claimed_entities or {}))

        return table.concat(lines, "\n")
    end,

    -- Convenience for scripted tests: queue a deconstruction order over an
    -- explicit area the same way the selection tool does, without needing a
    -- connected client to actually drag a selection box.
    queue_deconstruction = function(player_index, x1, y1, x2, y2)
        local player = game.get_player(player_index)
        if not player then return "no such player" end
        local surface = player.physical_surface
        local area = {left_top = {x = x1, y = y1}, right_bottom = {x = x2, y = y2}}
        surface.deconstruct_area{
            area = area,
            force = player.force,
            player = player,
        }
        dissect_and_queue_area(player_index, player.physical_position, area)
        return "queued"
    end,

    -- Spawns an extra fully-equipped (mk2) companion for a player, mirroring
    -- on_player_created()'s free-starter-companion setup, so multi-companion
    -- scenarios can be set up from a test script without manually crafting/
    -- placing/equipping companion items through the GUI. Still subject to
    -- the normal max_companions cap (Companion.new() itself enforces it and
    -- returns nil if capped, same as any other companion spawn path).
    spawn_companion = function(player_index, offset_x, offset_y)
        local player = game.get_player(player_index)
        if not player then return "no such player" end
        local surface = player.physical_surface
        local position = {
            x = player.physical_position.x + (offset_x or 0),
            y = player.physical_position.y + (offset_y or 0),
        }
        local entity = surface.create_entity{
            name = "companion",
            position = position,
            force = player.force
        }
        if not entity then return "create_entity failed" end
        entity.insert("wood")
        entity.color = player.color
        local grid = entity.grid
        grid.put{name = "companion-reactor-mk2"}
        grid.put{name = "companion-defense-mk2"}
        grid.put{name = "companion-defense-mk2"}
        grid.put{name = "companion-roboport-mk2"}
        grid.put{name = "companion-shield-mk2"}
        -- Companion.new() has no return statement in either its success or
        -- cap-rejection path (pre-existing in the mod, not something this
        -- test hook can rely on) -- check whether it actually registered
        -- the entity instead of trusting a return value.
        Companion.new(entity, player)
        if entity.valid and script_data.companions[entity.unit_number] then
            return "spawned unit=" .. entity.unit_number
        end
        local player_data = script_data.player_data[player.index]
        local count = player_data and table_size(player_data.companions) or 0
        if entity.valid then entity.destroy() end
        return string.format("capped: count=%d max=%d storage.max_companions=%s",
            count, get_max_companions(player.force), tostring(storage.max_companions))
    end,

    -- Testing convenience: override the shared max_companions base constant
    -- directly, bypassing the normal "research follower-robot-count" gate,
    -- so multi-companion scenarios can be set up without a research cheat
    -- roundtrip first.
    set_max_companions = function(n)
        storage.max_companions = n
        return "storage.max_companions=" .. n
    end,

    -- Testing convenience: research a technology instantly on a player's
    -- force, for setting up equipment-tier/max-companion scenarios without
    -- manually clicking through the tech tree.
    research = function(player_index, tech_name)
        local player = game.get_player(player_index)
        if not player then return "no such player" end
        local tech = player.force.technologies[tech_name]
        if not tech then return "no such technology: " .. tech_name end
        tech.researched = true
        return "researched " .. tech_name
    end,

    -- Live telemetry for a real (not scripted) play session polled over
    -- RCON, e.g. once per second from a PowerShell loop -- see
    -- tools/poll-telemetry.ps1. Covers the three things asked for when this
    -- was set up: damage/HP/shield, job/kiting/combat state, and what's
    -- nearby (enemies, fire hazards). Kept as one big formatted string
    -- (like dump_state()) rather than real JSON since RCON's response body
    -- is just plain text either way and this is easier to read by eye.
    dump_telemetry = function(player_index)
        local player = game.get_player(player_index)
        if not player then return "no such player" end

        local function format_damage(d)
            if not d then return "none" end
            return string.format("%.1f %s from %s (%dt ago)",
                d.amount or 0, tostring(d.dtype), tostring(d.cause), game.tick - (d.tick or game.tick))
        end

        local lines = { "tick=" .. game.tick }
        local player_data = script_data.player_data[player.index]

        if player.character then
            local ch = player.character
            local pos = player.physical_position
            local shield_str = "none"
            if ch.grid then
                shield_str = string.format("%d/%d", ch.grid.shield or 0, ch.grid.max_shield or 0)
            end
            local nearby_enemies = player.physical_surface.find_entities_filtered{position = pos, radius = 30, force = "enemy"}
            lines[#lines + 1] = string.format(
                "player pos=%.1f,%.1f hp=%.0f/%.0f shield=%s nearby_enemies=%d last_damage=%s",
                pos.x, pos.y, ch.health, ch.prototype.get_max_health(), shield_str,
                #nearby_enemies, format_damage(player_data and player_data.last_damage)
            )
        else
            lines[#lines + 1] = "player has no character"
        end

        if not player_data or not next(player_data.companions) then
            lines[#lines + 1] = "no companions"
            return table.concat(lines, "\n")
        end

        for unit_number in pairs(player_data.companions) do
            local c = get_companion(unit_number)
            if c and c.entity and c.entity.valid then
                local pos = c.entity.position
                local grid = c.entity.grid
                local shield_str = "none"
                if grid then
                    shield_str = string.format("%d/%d", grid.shield or 0, grid.max_shield or 0)
                end

                local target_str = "nil"
                if c.current_job_target then
                    local t = c.current_job_target
                    target_str = string.format("%.1f,%.1f", t.x or t[1], t.y or t[2])
                end

                local defend_str = "no"
                if c.defend_player_until_tick and game.tick < c.defend_player_until_tick then
                    defend_str = (c.defend_player_until_tick - game.tick) .. "t"
                end

                local nearby_enemies = c.entity.surface.find_entities_filtered{position = pos, radius = 20, force = "enemy"}
                local nearby_fire = c.entity.surface.find_entities_filtered{position = pos, radius = hazard_scan_radius, type = "fire"}

                local claimed_str = "none"
                if c.claimed_target_entity then
                    claimed_str = c.claimed_target_entity.valid and "valid" or "INVALID"
                end

                lines[#lines + 1] = string.format(
                    "companion unit=%d pos=%.1f,%.1f hp=%.0f/%.0f shield=%s in_combat=%s busy=%s moving=%s robots=%d dist_to_player=%.1f full=%s can_construct=%s wants_construct=%s job_target=%s from_queue=%s claimed=%s defend_for=%s hazard_streak=%d nearby_enemies=%d nearby_fire=%d last_damage=%s",
                    unit_number, pos.x, pos.y,
                    c.entity.health, c.entity.prototype.get_max_health(), shield_str,
                    tostring(c.is_in_combat), tostring(c.is_busy_for_construction), tostring(c.moving_to_destination),
                    table_size(c.robots or {}), c:distance(player.physical_position),
                    tostring(c.is_getting_full), tostring(c.can_construct), tostring(c:player_wants_construction()),
                    target_str, tostring(c.current_job_from_queue), claimed_str,
                    defend_str, c._hazard_dodge_streak or 0,
                    #nearby_enemies, #nearby_fire, format_damage(c.last_damage)
                )
            end
        end

        return table.concat(lines, "\n")
    end,
})

commands.add_command("reschedule_companions", "If they get stuck or something", reschedule_companions)

commands.add_command("reset_companions",
"Fully reset your companion(s) to brand-new state.",
function(cmd) 
    local player = game.get_player(cmd.player_index)
    if player then reset_companions_for_player(player) end
end)

--Various debug commands:
commands.add_command("debug_companion", 
"Debug companion state", 
function(cmd)
    if not debug_mode then game.print("You cannot use this command while Debug mode is disabled") return end 
    local player = game.get_player(cmd.player_index)
    if not player then return end
    local player_data = script_data.player_data[player.index]
    if not player_data then player.print("No player_data") return end
    for unit_number in pairs(player_data.companions) do
        local companion = script_data.companions[unit_number]
        if companion then
            companion:debug_report_state("console")
            companion:debug_stats_state("stats")
        end
    end
end)

commands.add_command("swap_equipment", 
"Takes any input equipment name and replaces it with output name. Takes two arguments.", 
function(cmd)
    if not debug_mode then game.print("You cannot use this command while Debug mode is disabled") return end
	local errmsg = "Usage: /swap_equipment <old-equipment-literal-name> <new-equipment-literal-name>"
    local player = game.get_player(cmd.player_index)
    local companion = script_data.companions[next(script_data.player_data[player.index].companions)]
    local grid = companion:get_grid()
	if not cmd.parameter then
		game.print(errmsg)
		return
	end
	local input, output = cmd.parameter:match("^(%S+)%s+(%S+)$") 
	-- splits the combined string of "old_equipment_name new_equipment_name" and separates them where the whitespace is
	-- then assigns them to input and output respectively.
	if not input or not output or type(input) ~= "string" or type(output) ~= "string" then
		game.print(errmsg)
		return
	end
	swap_equipment(grid, input, output)
end)

commands.add_command("companion_reseed_defaults",
"Refreshes companion stats in storage table.",
function(cmd)
    if not debug_mode then game.print("You cannot use this command while Debug mode is disabled") return end
    local player = game.get_player(cmd.player_index)
    if player then reseed_defaults(player) end
end)

commands.add_command("companion_speed_factor",
"Set companion speed multiplier (>0). Decimals between 0 and 1 will slow the drone.",
function(cmd)
    if not debug_mode then game.print("You cannot use this command while Debug mode is disabled") return end
    local v = tonumber(cmd.parameter)
    if v and v > 0 then
        remote.call("companion_speed", "set_factor", v)
        game.print({"", "[Companion] speed factor set to ", v})
    else
        local cur = remote.call("companion_speed", "get_factor")
        game.print({"", "[Companion] current speed factor = ", cur, " (usage: /companion_speed_factor <number>)"})
    end
end)

return lib