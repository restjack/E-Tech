# Companion Drones 2.0: Full Autonomy

A standalone fork of Companion Drones (based on the mjlfix 3.1.2 build) rebuilt around one goal: the companion should finish what you give it, on its own, without babysitting.

**This is a standalone replacement. Do not run it alongside the original or any other "Companion Drones" mod.**

**This mod is STILL BEING DEVELOPED and I'm actively working on it in my own free time! Expect borked stuff or unoptimized performance in some cases!**

## What it is

The companion is a persistent, upgradeable flying drone that follows you, builds/deconstructs/repairs/upgrades anything a construction robot could, manages its own inventory and fuel, and can defend itself in combat. It isn't a portable roboport you babysit - it's meant to be handed work and left alone.

## Autonomy, the headline feature

Give the companion a large deconstruction order or a blueprint and it will work through the entire thing by itself:

- Explicit tasks like this are exempt from the normal "stay near the player" leash - the companion won't abandon a big job just because you walked off to do something else.
- When cargo fills up, it automatically flies back to unload, then resumes the same task afterward instead of getting stuck standing in the middle of a forest.
- When several companions work the same task, it's automatically divided into sections so each companion sweeps its own part in an orderly pattern instead of overlapping or duplicating each other's routes. A companion that finishes its section early moves on to help whichever section is furthest behind.

Everything not covered by an explicit task is still handled the old way: the companion opportunistically picks up nearby construction/deconstruction/repair work as it follows you around, within a leash range that keeps it from wandering off on its own.

## Equipment and progression

The companion starts fully equipped and ready to work immediately - no crippled start, no separate difficulty modes to configure. From there, every piece of its gear (roboport, shield, laser, reactor) has its own four-tier upgrade path, from cheap starter gear all the way up to serious late-game equipment unlocked through research - so the companion keeps getting meaningfully better as you progress, not just faster.

Researching vanilla's infinite "Follower Robot Count" technology also raises how many companions you're allowed to have at once (starting from 3).

## Customization

- Toggle construction/deconstruction or combat independently, via shortcut buttons or (unbound by default) keybinds.
- Turn the companion's idle chatter on/off, or adjust how often it speaks.
- Raise the update interval to trade responsiveness for performance if you're running several companions at once.
- Choose whether it burns its best or worst fuel first.

## Known issues

- **Feedback is appreciated:** Have you encountered a bug? Would you like a feature to be added? Write it down on this modpage in discussions and I'll get to it as soon as possible.

- **Combat is still evolving:** the companion now repositions during fights and defends you when you're attacked, but combat behavior is newer than the construction side of the mod and hasn't been battle-tested as thoroughly. Feedback on both (de)construction / battle behaviour is appreciated a lot!

## Notes for other modders

- The dialogue system reads locale sections dynamically; line `0` of a section must be the integer count of lines in that section. Repeat a line to make it more likely to be picked.

## Credits

- Original mod and much of the core logic by Klonan
- kubiixx, MrJakobLaich and Maoman - for coming in with "Companion Drones for 2.0" and their updated codebase
- Forked, adjusted, fixed and maintained by Wearo