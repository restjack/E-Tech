local util = require("__core__/lualib/util")

local function replace_shadows(node, replacement)
    if type(node) ~= "table" then return end
    if node.draw_as_shadow == true then
        for k in pairs(node) do node[k] = nil end
        for k, v in pairs(replacement) do node[k] = v end
        return
    end
    for _, v in pairs(node) do
        if type(v) == "table" then replace_shadows(v, replacement) end
    end
end

local companion = data.raw["spider-vehicle"] and data.raw["spider-vehicle"]["companion"]
if companion and companion.graphics_set then
    local SHADOW = {
        filename = "__companion-drones-2-updated__/sprites/shadow.png",
        width = 256, height = 256,
        shift = util.by_pixel(-9, 4),
        scale = 0.15,
        draw_as_shadow = true,
    }
    replace_shadows(companion.graphics_set, SHADOW)
end

-- Companion.lua's get_max_companions() reads this technology's level
-- directly (script-side, per-force) to grant +1 max companion per level --
-- see CLAUDE.md's "Equipment tier progression" section. That bonus has no
-- vanilla effect of its own, so without this the tech tree GUI would show
-- Defender/Bubblegum/Destroyer/+following-robots and nothing about
-- companions at all, even though researching it does grant one. Append a
-- purely cosmetic "nothing" modifier (type = "nothing") so the tooltip
-- actually reflects what this tech does for companions.
local follower_robot_count_5 = data.raw["technology"] and data.raw["technology"]["follower-robot-count-5"]
if follower_robot_count_5 then
    follower_robot_count_5.effects = follower_robot_count_5.effects or {}
    table.insert(follower_robot_count_5.effects,
    {
        type = "nothing",
        icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
        icon_size = 200,
        effect_description = {"technology-effect.companion-follower-robot-count-bonus"}
    })
end