local util                 = require("__core__/lualib/util")
local attach_beam_graphics = require("data/beam_sprites")
local recipes = {}

local bot = util.copy(data.raw["construction-robot"]["construction-robot"])
bot.name = "companion-construction-robot"
bot.localised_name = "Companion construction laser bank"
bot.max_payload_size = 5
bot.speed = 0.75
bot.max_speed = 0.8
bot.max_energy = "1000000MJ"
bot.energy_per_tick = "10J"
bot.speed_multiplier_when_out_of_energy = 1
bot.energy_per_move = "100J"
bot.min_to_charge = 0
bot.max_to_charge = 0
bot.working_sound = nil
bot.minable = {name = "fish", amount = 0, mining_time = 3}
bot.selection_box = {{-0.25,-0.25}, {0.25,0.25}}
bot.cargo_centered = {0, -1}
bot.selectable_in_game = false
bot.draw_cargo = true
bot.max_health = 9999999
bot.hidden = true

bot.idle = util.empty_sprite()
bot.idle_with_cargo = util.empty_sprite()
bot.in_motion = util.empty_sprite()
bot.in_motion_with_cargo = util.empty_sprite()
bot.shadow_idle = util.empty_sprite()
bot.shadow_idle_with_cargo = util.empty_sprite()
bot.shadow_in_motion = util.empty_sprite()
bot.shadow_in_motion_with_cargo = util.empty_sprite()
bot.working = util.empty_sprite()
bot.shadow_working = util.empty_sprite()
bot.sparks = util.empty_sprite()
bot.smoke = nil
bot.water_reflection = nil
bot.placeable_by =
{
  {item = "companion-construction-robot", count = 1}
}
bot.created_effect =
{
  type = "direct",
  action_delivery =
  {
    type = "instant",
    target_effects =
    {
      {
        type = "script",
        effect_id = "companion-robot-spawned"
      }
    }
  }
}

local bot_item =
{
  type = "item",
  name = "companion-construction-robot",
  icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
  icon_size = 200,
  subgroup = "logistic-network",
  order = "a[robot]-b[construction-robot]",
  place_result = "companion-construction-robot",
  stack_size = 500,
  hidden = true,
  flags = {"only-in-cursor"}
}



local item_category =
{
  type = "item-subgroup",
  name = "companion",
  group = "combat",
  order = "dea-hank"
}


local build_beam = util.copy(data.raw["beam"]["electric-beam-no-sound"])
build_beam.name = "companion-build-beam"
build_beam.action = nil
attach_beam_graphics(build_beam, nil, nil, {0, 1, 0}, {0, 1, 0})

local deconstruct_beam = util.copy(data.raw["beam"]["electric-beam-no-sound"])
deconstruct_beam.name = "companion-deconstruct-beam"
deconstruct_beam.action = nil
attach_beam_graphics(deconstruct_beam, nil, nil, {1, 0, 0}, {1, 0, 0})

local inserter_beam = util.copy(util.copy(data.raw["beam"]["laser-beam"]))
inserter_beam.name = "inserter-beam"
--inserter_beam.head = util.empty_sprite()
--inserter_beam.head.repeat_count = 8
--inserter_beam.head =
--{
--  filename = "__companion-drones-2-updated__/data//hr-fast-inserter-hand-closed.png",
--  priority = "extra-high",
--  width = 164,
--  height = 72,
--  scale = 0.25
--}
--inserter_beam.start = util.empty_sprite()
--inserter_beam.start.repeat_count = 8
--inserter_beam.body =
--{
--  filename = "__companion-drones-2-updated__/data//hr-fast-inserter-hand-base.png",
--  priority = "extra-high",
--  height = 32,
--  width = 136,
--  scale = 0.25
--}
--inserter_beam.tail = util.empty_sprite()
--inserter_beam.tail.repeat_count = 8
--inserter_beam.ending = util.empty_sprite()
--inserter_beam.ending.repeat_count = 8
--inserter_beam.light_animations = nil
inserter_beam.target_offset = {0, 0}
inserter_beam.random_target_offset = false
inserter_beam.working_sound = nil
inserter_beam.damage_interval = 9999999
inserter_beam.action_triggered_automatically = false
inserter_beam.action = nil

local scale = 0.6
local leg_scale = 1
local arguments = {name = "spidertron"}
local drone =
{
  type = "spider-vehicle",
  name = "companion",
  localised_name = {"companion"},
  collision_box = {{-1 * scale, -1 * scale}, {1 * scale, 1 * scale}},
  selection_box = {{-1 * scale, -1 * scale}, {1 * scale, 1 * scale}},
  drawing_box = {{-3 * scale, -4 * scale}, {3 * scale, 2 * scale}},
  icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
  icon_size = 200,
  mined_sound = {filename = "__core__/sound/deconstruct-large.ogg",volume = 0.8},
  open_sound = { filename = "__base__/sound/spidertron/spidertron-door-open.ogg", volume= 0.35 },
  close_sound = { filename = "__base__/sound/spidertron/spidertron-door-close.ogg", volume = 0.4 },
  sound_minimum_speed = 0.3,
  sound_scaling_ratio = 0.1,
  allow_passengers = false,
  is_military_target = true,
  working_sound =
  {
    sound =
    {
      filename = "__base__/sound/spidertron/spidertron-vox.ogg",
      volume = 0.35
    },
    activate_sound =
    {
      filename = "__base__/sound/spidertron/spidertron-activate.ogg",
      volume = 0.5
    },
    deactivate_sound =
    {
      filename = "__base__/sound/spidertron/spidertron-deactivate.ogg",
      volume = 0.5
    },
    match_speed_to_activity = true
  },
  weight = 1,
  braking_force = 1,
  friction_force = 1,
  flags = {"placeable-neutral", "player-creation", "placeable-off-grid"},
  collision_mask = { layers = { trigger_target = true }},
  minable = {result = "companion", mining_time = 1},
  max_health = 250,
  resistances =
  {
    {
      type = "fire",
      decrease = 15,
      percent = 60
    },
    {
      type = "physical",
      decrease = 15,
      percent = 60
    },
    {
      type = "impact",
      decrease = 50,
      percent = 80
    },
    {
      type = "explosion",
      decrease = 20,
      percent = 75
    },
    {
      type = "acid",
      decrease = 0,
      percent = 70
    },
    {
      type = "laser",
      decrease = 0,
      percent = 70
    },
    {
      type = "electric",
      decrease = 0,
      percent = 70
    }
  },
  --corpse = "spidertron-remnants",
  --dying_explosion = "spidertron-explosion",
  energy_per_hit_point = 4,
  guns = {},
  inventory_size = 21,
  equipment_grid = "companion-equipment-grid",
  trash_inventory_size = 0,
  height = 2,
  torso_rotation_speed = 0.05,
  chunk_exploration_radius = 3,
  selection_priority = 45,
  graphics_set = spidertron_torso_graphics_set(0.6),
  base_render_layer = "smoke",
  render_layer = "air-object",
  energy_source =
  {
    type = "burner",
    fuel_categories = {"chemical"},
    effectivity = 0.25,
    fuel_inventory_size = 3,
    smoke =
    {
      {
        name = "train-smoke",
        deviation = {0.3, 0.3},
        frequency = 100,
        position = {0, 0},
        starting_frame = 0,
        starting_frame_deviation = 60,
        height = 0,
        height_deviation = 0.8,
        starting_vertical_speed = -0.2,
        starting_vertical_speed_deviation = 0.2
      }
    }
  },
  movement_energy_consumption = "100kW",
  automatic_weapon_cycling = true,
  chain_shooting_cooldown_modifier = 0.5,
  spider_engine =
  {
    legs =
    {
       { -- 1
         leg = "companion-leg",
         mount_position = {0, -1},
         ground_position = {0, -1},
         walking_group = 1,
         leg_hit_the_ground_trigger = nil
       }
    },
    military_target = "spidertron-military-target"
  },

  minimap_representation =
  {
    filename = "__companion-drones-2-updated__/sprites/drone-map.png",
    flags = {"icon"},
    size = {128, 128},
    scale = 0.25
  }

}
drone.graphics_set.render_layer = "air-entity-info-icon"
drone.graphics_set.base_render_layer = "air-object"
drone.graphics_set.autopilot_path_visualisation_line_width = 0
drone.graphics_set.autopilot_path_visualisation_on_map_line_width = 0
drone.graphics_set.autopilot_destination_visualisation = util.empty_sprite()
drone.graphics_set.autopilot_destination_queue_on_map_visualisation = util.empty_sprite()
drone.graphics_set.autopilot_destination_on_map_visualisation = util.empty_sprite()
drone.graphics_set.light =
{
  {
    type = "oriented",
    minimum_darkness = 0.3,
    picture =
    {
      filename = "__core__/graphics/light-cone.png",
      priority = "extra-high",
      flags = { "light" },
      scale = 1,
      width = 200,
      height = 200,
      shift = {0, -1}
    },
    source_orientation_offset = 0,
    shift = {0, (-200/32)- 0.5},
    add_perspective = false,
    size = 2,
    intensity = 0.6,
    color = {r = 0.92, g = 0.77, b = 0.3}
  }
}
drone.graphics_set.eye_light.size = 0

local leg =
{
  type = "spider-leg",
  name = "companion-leg",

  localised_name = {"entity-name.spidertron-leg"},
  collision_box = nil,
  collision_mask = { layers = {}},
  selection_box = {{-0, -0}, {0, 0}},
  icon = "__base__/graphics/icons/spidertron.png",
  icon_size = 64, icon_mipmaps = 4,
  walking_sound_volume_modifier = 0,
  target_position_randomisation_distance = 0,
  minimal_step_size = 0,
  working_sound = nil,
  part_length = 1000000000,
  initial_movement_speed = 100,
  movement_acceleration = 100,
  max_health = 100,
  knee_height = 0,
  knee_distance_factor = 2,
  base_position_selection_distance = 1,
  movement_based_position_selection_distance = 3,
  selectable_in_game = false,
  graphics_set = create_spidertron_leg_graphics_set(0, 1)
}

for x, field in pairs(leg.graphics_set) do
  leg.graphics_set[x] = nil
end

local drone_item =
{
  type = "item-with-entity-data",
  name = "companion",
  icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
  icon_tintable = "__companion-drones-2-updated__/sprites/drone-icon-tintable.png",
  icon_tintable_mask = "__companion-drones-2-updated__/sprites/drone-icon-mask.png",
  icon_size = 200,
  subgroup = "companion",

  order = "a",
  stack_size = 1,
  place_result = "companion"
}

-- NOTE: no damage_modifier parameter here on purpose. The actual damage
-- dealt per shot is NOT read from this prototype's attack_parameters -- the
-- ammo_type's action is type="script" (effect_id "companion-attack"),
-- which hands off entirely to Companion:attack() in companion.lua. Per-tier
-- damage scaling lives in that script's defense_tier_projectile_count
-- table, not here. cooldown/range below ARE real (vanilla uses them to
-- decide when/how far this equipment auto-fires).
local function make_defense_equipment(tier, cooldown, range, energy_consumption, buffer_capacity)
  local name = "companion-defense-mk" .. tier
  return
  {
    type = "active-defense-equipment",
    name = name,
    localised_name = {"item-name." .. name},
    take_result = name,
    sprite =
    {
      filename = "__base__/graphics/equipment/personal-laser-defense-equipment.png",
      width = 128,
      height = 128,
      priority = "medium",
      scale = 0.5
    },
    shape =
    {
      width = 2,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      buffer_capacity = buffer_capacity
    },

    attack_parameters =
    {
      type = "beam",
      warmup = 20,
      cooldown = cooldown,
      cooldown_deviation = 0.5,
      range = range,
      ammo_category = "laser",
      ammo_type =
      {
        category = "laser",
        energy_consumption = energy_consumption,
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "instant",
            target_effects =
            {
              type = "script",
              effect_id = "companion-attack"
            }
          }
        },
      }
    },

    automatic = true,
    categories = {"companion"}
  }
end

local function make_defense_item(tier, order)
  local name = "companion-defense-mk" .. tier
  return
  {
    type = "item",
    name = name,
    localised_name = {"item-name." .. name},
    icons =
    {
      {
        icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
        icon_size = 200
      },
      {
        icon = "__base__/graphics/equipment/personal-laser-defense-equipment.png",
        icon_size = 64,
        scale = 0.333,
      },
    },
    place_as_equipment_result = name,
    subgroup = "companion",
    order = order,
    default_request_amount = 1,
    stack_size = 20
  }
end

-- range matches vanilla worm attack range minus 2 tiles (small/medium/big/behemoth:
-- 25/30/38/48, see enemy-constants.lua) so the companion always stays within range
-- of the worm tier it's meant to fight, instead of safely outranging it.
local companion_defense_mk1 = make_defense_equipment(1, 30, 23, "0.7kJ", "0.5MJ")
local companion_defense_mk2 = make_defense_equipment(2, 24, 28, "1kJ", "1MJ")
local companion_defense_mk3 = make_defense_equipment(3, 18, 36, "1.5kJ", "1.5MJ")
local companion_defense_mk4 = make_defense_equipment(4, 14, 46, "2kJ", "2MJ")

local companion_defense_item_mk1 = make_defense_item(1, "d[mk1]")
local companion_defense_item_mk2 = make_defense_item(2, "d[mk2]")
local companion_defense_item_mk3 = make_defense_item(3, "d[mk3]")
local companion_defense_item_mk4 = make_defense_item(4, "d[mk4]")

local plasma_projectile =
{
  type = "projectile",
  name = "companion-projectile",
  icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
  icon_size = 200,
  flags = {"not-on-map"},
  subgroup = "explosions",
  height = 1.4,
  rotatable = true,
  animation = nil,
  acceleration = 0.005,
  max_speed = 0.5,
  turn_speed = 0.001,
  turning_speed_increases_exponentially_with_projectile_speed = true,
  collision_box = {{-0.1, -0.1},{0.1, 0.1}},
  speed_modifier = {1, 0.707},
  hit_at_collision_position = true,
  force_condition = "enemy",
  action =
  {
    type = "direct",
    action_delivery =
    {
      type = "instant",
      target_effects =
      {
        {
          type = "create-entity",
          entity_name = "explosion"
        },
        {
          type = "damage",
          damage = {amount = 5, type = "laser"}
        }, 
      }
    }
  },
}

local companion_grid =
{
  type = "equipment-grid",
  name = "companion-equipment-grid",
  width = 10,
  height = 2,
  equipment_categories = {"companion" }
}


local companion_shield_mk1 = {
    type = "energy-shield-equipment",
    name = "companion-shield-mk1",
    localised_name = {"item-name.companion-shield-mk1"},
    sprite = {
        filename = "__base__/graphics/equipment/energy-shield-equipment.png",
        width = 128,
        height = 128,
        priority = "medium",
        scale = 0.5
    },
    shape = {
        width = 2,
        height = 2,
        type = "full"
    },
    -- max_shield_value is sized as roughly 4x the matching-tier worm's
    -- stream damage (see enemy-constants.lua: small/medium/big/behemoth
    -- worm = 36/48/72/96), then rounded to the nearest 50, so a solo
    -- shield takes ~4 raw hits to break (fewer after the companion's own
    -- 70% acid resistance is factored in -- see CLAUDE.md). This also caps
    -- the worst case: Factorio sums equipment stats additively across
    -- multiple copies of the same equipment in one grid, so an earlier,
    -- much higher-capacity design let a stacked multi-shield loadout
    -- become nearly unkillable.
    max_shield_value = 150,
    energy_source = {
        type = "electric",
        buffer_capacity = "150kJ",
        input_flow_limit = "20kW",
        usage_priority = "primary-input"
    },
    -- energy_per_shield chosen so a full recharge from empty takes ~20s
    -- uniformly across tiers (rate = max_shield_value / 20s), instead of
    -- the earlier per-tier rates that recharged in as little as ~2s at
    -- mk4 -- fast enough that the shield would nearly fully heal between
    -- hits in a real fight, making the on-paper capacity above misleading.
    energy_per_shield = "2.67kJ",
    categories = {"companion"}
}

local companion_shield_mk2 = util.table.deepcopy(companion_shield_mk1)
companion_shield_mk2.name = "companion-shield-mk2"
companion_shield_mk2.localised_name = {"item-name.companion-shield-mk2"}
companion_shield_mk2.max_shield_value = 200
companion_shield_mk2.energy_source.buffer_capacity = "400kJ"
companion_shield_mk2.energy_source.input_flow_limit = "50kW"
companion_shield_mk2.energy_per_shield = "5kJ"

local companion_shield_mk3 = util.table.deepcopy(companion_shield_mk1)
companion_shield_mk3.name = "companion-shield-mk3"
companion_shield_mk3.localised_name = {"item-name.companion-shield-mk3"}
companion_shield_mk3.max_shield_value = 300
companion_shield_mk3.energy_source.buffer_capacity = "1MJ"
companion_shield_mk3.energy_source.input_flow_limit = "120kW"
companion_shield_mk3.energy_per_shield = "8kJ"

local companion_shield_mk4 = util.table.deepcopy(companion_shield_mk1)
companion_shield_mk4.name = "companion-shield-mk4"
companion_shield_mk4.localised_name = {"item-name.companion-shield-mk4"}
companion_shield_mk4.max_shield_value = 400
companion_shield_mk4.energy_source.buffer_capacity = "2.2MJ"
companion_shield_mk4.energy_source.input_flow_limit = "260kW"
companion_shield_mk4.energy_per_shield = "13kJ"

local companion_shield_item_mk1 = {
    type = "item",
    name = "companion-shield-mk1",
    localised_name = {"item-name.companion-shield-mk1"},
    icons = {
        {
            icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
            icon_size = 200
        },
        {
            icon = "__base__/graphics/equipment/energy-shield-equipment.png",
            icon_size = 64,
            scale = 0.333,
        }
    },
    place_as_equipment_result = "companion-shield-mk1",
    subgroup = "companion",
    order = "e[mk1]",
    default_request_amount = 1,
    stack_size = 20
}

local companion_shield_item_mk2 = util.table.deepcopy(companion_shield_item_mk1)
companion_shield_item_mk2.name = "companion-shield-mk2"
companion_shield_item_mk2.localised_name = {"item-name.companion-shield-mk2"}
companion_shield_item_mk2.place_as_equipment_result = "companion-shield-mk2"
companion_shield_item_mk2.order = "e[mk2]"

local companion_shield_item_mk3 = util.table.deepcopy(companion_shield_item_mk1)
companion_shield_item_mk3.name = "companion-shield-mk3"
companion_shield_item_mk3.localised_name = {"item-name.companion-shield-mk3"}
companion_shield_item_mk3.place_as_equipment_result = "companion-shield-mk3"
companion_shield_item_mk3.order = "e[mk3]"

local companion_shield_item_mk4 = util.table.deepcopy(companion_shield_item_mk1)
companion_shield_item_mk4.name = "companion-shield-mk4"
companion_shield_item_mk4.localised_name = {"item-name.companion-shield-mk4"}
companion_shield_item_mk4.place_as_equipment_result = "companion-shield-mk4"
companion_shield_item_mk4.order = "e[mk4]"

local companion_roboport_mk1 = {
    type = "roboport-equipment",
    name = "companion-roboport-mk1",
    localised_name = {"item-name.companion-roboport-mk1"},
    sprite = {
        filename = "__base__/graphics/equipment/personal-roboport-equipment.png",
        width = 128,
        height = 128,
        priority = "medium",
        scale = 0.5
    },
    shape = {
        width = 2,
        height = 2,
        type = "full"
    },
    energy_source = {
        type = "electric",
        buffer_capacity = "20MJ",
        input_flow_limit = "200kW",
        usage_priority = "secondary-input",
    },
    charging_energy = "80kW",
    spawn_minimum = "0W",
    robot_limit = 5,
    -- Factorio sums equipment stats additively across multiple copies of the
    -- same equipment in one grid, including construction_radius -- there's
    -- no diminishing return. These per-unit values are deliberately small so
    -- that even a worst-case stack of 4 same-tier roboports (using 4 of the
    -- companion's 5 equipment slots) tops out at 2 chunks (64 tiles):
    -- mk1=4x4=16, mk2=4x8=32, mk3=4x12=48, mk4=4x16=64.
    construction_radius = 4,
    draw_construction_radius_visualization = false,
    spawn_and_station_height = 1,
    spawn_and_station_shadow_height_offset = 0,
    charge_approach_distance = 2.6,
    robots_shrink_when_entering_and_exiting = true,
    recharging_animation = {
        filename = "__base__/graphics/entity/roboport/roboport-recharging.png",
        priority = "high",
        width = 37,
        height = 35,
        frame_count = 16,
        scale = 1.5,
        animation_speed = 0.5
    },
    recharging_light = {intensity = 0.3, size = 3},
    stationing_offset = {0, -2},
    charging_station_shift = {0, -2},
    charging_station_count = 1,
    charging_distance = 0,
    charging_threshold_distance = 0,
    robot_vertical_acceleration = 7,
    categories = {"companion"}
}

local companion_roboport_mk2 = util.table.deepcopy(companion_roboport_mk1)
companion_roboport_mk2.name = "companion-roboport-mk2"
companion_roboport_mk2.localised_name = {"item-name.companion-roboport-mk2"}
companion_roboport_mk2.energy_source.buffer_capacity = "50MJ"
companion_roboport_mk2.energy_source.input_flow_limit = "500kW"
companion_roboport_mk2.charging_energy = "250kW"
companion_roboport_mk2.robot_limit = 10
companion_roboport_mk2.construction_radius = 8
companion_roboport_mk2.charging_station_count = 2
companion_roboport_mk2.recharging_light = {intensity = 0.4, size = 4}
companion_roboport_mk2.robot_vertical_acceleration = 10

local companion_roboport_mk3 = util.table.deepcopy(companion_roboport_mk1)
companion_roboport_mk3.name = "companion-roboport-mk3"
companion_roboport_mk3.localised_name = {"item-name.companion-roboport-mk3"}
companion_roboport_mk3.energy_source.buffer_capacity = "120MJ"
companion_roboport_mk3.energy_source.input_flow_limit = "1MW"
companion_roboport_mk3.charging_energy = "600kW"
companion_roboport_mk3.robot_limit = 20
companion_roboport_mk3.construction_radius = 12
companion_roboport_mk3.charging_station_count = 4
companion_roboport_mk3.recharging_light = {intensity = 0.6, size = 5}
companion_roboport_mk3.robot_vertical_acceleration = 15

local companion_roboport_mk4 = util.table.deepcopy(companion_roboport_mk1)
companion_roboport_mk4.name = "companion-roboport-mk4"
companion_roboport_mk4.localised_name = {"item-name.companion-roboport-mk4"}
companion_roboport_mk4.energy_source.buffer_capacity = "250MJ"
companion_roboport_mk4.energy_source.input_flow_limit = "2MW"
companion_roboport_mk4.charging_energy = "1.2MW"
companion_roboport_mk4.robot_limit = 30
companion_roboport_mk4.construction_radius = 16
companion_roboport_mk4.charging_station_count = 4
companion_roboport_mk4.recharging_light = {intensity = 0.8, size = 6}
companion_roboport_mk4.robot_vertical_acceleration = 18

local companion_roboport_item_mk1 = {
    type = "item",
    name = "companion-roboport-mk1",
    localised_name = {"item-name.companion-roboport-mk1"},
    icons = {
        {
            icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
            icon_size = 200
        },
        {
            icon = "__base__/graphics/equipment/personal-roboport-equipment.png",
            icon_size = 64,
            scale = 0.333,
        }
    },
    place_as_equipment_result = "companion-roboport-mk1",
    subgroup = "companion",
    order = "f[mk1]",
    default_request_amount = 1,
    stack_size = 20
}

local companion_roboport_item_mk2 = util.table.deepcopy(companion_roboport_item_mk1)
companion_roboport_item_mk2.name = "companion-roboport-mk2"
companion_roboport_item_mk2.localised_name = {"item-name.companion-roboport-mk2"}
companion_roboport_item_mk2.place_as_equipment_result = "companion-roboport-mk2"
companion_roboport_item_mk2.order = "f[mk2]"

local companion_roboport_item_mk3 = util.table.deepcopy(companion_roboport_item_mk1)
companion_roboport_item_mk3.name = "companion-roboport-mk3"
companion_roboport_item_mk3.localised_name = {"item-name.companion-roboport-mk3"}
companion_roboport_item_mk3.place_as_equipment_result = "companion-roboport-mk3"
companion_roboport_item_mk3.order = "f[mk3]"

local companion_roboport_item_mk4 = util.table.deepcopy(companion_roboport_item_mk1)
companion_roboport_item_mk4.name = "companion-roboport-mk4"
companion_roboport_item_mk4.localised_name = {"item-name.companion-roboport-mk4"}
companion_roboport_item_mk4.place_as_equipment_result = "companion-roboport-mk4"
companion_roboport_item_mk4.order = "f[mk4]"

local battery =
{
  type = "battery-equipment",
  name = "companion-battery-equipment",
  sprite =
  {
    filename = "__base__/graphics/equipment/battery-equipment.png",
    width = 64,
    height = 128,
    priority = "medium",
    scale = 0.5
  },
  shape =
  {
    width = 1,
    height = 2,
    type = "full"
  },
  energy_source =
  {
    type = "electric",
    buffer_capacity = "20000MJ",
    usage_priority = "tertiary"
  },
  categories = {"companion"}
}

local battery_item =
{
  type = "item",
  name = "companion-battery-equipment",
  icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
  icon_size = 200,
  place_as_equipment_result = "companion-battery-equipment",
  subgroup = "companion",
  order = "e[robotics]-a[personal-roboport-equipment]",
  default_request_amount = 1,
  stack_size = 20
}

local category =
{
  type = "equipment-category",
  name = "companion"
}


local function make_reactor_equipment(tier, power)
  local name = "companion-reactor-mk" .. tier
  return
  {
    type = "generator-equipment",
    name = name,
    localised_name = {"item-name." .. name},
    take_result = name,
    sprite =
    {
      filename = "__base__/graphics/equipment/fission-reactor-equipment.png",
      width = 256,
      height = 256,
      priority = "medium",
      scale = 0.25
    },
    shape =
    {
      width = 2,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "primary-output"
    },
    power = power,
    categories = {"companion"}
  }
end

local function make_reactor_item(tier, order)
  local name = "companion-reactor-mk" .. tier
  return
  {
    type = "item",
    name = name,
    localised_name = {"item-name." .. name},
    icons =
    {
      {
        icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
        icon_size = 200
      },
      {
        icon = "__base__/graphics/equipment/fission-reactor-equipment.png",
        icon_size = 128,
        scale = 0.333 * 0.5,
      }
    },
    place_as_equipment_result = name,
    subgroup = "companion",
    order = order,
    default_request_amount = 1,
    stack_size = 20
  }
end

local companion_reactor_mk1 = make_reactor_equipment(1, "0.5MW")
local companion_reactor_mk2 = make_reactor_equipment(2, "1MW")
local companion_reactor_mk3 = make_reactor_equipment(3, "1.8MW")
local companion_reactor_mk4 = make_reactor_equipment(4, "3MW")

local companion_reactor_item_mk1 = make_reactor_item(1, "b[mk1]")
local companion_reactor_item_mk2 = make_reactor_item(2, "b[mk2]")
local companion_reactor_item_mk3 = make_reactor_item(3, "b[mk3]")
local companion_reactor_item_mk4 = make_reactor_item(4, "b[mk4]")

local function equipment_recipe(name, enabled, energy_required, ingredients)
  return
  {
    type = "recipe",
    name = name,
    enabled = enabled,
    energy_required = energy_required,
    ingredients = ingredients,
    results = {{type="item", name=name, amount=1}}
  }
end

recipes =
    {
      {
        type = "recipe",
        name = "companion",
        enabled = true,
        energy_required = 20,
        ingredients =
        {
          {type="item", name="electronic-circuit", amount=200},
          {type="item", name="copper-plate", amount=50},
          {type="item", name="iron-plate", amount=100},
          {type="item", name="raw-fish", amount=1}
        },
        results =
        {
          {type="item", name="companion", amount=1}
        }
      },

      -- mk1: cheap, craftable from the start, no research required. Uses
      -- electronic-circuit (green board) and iron-plate/coal -- the
      -- absolute starter-pack basics, deliberately no steel-plate or
      -- solid-fuel (those are mk2+ material tiers). Craft time is 20s
      -- across all mk1 recipes, +5s per subsequent tier (25/30/35 for
      -- mk2/mk3/mk4) -- a deliberately flat curve, not the steep per-tier
      -- jump an earlier draft used.
      equipment_recipe("companion-reactor-mk1", true, 20,
        {
          {type="item", name="electronic-circuit", amount=50},
          {type="item", name="iron-plate", amount=100},
          {type="item", name="copper-plate", amount=100},
          {type="item", name="coal", amount=50}
        }),
      equipment_recipe("companion-shield-mk1", true, 20,
        {
          {type="item", name="electronic-circuit", amount=50},
          {type="item", name="iron-plate", amount=200},
          {type="item", name="copper-plate", amount=100}
        }),
      equipment_recipe("companion-roboport-mk1", true, 20,
        {
          {type="item", name="electronic-circuit", amount=50},
          {type="item", name="iron-plate", amount=100},
          {type="item", name="copper-plate", amount=200}
        }),
      equipment_recipe("companion-defense-mk1", true, 20,
        {
          {type="item", name="electronic-circuit", amount=70},
          {type="item", name="copper-plate", amount=200},
          {type="item", name="iron-plate", amount=100}
        }),

      -- mk2: the loadout the starting companion spawns with, but only
      -- craftable once companion-equipment-mk2 is researched. Same
      -- ingredient types as mk1 -- this mod's own research gate is what's
      -- actually new here, not a material-tier jump yet -- but the
      -- circuit board amount doubles every tier (see mk3/mk4 below), while
      -- the rest scales 1.5x.
      equipment_recipe("companion-reactor-mk2", false, 25,
        {
          {type="item", name="advanced-circuit", amount=100},
          {type="item", name="steel-plate", amount=150},
          {type="item", name="copper-plate", amount=150},
          {type="item", name="solid-fuel", amount=75}
        }),
      equipment_recipe("companion-shield-mk2", false, 25,
        {
          {type="item", name="advanced-circuit", amount=100},
          {type="item", name="steel-plate", amount=300},
          {type="item", name="battery", amount=150}
        }),
      equipment_recipe("companion-roboport-mk2", false, 25,
        {
          {type="item", name="advanced-circuit", amount=100},
          {type="item", name="steel-plate", amount=150},
          {type="item", name="copper-plate", amount=300}
        }),
      equipment_recipe("companion-defense-mk2", false, 25,
        {
          {type="item", name="advanced-circuit", amount=140},
          {type="item", name="copper-plate", amount=300},
          {type="item", name="battery", amount=300}
        }),

      -- mk3: unlocked by companion-equipment-mk3 (production-science-pack
      -- tier) -- this is where the material tier actually steps up:
      -- processing-unit instead of advanced-circuit, rocket-fuel instead
      -- of solid-fuel, flying-robot-frame (an actual construction/logistic
      -- robot part) added to the roboport/laser, and low-density-structure
      -- (a genuinely late-game item, otherwise mostly seen on rocket
      -- silos/space platforms) so mk3/mk4 don't just mean "more steel and
      -- copper". The circuit board switches type here (advanced-circuit ->
      -- processing-unit) so its amount carries over unchanged rather than
      -- doubling again -- the doubling resumes at mk3->mk4.
      equipment_recipe("companion-reactor-mk3", false, 30,
        {
          {type="item", name="processing-unit", amount=100},
          {type="item", name="steel-plate", amount=150},
          {type="item", name="copper-plate", amount=150},
          {type="item", name="low-density-structure", amount=15},
          {type="item", name="rocket-fuel", amount=30}
        }),
      equipment_recipe("companion-shield-mk3", false, 30,
        {
          {type="item", name="processing-unit", amount=100},
          {type="item", name="steel-plate", amount=300},
          {type="item", name="low-density-structure", amount=20},
          {type="item", name="battery", amount=200},
          {type="item", name="energy-shield-equipment", amount=1}
        }),
      equipment_recipe("companion-roboport-mk3", false, 30,
        {
          {type="item", name="processing-unit", amount=100},
          {type="item", name="steel-plate", amount=150},
          {type="item", name="copper-plate", amount=300},
          {type="item", name="low-density-structure", amount=15},
          {type="item", name="flying-robot-frame", amount=15}
        }),
      equipment_recipe("companion-defense-mk3", false, 30,
        {
          {type="item", name="processing-unit", amount=140},
          {type="item", name="copper-plate", amount=300},
          {type="item", name="low-density-structure", amount=15},
          {type="item", name="battery", amount=400},
          {type="item", name="flying-robot-frame", amount=10}
        }),

      -- mk4: unlocked by companion-equipment-mk4 (utility-science-pack
      -- tier) -- nuclear-fuel for the reactor (the top fuel tier), more
      -- low-density-structure/flying-robot-frame for the rest. Circuit
      -- board amount doubles again from mk3 (processing-unit stays the
      -- same type, so the doubling rule applies normally here).
      equipment_recipe("companion-reactor-mk4", false, 35,
        {
          {type="item", name="processing-unit", amount=200},
          {type="item", name="steel-plate", amount=175},
          {type="item", name="copper-plate", amount=175},
          {type="item", name="low-density-structure", amount=35},
          {type="item", name="nuclear-fuel", amount=10}
        }),
      equipment_recipe("companion-shield-mk4", false, 35,
        {
          {type="item", name="processing-unit", amount=200},
          {type="item", name="steel-plate", amount=350},
          {type="item", name="low-density-structure", amount=45},
          {type="item", name="battery", amount=250},
          {type="item", name="energy-shield-mk2-equipment", amount=1}
        }),
      equipment_recipe("companion-roboport-mk4", false, 35,
        {
          {type="item", name="processing-unit", amount=200},
          {type="item", name="steel-plate", amount=175},
          {type="item", name="copper-plate", amount=350},
          {type="item", name="low-density-structure", amount=35},
          {type="item", name="flying-robot-frame", amount=30}
        }),
      equipment_recipe("companion-defense-mk4", false, 35,
        {
          {type="item", name="processing-unit", amount=280},
          {type="item", name="copper-plate", amount=350},
          {type="item", name="low-density-structure", amount=35},
          {type="item", name="battery", amount=500},
          {type="item", name="flying-robot-frame", amount=20}
        })
    }

data:extend(recipes)

local companion_equipment_tech_icon =
{
  icon = "__companion-drones-2-updated__/sprites/drone-icon.png",
  icon_size = 200
}

data:extend
{
  {
    type = "technology",
    name = "companion-equipment-mk2",
    icons = {companion_equipment_tech_icon},
    effects =
    {
      {type = "unlock-recipe", recipe = "companion-reactor-mk2"},
      {type = "unlock-recipe", recipe = "companion-shield-mk2"},
      {type = "unlock-recipe", recipe = "companion-roboport-mk2"},
      {type = "unlock-recipe", recipe = "companion-defense-mk2"}
    },
    prerequisites = {"chemical-science-pack"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"military-science-pack", 1},
        {"chemical-science-pack", 1}
      },
      time = 30
    }
  },
  {
    type = "technology",
    name = "companion-equipment-mk3",
    icons = {companion_equipment_tech_icon},
    effects =
    {
      {type = "unlock-recipe", recipe = "companion-reactor-mk3"},
      {type = "unlock-recipe", recipe = "companion-shield-mk3"},
      {type = "unlock-recipe", recipe = "companion-roboport-mk3"},
      {type = "unlock-recipe", recipe = "companion-defense-mk3"}
    },
    prerequisites = {"companion-equipment-mk2", "production-science-pack"},
    unit =
    {
      count = 250,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"military-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1}
      },
      time = 30
    }
  },
  {
    type = "technology",
    name = "companion-equipment-mk4",
    icons = {companion_equipment_tech_icon},
    effects =
    {
      {type = "unlock-recipe", recipe = "companion-reactor-mk4"},
      {type = "unlock-recipe", recipe = "companion-shield-mk4"},
      {type = "unlock-recipe", recipe = "companion-roboport-mk4"},
      {type = "unlock-recipe", recipe = "companion-defense-mk4"}
    },
    prerequisites = {"companion-equipment-mk3", "utility-science-pack"},
    unit =
    {
      count = 600,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"military-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 30
    }
  }
}

local speed_sticker =
{
    type = "sticker",
    name = "speed-sticker",
    flags = {"not-on-map"},
    animation = util.empty_sprite(),
    duration_in_ticks = 100,
    target_movement_modifier_from = 1,
    target_movement_modifier_to   = 1,
    vehicle_speed_modifier_from   = 10,
    vehicle_speed_modifier_to     = 1,
    vehicle_friction_modifier_from = 1,
    vehicle_friction_modifier_to   = 1,
}

local speed_flame =
{
    type = "animation",
    name = "companion-speed-flame",
    filename        = "__companion-drones-2-updated__/sprites/10-jet-flame.png",
    width           = 172,
    height          = 256,
    frame_count     = 8,
    line_length     = 8,
    animation_speed = 0.5,
    scale           = 1.13 / 8,
    shift           = util.by_pixel(-0.5, 20),
    render_layer    = "air-object",
}

local attack_icon =
{
  filename = "__companion-drones-2-updated__/sprites/drone-attack-shortcut.png",
  priority = "extra-high-no-scale",
  size = 200,
  scale = 1,
  flags = {"icon"},
}

local attack_icon_disabled =
{
  filename = "__companion-drones-2-updated__/sprites/drone-attack-shortcut-disabled.png",
  priority = "extra-high-no-scale",
  size = 200,
  scale = 1,
  flags = {"icon"},
}

local attack_shortcut =
{
  type = "shortcut",
  name = "companion-attack-toggle",
  localised_name = {"companion-attack-toggle"},
  order = "a[companion-drones]",
  action = "lua",
  style = "default",
  icon = "__companion-drones-2-updated__/sprites/drone-attack-shortcut.png",
  icon_size = 200,
  small_icon = "__companion-drones-2-updated__/sprites/drone-attack-shortcut.png",
  small_icon_size = 200,
  toggleable = true
}


local construct_icon =
{
  filename = "__companion-drones-2-updated__/sprites/drone-construction-shortcut.png",
  priority = "extra-high-no-scale",
  size = 200,
  scale = 1,
  flags = {"icon"},
}

local construct_icon_disabled =
{
  filename = "__companion-drones-2-updated__/sprites/drone-construction-shortcut-disabled.png",
  priority = "extra-high-no-scale",
  size = 200,
  scale = 1,
  flags = {"icon"},
}

local construct_shortcut =
{
  type = "shortcut",
  name = "companion-construction-toggle",
  localised_name = {"companion-construction-toggle"},
  order = "a[companion-drones]",
  action = "lua",
  style = "default",
  icon = "__companion-drones-2-updated__/sprites/drone-construction-shortcut.png",
  icon_size = 200,
  small_icon = "__companion-drones-2-updated__/sprites/drone-construction-shortcut.png",
  small_icon_size = 200,
  toggleable = true
}

data:extend
{

  item_category,
  --build_beam,
  --deconstruct_beam,
  inserter_beam,
  drone,
  drone_item,
  leg,
  plasma_projectile,
  companion_grid,
  --battery,
  --battery_item,
  bot,
  bot_item,
  category,
  speed_sticker,
  speed_flame,
  attack_shortcut,
  construct_shortcut,
  companion_shield_mk1,
  companion_shield_mk2,
  companion_shield_mk3,
  companion_shield_mk4,
  companion_roboport_mk1,
  companion_roboport_mk2,
  companion_roboport_mk3,
  companion_roboport_mk4,
  companion_shield_item_mk1,
  companion_shield_item_mk2,
  companion_shield_item_mk3,
  companion_shield_item_mk4,
  companion_roboport_item_mk1,
  companion_roboport_item_mk2,
  companion_roboport_item_mk3,
  companion_roboport_item_mk4,
  companion_defense_mk1,
  companion_defense_mk2,
  companion_defense_mk3,
  companion_defense_mk4,
  companion_defense_item_mk1,
  companion_defense_item_mk2,
  companion_defense_item_mk3,
  companion_defense_item_mk4,
  companion_reactor_mk1,
  companion_reactor_mk2,
  companion_reactor_mk3,
  companion_reactor_mk4,
  companion_reactor_item_mk1,
  companion_reactor_item_mk2,
  companion_reactor_item_mk3,
  companion_reactor_item_mk4
}

data:extend{ -- Keybinds to toggle construction or attack mode
    {
        type = "custom-input",
        name = "companion-construction-hotkey",
        key_sequence = "",
        consuming = "none",
        order = "a[companion]-a[construction]",
        localised_description = {"commands.companion-construction-hotkey"}
    },
    {
        type = "custom-input",
        name = "companion-attack-hotkey",
        key_sequence = "",
        consuming = "none",
        order = "a[companion]-b[attack]",
        localised_description = {"commands.companion-attack-hotkey"}
    },
    {
        type = "custom-input",
        name = "companion-force-search",
        key_sequence = "",
        consuming = "none",
        order = "a[companion]-c[force-search]",
        localised_description = {"commands.companion-force-search"}
    }
}