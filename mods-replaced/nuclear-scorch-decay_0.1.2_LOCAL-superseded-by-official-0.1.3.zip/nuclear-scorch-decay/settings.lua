data:extend{
    {
        type = "int-setting",
        name = "nuclear-scorch-decay-operation-interval",
        setting_type = "startup",
        default_value = 10,
        minimum_value = 1,
        order = "a"
    },
    {
        type = "string-setting",
        name = "nuclear-scorch-decay-chunk-selection-method",
        setting_type = "runtime-global",
        default_value = "random",
        allowed_values = {
            "random",
            "sequential"
        },
        order = "a"
    },
    {
        type = "int-setting",
        name = "nuclear-scorch-decay-chunk-subdivisions",
        setting_type = "runtime-global",
        default_value = 2,
        minimum_value = 1,
        order = "b"
    },
    {
        type = "bool-setting",
        name = "nuclear-scorch-decay-mark-active-chunk",
        setting_type = "runtime-global",
        default_value = false,
        order = "c"
    }
}