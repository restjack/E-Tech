--control.lua

--#region - settings
local operation_interval = settings.startup["nuclear-scorch-decay-operation-interval"].value
local chunk_selection_method = settings.global["nuclear-scorch-decay-chunk-selection-method"].value
local chunk_subdivisions = settings.global["nuclear-scorch-decay-chunk-subdivisions"].value
local mark_on_map = settings.global["nuclear-scorch-decay-mark-active-chunk"].value
--#endregion

--#region - definitions
local nuclear_tile_types = {
    "nuclear-ground"
}

local nuclear_secondary_decal_types = {
    "nuclear-ground-patch"
}

local function list_surfaces()
    local surface_names = {}
    for name, _ in pairs(game.surfaces) do
        surface_names[#surface_names+1] = name
    end
    return surface_names
end

local function get_chunk()
    local surface = nil -- set as local here and modify lower down to avoid lua scope weirdness
    local chunk = nil 

    if chunk_selection_method == "random" then
        storage.surfaces = list_surfaces()

        repeat
            surface = game.surfaces[storage.surfaces[math.random(1,#storage.surfaces)]]
        until surface.get_chunks()() ~= nil

        chunk = surface.get_random_chunk()

        -- deleting chunk iterators to make sure up-to-date ones are used when switching back to sequential
        if storage.chunk_iterators ~= {} then
            storage.chunk_iterators = {}
            storage.surfaces = {}
        end

    elseif chunk_selection_method == "sequential" then
        local surface_name = nil

        repeat
            if #storage.surfaces == 0 then
                storage.surfaces = list_surfaces()
            end
            surface_name = storage.surfaces[1]
            surface = game.surfaces[surface_name]
            table.remove(storage.surfaces,1)
        until surface.get_chunks()() ~= nil

        -- fresh chunk iterator if one doesn't exist of if existing one is invalid
        if (storage.chunk_iterators[surface_name]==nil) or (not storage.chunk_iterators[surface_name].valid) then
            storage.chunk_iterators[surface_name] = surface.get_chunks()
            chunk = storage.chunk_iterators[surface_name]()
        else
            chunk = storage.chunk_iterators[surface_name]()
            -- fresh chunk / chunk iterator if it returned nil (i.e. we've reached end of chunks)
            if chunk==nil then
                storage.chunk_iterators[surface_name] = surface.get_chunks()
                chunk = storage.chunk_iterators[surface_name]()
            end
        end
        -- chunk should now be guaranteed to be valid
    end

    -- get_random_chunk() can return nil when a surface has chunks in its
    -- iterator but none counted as generated (seen on space platform surfaces);
    -- skip this cycle instead of crashing in get_sub_chunks
    if chunk == nil then
        return nil
    end

    if storage.map_marker~=nil then
        storage.map_marker.destroy()
        storage.map_marker=nil
    end
    if mark_on_map then
        storage.map_marker = game.forces.player.add_chart_tag(surface, {icon = {type = "item", name = "atomic-bomb"}, text = "Active Chunk", position = {chunk.x*32,chunk.y*32}})
    end
    
    return {["surface"] = surface, ["chunk"] = chunk}
end

local function get_sub_chunks(chunk, divisions)
    local x = chunk.x*32
    local y = chunk.y*32
    local s = 32/divisions -- size
    local sub_chunks = {}
    for i=0,(divisions*divisions)-1 do
        local dx=s*(i%divisions)
        local dy=s*math.floor(i/divisions)
        sub_chunks[#sub_chunks+1] = {left_top = {x = x+dx, y = y+dy}, right_bottom = {x = x+dx+s, y = y+dy+s}}
    end
    return sub_chunks
end
--#endregion

--#region - event handling
script.on_nth_tick(operation_interval, function()
    
    if (#storage.nuclear_tiles==0 and storage.sub_chunks==nil) then
        local chunk = get_chunk()
        if chunk == nil then return end
        storage.chunk = chunk
        storage.sub_chunks = get_sub_chunks(chunk.chunk, chunk_subdivisions)

    elseif storage.sub_chunks~=nil then
        local surface = storage.chunk.surface
        -- surface may have been deleted (e.g. destroyed space platform)
        if not surface.valid then
            storage.chunk = nil
            storage.sub_chunks = nil
            storage.nuclear_tiles = {}
            return
        end
        local sub_chunk = storage.sub_chunks[1]

        if sub_chunk~=nil then
            local new_tiles = surface.find_tiles_filtered{name = nuclear_tile_types, area = sub_chunk}
            for _, tile in pairs(new_tiles) do
                storage.nuclear_tiles[#storage.nuclear_tiles+1] = tile
            end
            table.remove(storage.sub_chunks, 1)
        else
            storage.sub_chunks = nil
        end

    else
        local surface = storage.chunk.surface
        if not surface.valid then
            storage.chunk = nil
            storage.sub_chunks = nil
            storage.nuclear_tiles = {}
            return
        end
        local index = math.random(1,#storage.nuclear_tiles)
        local tile = storage.nuclear_tiles[index]
        local pos = tile.position

        if tile.valid then
            local neighbours = {}
            local neighbour = nil

            for _, i in pairs({{0,-1},{-1,0},{1,0},{0,1}}) do
                neighbour = surface.get_tile({pos.x+i[1],pos.y+i[2]})
    
                local is_nuclear_tile = false
                for _, tile_type in pairs(nuclear_tile_types) do
                    if neighbour.prototype.name == tile_type then
                        is_nuclear_tile = true
                    end
                end

                if not neighbour.collides_with("player") and (not is_nuclear_tile) then
                    neighbours[#neighbours+1] = neighbour
                end
            end

            if #neighbours > 0 then
                neighbour = neighbours[math.random(1,#neighbours)]
                surface.set_tiles({{position = pos, name = neighbour.prototype.name}})
                surface.destroy_decoratives{name = nuclear_secondary_decal_types, area = {{pos.x-1,pos.y-1},{pos.x+1,pos.y+1}}}
            end
        end
        table.remove(storage.nuclear_tiles, index)
    end
end)

script.on_event(defines.events.on_runtime_mod_setting_changed, function()
    operation_interval = settings.startup["nuclear-scorch-decay-operation-interval"].value
    chunk_selection_method = settings.global["nuclear-scorch-decay-chunk-selection-method"].value
    chunk_subdivisions = settings.global["nuclear-scorch-decay-chunk-subdivisions"].value
    mark_on_map = settings.global["nuclear-scorch-decay-mark-active-chunk"].value
end)

script.on_init(function()
    storage.map_marker = nil
    storage.chunk_iterators = {}
    storage.surfaces = {}
    storage.chunk = nil
    storage.sub_chunks = nil
    storage.nuclear_tiles = {}
end)

script.on_configuration_changed(function()
    if storage.map_marker ~= nil then
        storage.map_marker.destroy()
    end
    storage.map_marker = nil
    storage.chunk_iterators = {}
    storage.surfaces = {}
    storage.chunk = nil
    storage.sub_chunks = nil
    storage.nuclear_tiles = {}
end)
--#endregion