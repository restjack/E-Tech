local mk1_icon_path = "__base__/graphics/icons/personal-roboport-equipment.png"
local mk2_icon_path = "__ev-assets__/graphics/icons/personal-roboport-mk2-equipment.png"
local icon_size = 64

-- <> -- { v8.0.0: Space age changes - Other graphics } -- <> --

-- Patch mk2
local mk2_targets = {
  data.raw.item["personal-roboport-mk2-equipment"],
  data.raw["roboport-equipment"]["personal-roboport-mk2-equipment"],
  data.raw.recipe["personal-roboport-mk2-equipment-recycling"]
}

for _, proto in pairs(mk2_targets) do
  if proto then
    proto.icon = mk2_icon_path
    proto.icon_size = icon_size
    proto.icons = nil
  end
end

-- Patch mk1
local mk1_targets = {
  data.raw.item["personal-roboport-equipment"],
  data.raw["roboport-equipment"]["personal-roboport-equipment"],
  data.raw.recipe["personal-roboport-equipment-recycling"]
}

for _, proto in pairs(mk1_targets) do
  if proto then
    proto.icon = mk1_icon_path
    proto.icon_size = icon_size
    proto.icons = nil
  end
end