local mod_name = "__ev-assets__"

-- { LOCAL FORK 9.0.2: guarded shims for evanilla functions missing from
--   ev-assets 3.1.1 - see prototypes/local-fork-shims.lua }
require("prototypes.local-fork-shims")

-- <> -- { v5.0.0: Mod merge implemented } -- <> --

require("prototypes.item-groups")

if settings.startup["ev-armors-enabled"].value == true then
    require("prototypes.armors.grid")
    require("prototypes.armors.armor")
    require("prototypes.armors.recipes")
    require("prototypes.armors.technology")
    require("prototypes.armors.configs")
end

if settings.startup["fission-reactors-enabled"].value == true then
    require("prototypes.fission-reactors.item")
    require("prototypes.fission-reactors.equipment")
    require("prototypes.fission-reactors.recipes")
    require("prototypes.fission-reactors.technology")
    require("prototypes.fission-reactors.configs")
end

if settings.startup["roboports-enabled"].value == true then
    require("prototypes.roboports.item")
    require("prototypes.roboports.equipment")
    require("prototypes.roboports.recipes")
    require("prototypes.roboports.technology")
    require("prototypes.roboports.configs")
end

if settings.startup["exoskeletons-enabled"].value == true then
    require("prototypes.exoskeletons.item")
    require("prototypes.exoskeletons.equipment")
    require("prototypes.exoskeletons.recipes")
    require("prototypes.exoskeletons.technology")
    require("prototypes.exoskeletons.configs")
end

if settings.startup["shields-enabled"].value == true then
    require("prototypes.shields.item")
    require("prototypes.shields.equipment")
    require("prototypes.shields.recipes")
    require("prototypes.shields.technology")
    require("prototypes.shields.configs")
end

if settings.startup["lasers-enabled"].value == true then
    require("prototypes.lasers.item")
    require("prototypes.lasers.equipment")
    require("prototypes.lasers.recipes")
    require("prototypes.lasers.technology")
    require("prototypes.lasers.configs")
end

if settings.startup["utility-equipment-enabled"].value == true then
    require("prototypes.utility.item")
    require("prototypes.utility.equipment")
    require("prototypes.utility.recipes")
    require("prototypes.utility.technology")
    require("prototypes.utility.configs")
end

-- <> -- { v7.0.0: Space age changes } -- <> --

if mods ["space-age"] then
    if settings.startup["ev-mech-enabled"].value == true then
        require("prototypes.mech-armors.armor")
        require("prototypes.mech-armors.mech-grids")
        require("prototypes.mech-armors.recipes")
        require("prototypes.mech-armors.technology")
    end

    if settings.startup["fusion-reactors-enabled"].value == true then
        require("prototypes.fusion-reactors.item")
        require("prototypes.fusion-reactors.equipment")
        require("prototypes.fusion-reactors.recipes")
        require("prototypes.fusion-reactors.technology")
        require("prototypes.fusion-reactors.configs")
    end
end

-- <> -- { v5.1.0: Mod compatibilities } -- <> --

if mods ["ev-refining"] then
    if settings.startup["fusion-reactors-enabled"].value == true then
        require("prototypes.mods.ev-refining.reactors")
    end
    if settings.startup["utility-equipment-enabled"].value == true then
        require("prototypes.mods.ev-refining.utility")
    end
end

if mods ["jetpack"] and settings.startup["ev-armors-enabled"].value == true then
    table.insert(data.raw["battery-equipment"]["jetpack-1"].categories, "ind_armor")
    table.insert(data.raw["battery-equipment"]["jetpack-2"].categories, "ind_armor")
    table.insert(data.raw["battery-equipment"]["jetpack-3"].categories, "ind_armor")
    table.insert(data.raw["battery-equipment"]["jetpack-4"].categories, "ind_armor")
end

if mods ["Krastorio2"] and mods ["Krastorio2Assets"] then
    if settings.startup["ev-armors-enabled"].value == true then
        require("prototypes.mods.krastorio2.armors")
    end

    settings.startup["fusion-reactors-enabled"].value = false

    if settings.startup["roboports-enabled"].value == true then
        require("prototypes.mods.krastorio2.roboports")
    end
    if settings.startup["exoskeletons-enabled"].value == true then
        require("prototypes.mods.krastorio2.exoskeletons")
    end
    if settings.startup["shields-enabled"].value == true then
        require("prototypes.mods.krastorio2.shields")
    end
    if settings.startup["lasers-enabled"].value == true then
        require("prototypes.mods.krastorio2.lasers")
    end
    if settings.startup["utility-equipment-enabled"].value == true then
        require("prototypes.mods.krastorio2.utility")
    end
end