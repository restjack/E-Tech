-- - -- { More equipments mod: who remembers that? If you do, you're an awelsome person,
-- and probably one of my best fans. 
-- I used control.lua files when I didn't even know what a for cycle was.
-- Now I'm asking to myself how that thing was even possible. } -- - --

local personal_assemblers = {"1", "2", "3", "4"}
local crafting_bonuses = {"0.2", "0.3", "0.80", "2"}

-- - -- { Equipment gets placed in the grid } -- - --

script.on_event(defines.events.on_player_placed_equipment, function(event)
	local player = game.players[event.player_index]
	--local inventory_size = player.character_inventory_slots_bonus
	
	if player then
		if player.character then
   		local crafting_speed = player.character_crafting_speed_modifier
			for i, tier in pairs (personal_assemblers) do
				if event.equipment.name == "personal-assembling-unit"..personal_assemblers[i].."-equipment" then
					player.character_crafting_speed_modifier = crafting_speed + crafting_bonuses[i]
				end
			end
		else return
		end
	end
end)

-- - -- { Equipment gets removed from the grid } -- - --

script.on_event(defines.events.on_player_removed_equipment, function(event)
 	local player = game.players[event.player_index]
	--local inventory_size_bonus = player.character_inventory_slots_bonus

	if player then
		if player.character then
   		local crafting_speed_bonus = player.character_crafting_speed_modifier
			for i, tier in pairs (personal_assemblers) do
				if event.equipment == "personal-assembling-unit"..personal_assemblers[i].."-equipment" then
					if event.count >= 0 then
						local craftingCount = crafting_speed_bonus - (crafting_bonuses[i] * event.count)
						if craftingCount >= 0 then
							crafting_speed_bonus = craftingCount
							player.character_crafting_speed_modifier = crafting_speed_bonus
						end
					end
				end
			end
		else return
		end
	end
end)

script.on_event(defines.events.on_player_armor_inventory_changed, function(event)
  	local player = game.players[event.player_index]
	local crafting_bonus = 0

	if player then
		if player.character then
			local armor = player.get_inventory(defines.inventory.character_armor)
			if not armor.is_empty() then
				
				local crafting_bonus = 0
				--local inventory_bonus = 0
				local grid = armor[1].grid
				if grid ~= nil then
	
					for i = 1, #grid.equipment do
						for f, tier in pairs (personal_assemblers) do
							if grid.equipment[i].name == "personal-assembling-unit"..personal_assemblers[f].."-equipment" then
								crafting_bonus = crafting_bonus + crafting_bonuses[f]
							end
						end
					end
	
					set_inventory(player, crafting_bonus)	
					--set_inventory_bonus(player, inventory_bonus)
				else
					clear_all_bonuses(player, crafting_bonus)			
				end	
			else
				clear_all_bonuses(player, crafting_bonus)
			end
		else return
		end
	end
end)

function clear_all_bonuses(player, crafting_bonus)
	local total_crafting_bonus = player.character_crafting_speed_modifier
	player.character_crafting_speed_modifier = total_crafting_bonus - crafting_bonus
end

function set_inventory(player, count)
	player.character_crafting_speed_modifier = count
end

function log_crafting_Bonus(player)
	player.print("Character crafting speed: +" .. player.character_crafting_speed_modifier)	
end

--[[
		for i, tier in pairs (personal_backpacks) do
			if event.equipment.name == "personal-backpack-mk"..personal_backpacks[i].."-equipment" then
				player.character_inventory_slots_bonus = inventory_size + inventory_bonuses[i]
			end
		end



		for i, tier in pairs (personal_backpacks) do
			if event.equipment == "personal-backpack-mk"..personal_backpacks[i].."-equipment" then
				if event.count >= 0 then
					local inventoryCount = inventory_size_bonus - (inventory_bonuses[i] * event.count)
					if inventoryCount >= 0 then
						inventory_size_bonus = inventoryCount
						player.character_inventory_slots_bonus = inventory_size_bonus
					end
				end
			end
		end



				for i = 1, #grid.equipment do
					for f, tier in pairs (personal_backpacks) do
						if grid.equipment[i].name == "personal-backpack-mk"..personal_backpacks[f].."-equipment" then
							inventory_bonus = inventory_bonus + crafting_bonuses[f]
						end
					end
				end

function set_inventory_bonus(player, count)
	player.character_inventory_slots_bonus = count
end


script.on_event(defines.events.on_player_armor_inventory_changed, function(event)
    local player = game.players[event.player_index]
    local grid = player.get_inventory(defines.inventory.character_armor).grid
    if grid then
        for _, equipment in pairs(grid.equipment) do
            if equipment.name == "personal-backpack-mk1-equipment" then
                -- Update player's inventory size when the equipment is equipped
                player.character_inventory_slots_bonus = player.character_inventory_slots_bonus + 10
            end
            if equipment.name == "personal-backpack-mk2-equipment" then
                -- Update player's inventory size when the equipment is equipped
                player.character_inventory_slots_bonus = player.character_inventory_slots_bonus + 20
            end
            if equipment.name == "personal-backpack-mk3-equipment" then
                -- Update player's inventory size when the equipment is equipped
                player.character_inventory_slots_bonus = player.character_inventory_slots_bonus + 30
            end
        end
    end
end)
]]--