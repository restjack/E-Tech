local mod_name = "__ev-assets__"

local assembler_tiers = {"1", "2", "3", "4"}
local backpack_tiers = {"1", "2", "3"}

-- - { Ev modpack tweaks } - --

if settings.startup["ev-armors-enabled"].value == true then
  if settings.startup["ev-armor-division"].value == true then
    for i, tier in pairs (assembler_tiers) do 
      data.raw["belt-immunity-equipment"]["personal-assembling-unit"..assembler_tiers[i].."-equipment"].categories = {"ind_armor"}
    end
    for i, tier in pairs (backpack_tiers) do 
      table.insert(data.raw["inventory-bonus-equipment"]["personal-backpack-mk"..backpack_tiers[i].."-equipment"].categories, "ind_armor")
    end
  elseif settings.startup["ev-armor-division"].value == false then
    for i, tier in pairs (assembler_tiers) do 
      table.insert(data.raw["belt-immunity-equipment"]["personal-assembling-unit"..assembler_tiers[i].."-equipment"].categories, "ind_armor")
    end
  end
end

-- <> -- { v7.1.0: Space age changes } -- <> --

if mods ["space-age"] then
  -- { Inventory boost changes }
  data.raw["inventory-bonus-equipment"]["personal-backpack-mk1-equipment"].inventory_size_bonus = 30
  data.raw["inventory-bonus-equipment"]["personal-backpack-mk2-equipment"].inventory_size_bonus = 50
  data.raw["inventory-bonus-equipment"]["personal-backpack-mk3-equipment"].inventory_size_bonus = 80

  -- { Personal backpack mk1 equipment }
  table.insert(data.raw.technology["personal-backpack-mk1-equipment"].prerequisites, "toolbelt-equipment")
  table.insert(data.raw.technology["personal-backpack-mk1-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["personal-backpack-mk1-equipment"].unit.ingredients, {"agricultural-science-pack", 1})
  data.raw.recipe["personal-backpack-mk1-equipment"].ingredients =
  {
    { type = "item", name = "toolbelt-equipment", amount = 3 },
    { type = "item", name = "low-density-structure", amount = 10 },
    { type = "item", name = "carbon-fiber", amount = 20 }
  }

  -- { Personal backpack mk2 equipment }
  table.insert(data.raw.technology["personal-backpack-mk2-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["personal-backpack-mk2-equipment"].unit.ingredients, {"agricultural-science-pack", 1})
  data.raw.recipe["personal-backpack-mk2-equipment"].ingredients =
  {
    { type = "item", name = "personal-backpack-mk1-equipment", amount = 2 },
    { type = "item", name = "low-density-structure", amount = 20 },
    { type = "item", name = "carbon-fiber", amount = 25 },
    { type = "item", name = "efficiency-module-2", amount = 5 }
  }

  -- { Personal backpack mk3 equipment }
  table.insert(data.raw.technology["personal-backpack-mk3-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["personal-backpack-mk3-equipment"].unit.ingredients, {"agricultural-science-pack", 1})
  data.raw.recipe["personal-backpack-mk3-equipment"].ingredients =
  {
    { type = "item", name = "personal-backpack-mk2-equipment", amount = 1 },
    { type = "item", name = "low-density-structure", amount = 25 },
    { type = "item", name = "carbon-fiber", amount = 50 },
    { type = "item", name = "efficiency-module-2", amount = 5 }
  }
end