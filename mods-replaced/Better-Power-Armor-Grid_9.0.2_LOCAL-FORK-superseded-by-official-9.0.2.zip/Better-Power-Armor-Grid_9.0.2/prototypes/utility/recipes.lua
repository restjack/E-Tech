data:extend(
{

  {
    type = "recipe",
    name = "personal-assembling-unit1-equipment",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      { type = "item", name = "belt-immunity-equipment", amount = 4 },
      { type = "item", name = "low-density-structure", amount = 10 },
      { type = "item", name = "processing-unit", amount = 10 },
      { type = "item", name = "assembling-machine-3", amount = 1 }
    },
    results = { {type = "item", name = "personal-assembling-unit1-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "personal-assembling-unit2-equipment",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      { type = "item", name = "personal-assembling-unit1-equipment", amount = 1 },
      { type = "item", name = "productivity-module-2", amount = 5 },
      { type = "item", name = "speed-module-2", amount = 5 }
    },
    results = { {type = "item", name = "personal-assembling-unit2-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "personal-assembling-unit3-equipment",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      { type = "item", name = "personal-assembling-unit2-equipment", amount = 2 },
      { type = "item", name = "low-density-structure", amount = 20 },
      { type = "item", name = "processing-unit", amount = 20 }
    },
    results = { {type = "item", name = "personal-assembling-unit3-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "personal-assembling-unit4-equipment",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      { type = "item", name = "personal-assembling-unit3-equipment", amount = 2 },
      { type = "item", name = "low-density-structure", amount = 20 },
      { type = "item", name = "processing-unit", amount = 30 },
      { type = "item", name = "productivity-module-3", amount = 3 },
      { type = "item", name = "speed-module-3", amount = 3 }
    },
    results = { {type = "item", name = "personal-assembling-unit4-equipment", amount = 1 } }
  }
	
})

-- - -- { v6.0.0: Personal backpack equipment } -- - --

data:extend(
{

  {
    type = "recipe",
    name = "personal-backpack-mk1-equipment",
    enabled = false,
    energy_required = 5,
    ingredients =
    {
      { type = "item", name = "belt-immunity-equipment", amount = 4 },
      { type = "item", name = "low-density-structure", amount = 20 },
      { type = "item", name = "plastic-bar", amount = 25 }
    },
    results = { {type = "item", name = "personal-backpack-mk1-equipment", amount = 1 } }
  },

  {
    type = "recipe",
    name = "personal-backpack-mk2-equipment",
    enabled = false,
    energy_required = 5,
    ingredients =
    {
      { type = "item", name = "personal-backpack-mk1-equipment", amount = 2 },
      { type = "item", name = "low-density-structure", amount = 25 },
      { type = "item", name = "efficiency-module-2", amount = 5 }
    },
    results = { {type = "item", name = "personal-backpack-mk2-equipment", amount = 1 } }
  },

  {
    type = "recipe",
    name = "personal-backpack-mk3-equipment",
    enabled = false,
    energy_required = 5,
    ingredients =
    {
      { type = "item", name = "personal-backpack-mk2-equipment", amount = 2 },
      { type = "item", name = "low-density-structure", amount = 30 },
      { type = "item", name = "efficiency-module-3", amount = 5 }
    },
    results = { {type = "item", name = "personal-backpack-mk3-equipment", amount = 1 } }
  }

})