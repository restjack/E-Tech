local mod_name = "__ev-assets__"
local item_sounds = require("__base__.prototypes.item_sounds")

-- - -- { v5.0.0: Personal assembling unit } -- - --

local assembler_tiers = {"1", "2", "3", "4"}
local assembler_properties = { 10, 10, 5, 5 }

for i, tier in pairs (assembler_tiers) do
  data:extend({
    {
      type = "item",
      name = "personal-assembling-unit"..assembler_tiers[i].."-equipment",
		  icon = mod_name.."/graphics/icons/assembling-unit"..assembler_tiers[i]..".png",
      icon_size = 64,
      place_as_equipment_result = "personal-assembling-unit"..assembler_tiers[i].."-equipment",
      subgroup = "ev-utility",
      order = "aa",
      inventory_move_sound = item_sounds.electric_large_inventory_move,
      pick_sound = item_sounds.electric_large_inventory_pickup,
      drop_sound = item_sounds.electric_large_inventory_move,
      default_request_amount = 5,
      stack_size = assembler_properties[i]
    }
  })
end

-- - -- { v6.0.0: Personal backpack equipment } -- - --

local backpack_tiers = {"1", "2", "3"}
local backpack_properties = { 10, 10, 10 }

for i, tier in pairs (backpack_tiers) do
  data:extend({
    {
      type = "item",
      name = "personal-backpack-mk"..backpack_tiers[i].."-equipment",
      --localized_name = "Personal backpack mk "..backpack_tiers[i].." equipment",
		  icon = mod_name.."/graphics/icons/personal-backpack-mk"..backpack_tiers[i].."-equipment.png",
      icon_size = 64,
      place_as_equipment_result = "personal-backpack-mk"..backpack_tiers[i].."-equipment",
      subgroup = "ev-utility",
      order = "ba",
      inventory_move_sound = item_sounds.armor_small_inventory_move,
      pick_sound = item_sounds.armor_small_inventory_pickup,
      drop_sound = item_sounds.armor_small_inventory_move,
      default_request_amount = 10,
      stack_size = backpack_properties[i]
    }
  })
end