local mod_name = "__ev-assets__"

data:extend(
{
    
  {
    type = "technology",
    name = "personal-assembling-unit1-equipment",
    icon_size = 256,
    icon = mod_name.."/graphics/technology/personal-assembling-unit1-equipment.png",
    prerequisites = {"belt-immunity-equipment", "modular-armor", "processing-unit", "low-density-structure", "automation-3"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-assembling-unit1-equipment"
      }
    },
    unit =
    {
      count = 350,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1}
      },
      time = 30
    },
    order = "g-e-b-a"
  },
  {
    type = "technology",
    name = "personal-assembling-unit2-equipment",
    icon_size = 256,
    icon = mod_name.."/graphics/technology/personal-assembling-unit2-equipment.png",
    prerequisites = {"personal-assembling-unit1-equipment", "power-armor", "speed-module-2", "productivity-module-2"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-assembling-unit2-equipment"
      }
    },
    unit =
    {
      count = 450,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1}
      },
      time = 30
    },
    order = "g-e-b-a"
  },
  {
    type = "technology",
    name = "personal-assembling-unit3-equipment",
    icon_size = 256,
    icon = mod_name.."/graphics/technology/personal-assembling-unit3-equipment.png",
    prerequisites = {"personal-assembling-unit2-equipment", "power-armor-mk2"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-assembling-unit3-equipment"
      }
    },
    unit =
    {
      count = 600,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 30
    },
    order = "g-e-b-a"
  },
  {
    type = "technology",
    name = "personal-assembling-unit4-equipment",
    icon_size = 256,
    icon = mod_name.."/graphics/technology/personal-assembling-unit4-equipment.png",
    prerequisites = {"personal-assembling-unit3-equipment", "productivity-module-3", "speed-module-3"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-assembling-unit4-equipment"
      }
    },
    unit =
    {
      count = 750,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"utility-science-pack", 1},
        {"production-science-pack", 1},
      },
      time = 30
    },
    order = "g-e-b-a"
  },
  
})

-- - -- { v6.0.0: Personal backpack equipment } -- - --

data:extend(
{
    
  {
    type = "technology",
    name = "personal-backpack-mk1-equipment",
    icon_size = 256,
    icon = mod_name.."/graphics/technology/personal-backpack-mk1-equipment.png",
    prerequisites = {"belt-immunity-equipment", "modular-armor", "low-density-structure"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-backpack-mk1-equipment"
      }
    },
    unit =
    {
      count = 350,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1}
      },
      time = 30
    },
    order = "f-e-b-a"
  },
    
  {
    type = "technology",
    name = "personal-backpack-mk2-equipment",
    icon_size = 256,
    icon = mod_name.."/graphics/technology/personal-backpack-mk2-equipment.png",
    prerequisites = {"personal-backpack-mk1-equipment", "power-armor", "efficiency-module-2"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-backpack-mk2-equipment"
      }
    },
    unit =
    {
      count = 500,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 30
    },
    order = "f-e-b-b"
  },
    
  {
    type = "technology",
    name = "personal-backpack-mk3-equipment",
    icon_size = 256,
    icon = mod_name.."/graphics/technology/personal-backpack-mk3-equipment.png",
    prerequisites = {"personal-backpack-mk2-equipment", "power-armor-mk2", "efficiency-module-3"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-backpack-mk3-equipment"
      }
    },
    unit =
    {
      count = 750,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 30
    },
    order = "f-e-b-b"
  }

})