local mod_name = "__ev-assets__"

local assembler_tiers = {"1", "2", "3", "4"}
local assembler_properties = {
  {"300kJ", "500kJ", "1000kJ", "1500kJ"}, -- buffer_capacity --
  {"720kW", "1200kW", "2400kW", "3600kW"}, -- input_flow_limit --
  {"300kW", "500kW", "1000kW", "1500kW"}, -- energy_consumption --
  { 2, 2, 3, 4 } -- width / height --
}

-- - -- { v5.0.0: Personal assembling unit } -- - --

for i, tier in pairs (assembler_tiers) do
  data:extend(
  {
    {
      type = "belt-immunity-equipment",
      name = "personal-assembling-unit"..assembler_tiers[i].."-equipment",
      sprite =
      {
        filename = mod_name.."/graphics/equipment/assembling-unit"..assembler_tiers[i]..".png",
        width = 128,
        height = 128,
        priority = "medium"
      },
      shape =
      {
        width = assembler_properties[4][i],
        height = assembler_properties[4][i],
        type = "full"
      },
      energy_source =
      {
        type = "electric",
        buffer_capacity = assembler_properties[1][i],
        input_flow_limit = assembler_properties[2][i],
        usage_priority = "primary-input"
      },
      energy_consumption = assembler_properties[3][i],
      categories = {"armor"},
      order = "z-a-a"
    }
  })
end

data.raw["belt-immunity-equipment"]["personal-assembling-unit3-equipment"].sprite.width = 256
data.raw["belt-immunity-equipment"]["personal-assembling-unit3-equipment"].sprite.height = 256

data.raw["belt-immunity-equipment"]["personal-assembling-unit4-equipment"].sprite.width = 256
data.raw["belt-immunity-equipment"]["personal-assembling-unit4-equipment"].sprite.height = 256

-- - -- { v6.0.0: Personal backpack equipment } -- - --

local backpack_tiers = {"1", "2", "3"}
local backpack_properties = {
  { 2, 3, 4 }, -- width --
  { 4, 4, 4 }, -- height --
  { 20, 30, 40 } -- inventory size -- - -- { v7.0.2: 10, 20, 30 >> 20, 30, 40 }
}

for i, tier in pairs (backpack_tiers) do
  data:extend(
  {
    {
      type = "inventory-bonus-equipment",
      name = "personal-backpack-mk"..tier.."-equipment",
      sprite =
      {
        filename = mod_name.."/graphics/equipment/personal-backpack-mk"..tier.."-equipment.png",
        width = 256,
        height = 256,
        priority = "medium",
        scale = 0.5
      },
      shape =
      {
        width = backpack_properties[1][i],
        height = backpack_properties[2][i],
        type = "full"
      },
      categories = {"armor"},
      inventory_size_bonus = backpack_properties[3][i]
    }
  })
end

