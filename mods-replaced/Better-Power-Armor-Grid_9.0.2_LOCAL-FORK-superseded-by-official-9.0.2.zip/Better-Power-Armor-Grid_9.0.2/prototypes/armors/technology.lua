local mod_name = "__ev-assets__"

if settings.startup["maximum-armor-tier"].value >= 3 then
  data:extend(
  {
    {
      type = "technology",
      name = "77-power-armor-mk3",
      icon = mod_name.."/graphics/technology/power-armor-mk3.png",
      localised_description = {"technology-description.power-armor-3"},
      icon_size = 256, icon_mipmaps = 4,
      effects =
      {
        {
          type = "unlock-recipe",
          recipe = "77-power-armor-mk3"
        }
      },
      prerequisites =
      {
        "power-armor-mk2",
        "energy-shield-mk2-equipment"
      },
      unit =
      {
        count = 600,
        ingredients =
        {
          {"automation-science-pack", 1},
          {"logistic-science-pack", 1},
          {"chemical-science-pack", 1},
          {"military-science-pack", 1},
          {"utility-science-pack", 1}
        },
        time = 30
      },
      order = "g-c-ca"
    }
  })
end

if settings.startup["maximum-armor-tier"].value > 3 then 
  data:extend(
  { 
    {
      type = "technology",
      name = "77-power-armor-mk4",
      icon = mod_name.."/graphics/technology/power-armor-mk4.png",
      localised_description = {"technology-description.power-armor-4"},
      icon_size = 256, icon_mipmaps = 4,
      effects =
      {
        {
          type = "unlock-recipe",
          recipe = "77-power-armor-mk4"
        },
        {
          type = "unlock-recipe",
          recipe = "industrial-armor-mk2"
        }
      },
      prerequisites =
      {
        "77-power-armor-mk3",
        "speed-module-3"
      },
      unit =
      {
        count = 800,
        ingredients =
        {
          {"automation-science-pack", 1},
          {"logistic-science-pack", 1},
          {"chemical-science-pack", 1},
          {"military-science-pack", 1},
          {"production-science-pack", 1}, -- (v6.1.0 Changes: Introduced)
          {"utility-science-pack", 1},
        },
        time = 30
      },
      order = "g-c-cb"
    }
  })  
end

if settings.startup["maximum-armor-tier"].value > 4 then 
  data:extend(
  { 
    {
      type = "technology",
      name = "77-power-armor-mk5",
      icon = mod_name.."/graphics/technology/power-armor-mk5.png",
      localised_description = {"technology-description.power-armor-5"},
      icon_size = 256, icon_mipmaps = 4,
      effects =
      {
        {
          type = "unlock-recipe",
          recipe = "77-power-armor-mk5"
        }
      },
      prerequisites =
      {
        "77-power-armor-mk4",
        "efficiency-module-3"
      },
      unit =
      {
        count = 1000,
        ingredients =
        {
          {"automation-science-pack", 1},
          {"logistic-science-pack", 1},
          {"chemical-science-pack", 1},
          {"military-science-pack", 1},
          {"production-science-pack", 1}, -- (v4.0.0 Changes: Introduced)
          {"utility-science-pack", 1},
        },
        time = 30
      },
      order = "g-c-cc"
    }
  })
end

if settings.startup["maximum-armor-tier"].value > 5 then 
  data:extend(
  { 
    {
      type = "technology",
      name = "77-power-armor-mk6",
      icon = mod_name.."/graphics/technology/power-armor-mk6.png",
      localised_description = {"technology-description.power-armor-5"},
      icon_size = 256, icon_mipmaps = 4,
      effects =
      {
        {
          type = "unlock-recipe",
          recipe = "77-power-armor-mk6"
        },
        {
          type = "unlock-recipe",
          recipe = "industrial-armor-mk3"
        }
      },
      prerequisites =
      {
        "77-power-armor-mk5",
        "productivity-module-3",
        "space-science-pack"
      },
      unit =
      {
        count = 2000, -- { v6.2.0: 1500 -> 2000 }
        ingredients =
        {
          {"automation-science-pack", 1},
          {"logistic-science-pack", 1},
          {"chemical-science-pack", 1},
          {"military-science-pack", 1},
          {"production-science-pack", 1}, -- (v4.0.0 Changes: Introduced)
          {"utility-science-pack", 1},
          {"space-science-pack", 1},
        },
        time = 30
      },
      order = "g-c-cd"
    }
  })
end