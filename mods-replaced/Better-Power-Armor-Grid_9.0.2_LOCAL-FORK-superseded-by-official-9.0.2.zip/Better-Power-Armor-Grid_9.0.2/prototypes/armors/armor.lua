local mod_name = "__ev-assets__"
local item_sounds = require("__base__.prototypes.item_sounds")

data:extend(
{
  {
    type = "armor",
    name = "77-power-armor-mk3",
    icon = mod_name.."/graphics/icons/power-armor-mk3.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "acid",
        decrease = 25, -- +15 -- (Buff/Nerf that came in version 4.0.0)
        percent = 75
      },
      {
        type = "explosion",
        decrease = 75,
        percent = 50
      },
      {
        type = "fire",
        decrease = 10, -- +10 --
        percent = 70 -- -5% --
      },
      {
        type = "physical",
        decrease = 20, -- +10 --
        percent = 50
      }
    },
    subgroup = "ev-armor",
    order = "ba",
    inventory_move_sound = item_sounds.armor_large_inventory_move,
    pick_sound = item_sounds.armor_large_inventory_pickup,
    drop_sound = item_sounds.armor_large_inventory_move,
    stack_size = 1,
    infinite = true,
    equipment_grid = "mk3_grid",
    inventory_size_bonus = 40, -- - -- {v5.1.0: form 50 to 40}
  },
  
  {
    type = "armor",
    name = "77-power-armor-mk4",
    icon = mod_name.."/graphics/icons/power-armor-mk4.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "acid",
        decrease = 40, -- +15 --
        percent = 80 -- +5% --
      },
      {
        type = "explosion",
        decrease = 100, -- +25 --
        percent = 60
      },
      {
        type = "fire",
        decrease = 25, -- +15 --
        percent = 75
      },
      {
        type = "physical",
        decrease = 37.5, -- +12.5 --
        percent = 55 -- +5% --
      }
    },
    subgroup = "ev-armor",
    order = "bb",
    inventory_move_sound = item_sounds.armor_large_inventory_move,
    pick_sound = item_sounds.armor_large_inventory_pickup,
    drop_sound = item_sounds.armor_large_inventory_move,
    stack_size = 1,
    infinite = true,
    equipment_grid = "mk4_grid",
    inventory_size_bonus = 50, -- - -- {v5.1.0: form 60 to 50}
  },
  
  {
    type = "armor",
    name = "77-power-armor-mk5",
    icon = mod_name.."/graphics/icons/power-armor-mk5.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "acid",
        decrease = 75, -- +25 --
        percent = 80 -- +5% --
      },
      {
        type = "explosion",
        decrease = 100, -- +25 --
        percent = 70 -- -5% --
      },
      {
        type = "fire",
        decrease = 50, -- +25 --
        percent = 75
      },
      {
        type = "physical",
        decrease = 50,
        percent = 60 -- +10% --
      }
    },
    subgroup = "ev-armor",
    order = "bc",
    inventory_move_sound = item_sounds.armor_large_inventory_move,
    pick_sound = item_sounds.armor_large_inventory_pickup,
    drop_sound = item_sounds.armor_large_inventory_move,
    stack_size = 1,
    infinite = true,
    equipment_grid = "mk5_grid",
    inventory_size_bonus = 60, -- - -- {v5.1.0: form 70 to 60 / Before v5.0.0: From 60 to 85 and from 85 to 70}
  },
  
  {
    type = "armor",
    name = "77-power-armor-mk6",
    icon = mod_name.."/graphics/icons/power-armor-mk6.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "acid",
        decrease = 150, -- +75 --
        percent = 80 -- +5% --
      },
      {
        type = "explosion",
        decrease = 150, -- +50 --
        percent = 75
      },
      {
        type = "fire",
        decrease = 75, -- +25 --
        percent = 75
      },
      {
        type = "physical",
        decrease = 75,
        percent = 75 -- +25% --
      }
    },
    subgroup = "ev-armor",
    order = "bd",
    inventory_move_sound = item_sounds.armor_large_inventory_move,
    pick_sound = item_sounds.armor_large_inventory_pickup,
    drop_sound = item_sounds.armor_large_inventory_move,
    stack_size = 1,
    infinite = true,
    equipment_grid = "mk6_grid",
    inventory_size_bonus = 70, -- - -- {v5.1.0: form 80 to 70 / Before v5.0.0: from 90 to 100 and from 110 to 80}
  },
  
})

-- Industrial Armors --

data:extend{
  {
    type = "armor",
    name = "industrial-armor-mk1",
    icon = mod_name.."/graphics/icons/industrial-armor.png",
    icon_size = 64,
    resistances =
    {
      {
        type = "acid",
        decrease = 0,
        percent = 25
      },
      {
        type = "explosion",
        decrease = 50,
        percent = 25
      },
      {
        type = "fire",
        decrease = 0,
        percent = 50
      },
      {
        type = "physical",
        decrease = 17.5,
        percent = 25
      }
    },
    subgroup = "ev-armor",
    order = "ca",
    inventory_move_sound = item_sounds.armor_large_inventory_move,
    pick_sound = item_sounds.armor_large_inventory_pickup,
    drop_sound = item_sounds.armor_large_inventory_move,
    stack_size = 1,
    infinite = true,
    equipment_grid = "ind1_grid",
    inventory_size_bonus = 30, -- - -- {v5.1.0: form 40 to 30}
    open_sound = {filename =  "__base__/sound/armor-open.ogg", volume = 1},
    close_sound = {filename = "__base__/sound/armor-close.ogg", volume = 1}
  },
  
  {
    type = "armor",
    name = "industrial-armor-mk2",
    icon = mod_name.."/graphics/icons/industrial-armor-mk3.png",
    icon_size = 64,
    resistances =
    {
      {
        type = "acid",
        decrease = 12.5,
        percent = 37.5
      },
      {
        type = "explosion",
        decrease = 75,
        percent = 37.5
      },
      {
        type = "fire",
        decrease = 5,
        percent = 62.5
      },
      {
        type = "physical",
        decrease = 17.5,
        percent = 37.5
      }
    },
    subgroup = "ev-armor",
    order = "cb",
    inventory_move_sound = item_sounds.armor_large_inventory_move,
    pick_sound = item_sounds.armor_large_inventory_pickup,
    drop_sound = item_sounds.armor_large_inventory_move,
    stack_size = 1,
    infinite = true,
    equipment_grid = "ind2_grid",
    inventory_size_bonus = 50, -- - -- {v5.1.0: form 60 to 50}
    open_sound = {filename =  "__base__/sound/armor-open.ogg", volume = 1},
    close_sound = {filename = "__base__/sound/armor-close.ogg", volume = 1}
  },
  
  {
    type = "armor",
    name = "industrial-armor-mk3",
    icon = mod_name.."/graphics/icons/industrial-armor-mk5.png",
    icon_size = 64,
    resistances =
    {
      {
        type = "acid",
        decrease = 25,
        percent = 50
      },
      {
        type = "explosion",
        decrease = 100,
        percent = 50
      },
      {
        type = "fire",
        decrease = 10,
        percent = 75
      },
      {
        type = "physical",
        decrease = 25,
        percent = 50
      }
    },
    subgroup = "ev-armor",
    order = "cc",
    inventory_move_sound = item_sounds.armor_large_inventory_move,
    pick_sound = item_sounds.armor_large_inventory_pickup,
    drop_sound = item_sounds.armor_large_inventory_move,
    stack_size = 1,
    infinite = true,
    equipment_grid = "ind3_grid",
    inventory_size_bonus = 70, -- - -- {v5.1.0: form 80 to 770}
    open_sound = {filename =  "__base__/sound/armor-open.ogg", volume = 1},
    close_sound = {filename = "__base__/sound/armor-close.ogg", volume = 1}
  },
}