local mod_name = "__ev-assets__"
local aggro_tiers = {"mk3", "mk4", "mk5", "mk6"}
local industrial_tiers = {"ind1", "ind2", "ind3"}

-- - -- { Vanilla changes - Base grid stats overwrite } -- - --

data.raw["equipment-grid"]["small-equipment-grid"].width = 6
data.raw["equipment-grid"]["small-equipment-grid"].height = 6

data.raw["equipment-grid"]["medium-equipment-grid"].width = 8
data.raw["equipment-grid"]["medium-equipment-grid"].height = 8

if settings.startup["grid-size"].value == "Small" then

  data.raw["equipment-grid"]["small-equipment-grid"].width = 4
  data.raw["equipment-grid"]["small-equipment-grid"].height = 4
  
  data.raw["equipment-grid"]["medium-equipment-grid"].width = 6
  data.raw["equipment-grid"]["medium-equipment-grid"].height = 6
end

-- - -- { Grid prototypes } -- - --

data:extend(
{
  {
    type = "equipment-category",
    name = "ind_armor"
  }
})

for i, tier in pairs (aggro_tiers) do
  data:extend({
    {
      type = "equipment-grid",
      name = tier.."_grid",
      width = 10,
      height = 10,
      equipment_categories = {"armor"}
    },
  })
end

for i, tier in pairs (industrial_tiers) do
  data:extend({
    {
      type = "equipment-grid",
      name = tier.."_grid",
      width = 10,
      height = 10,
      equipment_categories = {"ind_armor"}
    },
  })
end