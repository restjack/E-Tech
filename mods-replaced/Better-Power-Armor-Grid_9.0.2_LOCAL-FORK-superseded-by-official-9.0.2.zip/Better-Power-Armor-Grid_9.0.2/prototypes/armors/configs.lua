local mod_name = "__ev-assets__"

-- <> -- { File edited in version: v8.0.0 } -- <> --

-- <> -- { v7.0.0: Vanilla changes } -- <> --

data.raw["armor"]["power-armor-mk2"].icon = mod_name.."/graphics/icons/power-armor-mk2.png"
data.raw["armor"]["power-armor-mk2"].subgroup = "ev-armor"
data.raw["armor"]["power-armor-mk2"].order = "aa"

-- <> -- { v6.0.0: Equipment division changes (Refactored for 2.1) } -- <> --

local industrial_tiers = {"ind1", "ind2", "ind3"}

if settings.startup["ev-armor-division"].value == true then

    table.insert(data.raw["equipment-grid"]["spidertron-equipment-grid"].equipment_categories, "ind_armor")
    
    -- Factorio equipment types
    local equipment_types = {
        "active-defense-equipment",
        "battery-equipment",
        "belt-immunity-equipment",
        "energy-shield-equipment",
        "generator-equipment",
        "movement-bonus-equipment",
        "night-vision-equipment",
        "roboport-equipment",
        "solar-panel-equipment"
    }

    -- Iteration on all equipment types
    for _, eq_type in pairs(equipment_types) do
        -- Is there an entry in data.raw?
        if data.raw[eq_type] then
            for eq_name, equipment in pairs(data.raw[eq_type]) do
                -- Verify that the equipment has the categories table
                if equipment.categories then
                    local has_category = false
                    -- Safety check to avoid duplicates
                    for _, category in pairs(equipment.categories) do
                        if category == "ind_armor" then
                            has_category = true
                            break
                        end
                    end
                    
                    -- Insert category if not present
                    if not has_category then
                        table.insert(equipment.categories, "ind_armor")
                    end
                end
            end
        end
    end
else
    -- Extra security check to ensure that the "armor" category is present in the industrial armor grids
    for _, tier in pairs(industrial_tiers) do
        local grid = data.raw["equipment-grid"][tier.."_grid"]
        if grid and grid.equipment_categories then
            local has_category = false
            for _, cat in pairs(grid.equipment_categories) do
                if cat == "armor" then
                    has_category = true
                    break
                end
            end
            
            if not has_category then
                table.insert(grid.equipment_categories, "armor")
            end
        end
    end
end

-- <> -- { v4.2.0 - Grid sizes depending on the chosen size } -- <> --

local tiers = {"mk3", "mk4", "mk5", "mk6", "ind1", "ind2", "ind3"}
local chosen_size = settings.startup["grid-size"].value

-- Map of all the grid sizes for each tier based on the chosen setting
local grid_sizes_map = {
    ["Small"]    = { 8,  10, 12, 14, 10, 14, 16 },
    ["Medium"]   = { 10, 12, 14, 16, 12, 16, 20 },
    ["Big"]      = { 12, 14, 16, 18, 14, 18, 22 },
    ["Behemoth"] = { 14, 16, 18, 20, 16, 20, 24 }
}

-- Draw the correct array given the chosen setting
local active_grids = grid_sizes_map[chosen_size]

if active_grids then
    for i, tier in ipairs(tiers) do
        local grid_name = tier .. "_grid"
        local grid_prototype = data.raw["equipment-grid"][grid_name]
        
        -- Controllo di sicurezza prima di iniettare i valori
        if grid_prototype then
            grid_prototype.width = active_grids[i]
            grid_prototype.height = active_grids[i]
        end
    end
end

-- <> -- { v4.2.0: Armor recipes changes depending on which type of equipment is enabled } -- <> --

local max_tier = settings.startup["maximum-armor-tier"].value
local diff_setting = settings.startup["ev-equipment-recipe-difficulty"].value
-- Difficulty >> Numerical number: Easy=1, Normal=2, Hard=3
local diff_idx = (diff_setting == "Easy" and 1) or (diff_setting == "Normal" and 2) or 3

-- Helper functions for adding prerequisites and modifying ingredients
local function add_prerequisite(tech_name, prereq_name)
    local tech = data.raw.technology[tech_name]
    if tech then
        tech.prerequisites = tech.prerequisites or {}
        table.insert(tech.prerequisites, prereq_name)
    end
end

-- Helper function to set or modify recipe ingredients
local function set_ingredient(recipe_name, index, item_name, amount)
    local recipe = data.raw.recipe[recipe_name]
    if recipe then
        recipe.ingredients = recipe.ingredients or {}
        recipe.ingredients[index] = { type = "item", name = item_name, amount = amount }
    end
end

-- <> -- { v7.0.0: Shields are enabled } -- <> --
if settings.startup["shields-enabled"].value == true then
    
    if max_tier > 3 then
        add_prerequisite("77-power-armor-mk4", "77-energy-shield-mk3-equipment")
        -- Inline array { Easy, Normal, Hard } >> draw value based on diff_idx
        set_ingredient("77-power-armor-mk4", 4, "77-energy-shield-mk3-equipment", ({1, 2, 5})[diff_idx])
        set_ingredient("industrial-armor-mk2", 4, "77-energy-shield-mk3-equipment", ({1, 1, 3})[diff_idx])
    end
    
    if max_tier > 4 then
        add_prerequisite("77-power-armor-mk5", "77-energy-shield-mk4-equipment")
        set_ingredient("77-power-armor-mk5", 4, "77-energy-shield-mk4-equipment", ({1, 2, 5})[diff_idx])
    end
    
    if max_tier > 5 then
        add_prerequisite("77-power-armor-mk6", "77-energy-shield-mk5-equipment")
        set_ingredient("77-power-armor-mk6", 4, "77-energy-shield-mk5-equipment", ({1, 2, 5})[diff_idx])
        set_ingredient("industrial-armor-mk3", 4, "77-energy-shield-mk5-equipment", ({1, 1, 3})[diff_idx])
    end
end

-- <> -- { v7.0.0: Utility equipment is enabled } -- <> --
if settings.startup["utility-equipment-enabled"].value == true then
    
    if max_tier > 3 then
        add_prerequisite("77-power-armor-mk4", "personal-assembling-unit2-equipment")
        
        -- We want MK4 armor recipe to change here
        local pa_mk4_item = ({ "personal-assembling-unit2-equipment", "personal-assembling-unit3-equipment", "personal-assembling-unit3-equipment" })[diff_idx]
        set_ingredient("77-power-armor-mk4", 3, pa_mk4_item, 1)
        
        set_ingredient("industrial-armor-mk2", 3, "personal-assembling-unit3-equipment", ({1, 1, 2})[diff_idx])
    end
    
    if max_tier > 4 then
        add_prerequisite("77-power-armor-mk5", "personal-assembling-unit3-equipment")
        set_ingredient("77-power-armor-mk5", 3, "personal-assembling-unit3-equipment", ({1, 2, 2})[diff_idx])
    end
    
    if max_tier > 5 then
        add_prerequisite("77-power-armor-mk6", "personal-assembling-unit4-equipment")
        set_ingredient("77-power-armor-mk6", 3, "personal-assembling-unit4-equipment", ({1, 1, 2})[diff_idx])
        set_ingredient("industrial-armor-mk3", 3, "personal-assembling-unit4-equipment", ({1, 1, 2})[diff_idx])
    end
end

-- <> -- { Enable armor animation on the character for every new tier of power armor added } -- <> --

for i, tier in pairs (tiers) do
    if i<5 then
        local armor = "77-power-armor-"..tier
        table.insert(data.raw["character"]["character"].animations[3]["armors"], armor)
    else
        if i<7 then
            local armor = "industrial-armor-mk"..(i-3)
            table.insert(data.raw["character"]["character"].animations[3]["armors"], armor)
        end
    end
end

-- <> -- { v7.1.0: Space age changes } -- <> --

if mods ["space-age"] then
    
    -- <> -- { Set the weight of every armor } -- <> --
    
    if data.raw["armor"] then
        for _, armor in pairs(data.raw["armor"]) do
            armor.weight = 1*tons
        end
    end

    -- <> -- { Hide power armor tiers greater than mk3 }

    if settings.startup["maximum-armor-tier"].value > 3 then
        if data.raw.armor["77-power-armor-mk4"] then
            data.raw.armor["77-power-armor-mk4"].hidden = true
            data.raw.recipe["77-power-armor-mk4"].hidden = true
            data.raw.technology["77-power-armor-mk4"].hidden = true
        end
    end
    if settings.startup["maximum-armor-tier"].value > 4 then
        if data.raw.armor["77-power-armor-mk5"] then
            data.raw.armor["77-power-armor-mk5"].hidden = true
            data.raw.recipe["77-power-armor-mk5"].hidden = true
            data.raw.technology["77-power-armor-mk5"].hidden = true
        end
    end
    if settings.startup["maximum-armor-tier"].value > 5 then
        if data.raw.armor["77-power-armor-mk6"] then
            data.raw.armor["77-power-armor-mk6"].hidden = true
            data.raw.recipe["77-power-armor-mk6"].hidden = true
            data.raw.technology["77-power-armor-mk6"].hidden = true

            data.raw.armor["industrial-armor-mk3"].hidden = true
            data.raw.recipe["industrial-armor-mk3"].hidden = true
        end
    end

    -- <> -- { Recipe changes }

    data:extend(
    { 
        {
            type = "recipe",
            name = "industrial-armor-mk2",
            enabled = false,
            energy_required = 40,
            ingredients =
            {
                { type = "item", name = "industrial-armor-mk1", amount = 1 },
                { type = "item", name = "low-density-structure", amount = 40 },
                
                { type = "item", name = "processing-unit", amount = 120 },
                { type = "item", name = "energy-shield-mk2-equipment", amount = 5 },
                
                { type = "item", name = "speed-module-2", amount = 20 }
            },
            results = { {type = "item", name = "industrial-armor-mk2", amount = 1 } }
        }
    })
    if settings.startup["maximum-armor-tier"].value > 2 then
        data.raw.recipe["77-power-armor-mk3"].ingredients =
        {
			{ type = "item", name = "power-armor-mk2", amount = 1 },
            { type = "item", name = "electric-engine-unit", amount = 50 },
            { type = "item", name = "low-density-structure", amount = 50 },
            { type = "item", name = "speed-module-2", amount = 25 },
            { type = "item", name = "efficiency-module-2", amount = 25 }
        }
        data.raw.recipe["mech-armor"].ingredients =
        {
            { type = "item", name = "77-power-armor-mk3", amount = 1 },
            { type = "item", name = "holmium-plate", amount = 100 },
            { type = "item", name = "processing-unit", amount = 75 },
            { type = "item", name = "superconductor", amount = 50 },
            { type = "item", name = "supercapacitor", amount = 50 }
        }
    end

    -- <> -- { Technology changes }

    table.insert(data.raw.technology["power-armor-mk2"].effects, { type = "unlock-recipe", recipe = "industrial-armor-mk1" })

    table.insert(data.raw.technology["77-power-armor-mk3"].effects, { type = "unlock-recipe", recipe = "industrial-armor-mk2" })    
    table.insert(data.raw.technology["77-power-armor-mk3"].unit.ingredients, {"space-science-pack", 1})
    data.raw.technology["77-power-armor-mk3"].prerequisites =
    {
        "power-armor-mk2",
        "efficiency-module-2",
        "speed-module-2"
    }
    
    -- <> -- { Equipment changes }
    
    local mech_grid_1 = settings.startup["ev-mech-grid-1"].value
    
    data.raw["equipment-grid"]["mk3_grid"].width = 12
    data.raw["equipment-grid"]["mk3_grid"].height = 12
    
    data.raw["equipment-grid"]["mk3_grid"].width = 14
    data.raw["equipment-grid"]["mk3_grid"].height = 14

    data.raw.armor["mech-armor"].equipment_grid = "mech-equipment-grid-1"
        
    data:extend(
    {
        {
            type = "equipment-grid",
            name = "mech-equipment-grid-1",
            width = mech_grid_1,
            height = mech_grid_1,
            equipment_categories = {"armor", "ind_armor"}
        }
    })
    if settings.startup["ev-armor-division"].value == true then
        table.insert(data.raw["generator-equipment"]["fusion-reactor-equipment"].categories, "ind_armor")
    end
end