local mod_name = "__ev-assets__"

-- <> -- { Power armors recipes } -- <> --
	
data:extend(
{
	{
		type = "recipe",
		name = "77-power-armor-mk3",
		enabled = false,
		energy_required = 30,
		ingredients =
		{
			{ type = "item", name = "power-armor-mk2", amount = 1 },
			{ type = "item", name = "processing-unit", amount = 30 },
			{ type = "item", name = "electric-engine-unit", amount = 30 },
			{ type = "item", name = "low-density-structure", amount = 20 },

			{ type = "item", name = "energy-shield-mk2-equipment", amount = 2 },

			{ type = "item", name = "productivity-module-2", amount = 30 }
		},
		results = { { type = "item", name = "77-power-armor-mk3", amount = 1 } }
	},

	{
	  type = "recipe",
	  name = "industrial-armor-mk1",
	  enabled = false,
	  energy_required = 25, -- <> -- {v6.1.0: 120 -> 25}
	  ingredients =
	  {
		{ type = "item", name = "power-armor", amount = 1 },
		{ type = "item", name = "processing-unit", amount = 30 },
		{ type = "item", name = "electric-engine-unit", amount = 30 },
		{ type = "item", name = "low-density-structure", amount = 15 },
  
		{ type = "item", name = "productivity-module-2", amount = 20 },
		{ type = "item", name = "efficiency-module-2", amount = 20 }
	  },
	  results = { {type = "item", name = "industrial-armor-mk1", amount = 1 } }
	}
})

if settings.startup["maximum-armor-tier"].value > 3 then
	data:extend(
	{
	  {
		type = "recipe",
		name = "77-power-armor-mk4",
		enabled = false,
		energy_required = 40, -- <> -- {v6.1.0: 60 -> 40}
		ingredients =
		{
		  { type = "item", name = "77-power-armor-mk3", amount = 1 },
		  { type = "item", name = "low-density-structure", amount = 30 },
	
		  { type = "item", name = "processing-unit", amount = 40 },
		  { type = "item", name = "energy-shield-mk2-equipment", amount = 10 },
	
		  { type = "item", name = "speed-module-3", amount = 20 }
		},
		results = { {type = "item", name = "77-power-armor-mk4", amount = 1 } }
	  },

	  {
		type = "recipe",
		name = "industrial-armor-mk2",
		enabled = false,
		energy_required = 40, -- <> -- {v6.1.0: 120 -> 40}
		ingredients =
		{
		  { type = "item", name = "industrial-armor-mk1", amount = 1 },
		  { type = "item", name = "low-density-structure", amount = 40 },
		  
		  { type = "item", name = "processing-unit", amount = 120 },
		  { type = "item", name = "energy-shield-mk2-equipment", amount = 5 },
		  
		  { type = "item", name = "speed-module-3", amount = 20 }
		},
		results = { {type = "item", name = "industrial-armor-mk2", amount = 1 } }
	  }
	})
end



if settings.startup["maximum-armor-tier"].value > 4 then
	data:extend(
	{
		{
			type = "recipe",
			name = "77-power-armor-mk5",
			enabled = false,
			energy_required = 50, -- <> -- {v6.1.0: 90 -> 50}
			ingredients =
			{
			{ type = "item", name = "77-power-armor-mk4", amount = 1 },
			{ type = "item", name = "electric-engine-unit", amount = 40 },
		
			{ type = "item", name = "processing-unit", amount = 80 },
			{ type = "item", name = "energy-shield-mk2-equipment", amount = 40 },
		
			{ type = "item", name = "efficiency-module-3", amount = 30 }
			},
			results = { {type = "item", name = "77-power-armor-mk5", amount = 1 } }
		},
	})
end



if settings.startup["maximum-armor-tier"].value > 5 then
	data:extend(
	{
		{
		  type = "recipe",
		  name = "77-power-armor-mk6",
		  enabled = false,
		  energy_required = 60, -- <> -- {v6.1.0: 120 -> 60}
		  ingredients =
		  {
			{ type = "item", name = "77-power-armor-mk5", amount = 1 },
			{ type = "item", name = "electric-engine-unit", amount = 40 },
	  
			{ type = "item", name = "processing-unit", amount = 120 },
			{ type = "item", name = "energy-shield-mk2-equipment", amount = 120 },
	  
			{ type = "item", name = "productivity-module-3", amount = 3 },
		  },
		  results = { {type = "item", name = "77-power-armor-mk6", amount = 1 } }
		},
	  
		{
		  type = "recipe",
		  name = "industrial-armor-mk3",
		  enabled = false,
		  energy_required = 60, -- <> -- {v6.1.0: 120 -> 60}
		  ingredients =
		  {
			{ type = "item", name = "industrial-armor-mk2", amount = 1 },
			{ type = "item", name = "electric-engine-unit", amount = 40 },
			
			{ type = "item", name = "processing-unit", amount = 200 },
			{ type = "item", name = "energy-shield-mk2-equipment", amount = 20 },
			
			{ type = "item", name = "productivity-module-3", amount = 30 }
			},
		  results = { {type = "item", name = "industrial-armor-mk3", amount = 1 } }
		}
	})
end