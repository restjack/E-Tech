local mod_name = "__ev-assets__"

data:extend(
{

  {
    type = "technology",
    name = "77-personal-laser-defense-mk2-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/personal-laser-defense-mk2-equipment.png"),
    prerequisites = {"speed-module", "personal-laser-defense-equipment"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-personal-laser-defense-mk2-equipment"
      }
    },
    unit =
    {
      count = 250,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1}
      },
      time = 45
    },
    order = "g-m-a"
  },
  {
    type = "technology",
    name = "77-personal-laser-defense-mk3-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/personal-laser-defense-mk3-equipment.png"),
    prerequisites = {"power-armor-mk2", "77-personal-laser-defense-mk2-equipment", "speed-module-2"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-personal-laser-defense-mk3-equipment"
      }
    },
    unit =
    {
      count = 300,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1},
      },
      time = 60
    },
    order = "g-m-c"
  },
  {
    type = "technology",
    name = "77-personal-laser-defense-mk4-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/personal-laser-defense-mk4-equipment.png"),
    prerequisites = {"77-personal-laser-defense-mk3-equipment", "speed-module-3"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-personal-laser-defense-mk4-equipment"
      }
    },
    unit =
    {
      count = 500,
      ingredients =
      {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
        {"military-science-pack", 2},
        {"chemical-science-pack", 1},
        {"utility-science-pack", 1},
      },
      time = 60
    },
    order = "g-m-d"
  },
  {
    type = "technology",
    name = "77-personal-laser-defense-mk5-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/personal-laser-defense-mk5-equipment.png"),
    prerequisites = {"77-personal-laser-defense-mk4-equipment", "fission-reactor-equipment"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-personal-laser-defense-mk5-equipment"
      }
    },
    unit =
    {
      count = 750,
      ingredients =
      {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
        {"military-science-pack", 2},
        {"chemical-science-pack", 1},
        {"utility-science-pack", 1},
      },
      time = 60
    },
    order = "g-m-d"
  },
  
})