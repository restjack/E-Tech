-- - { Ev modpack tweaks } - --

local tiers = {"mk2", "mk3", "mk4", "mk5"}

if settings.startup["ev-armors-enabled"].value == true and settings.startup["ev-armor-division"].value == false then
  for i, tier in pairs (tiers) do   
      table.insert(data.raw["active-defense-equipment"]["77-personal-laser-defense-"..tier.."-equipment"].categories, "ind_armor")
  end
end

-- <> -- { v9.0.0: Recipe difficulty changes via settings } -- <> --

local diff_setting = settings.startup["ev-equipment-recipe-difficulty"].value
local diff_idx = (diff_setting == "Easy" and 1) or (diff_setting == "Normal" and 2) or 3

local function modify_ingredient_amount(recipe_name, index, new_amount)
    if not new_amount then return end 
    
    local recipe = data.raw.recipe[recipe_name]
    if recipe and recipe.ingredients and recipe.ingredients[index] then
        local ing = recipe.ingredients[index]
        
        if ing.amount then
            ing.amount = new_amount
        else
            ing[2] = new_amount
        end
    end
end

-- <> -- { v7.1.0: Space age changes } -- <> --

if mods ["space-age"] then
    
  -- <> -- { Set the weight of every fission reactor } -- <> --
  for i, tier in pairs (tiers) do
      if data.raw.item["77-personal-laser-defense-"..tier.."-equipment"] then
        data.raw.item["77-personal-laser-defense-"..tier.."-equipment"].weight = 0.5*tons
      end
  end
  
  -- { Personal laser defense mk3 equipment }
  table.insert(data.raw.technology["77-personal-laser-defense-mk3-equipment"].unit.ingredients, {"space-science-pack", 1})
  data.raw.recipe["77-personal-laser-defense-mk3-equipment"].ingredients =
  {
    { type = "item", name = "77-personal-laser-defense-mk2-equipment", amount = 1 },
    { type = "item", name = "processing-unit", amount = 50 },
    { type = "item", name = "speed-module-2", amount = 15 }
  }
  modify_ingredient_amount("77-personal-laser-defense-mk2-equipment", 2, ({25, 50, 125})[diff_idx])
  modify_ingredient_amount("77-personal-laser-defense-mk2-equipment", 3, ({7, 15, 30})[diff_idx])
  
  -- { Personal laser defense mk4 equipment }
  table.insert(data.raw.technology["77-personal-laser-defense-mk4-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-personal-laser-defense-mk4-equipment"].unit.ingredients, {"metallurgic-science-pack", 1})
  data.raw.recipe["77-personal-laser-defense-mk4-equipment"].ingredients =
  {
    { type = "item", name = "77-personal-laser-defense-mk3-equipment", amount = 1 },
    { type = "item", name = "tungsten-carbide", amount = 30 },
    { type = "item", name = "tungsten-plate", amount = 20 },
    { type = "item", name = "speed-module-3", amount = 5 },
  }
  modify_ingredient_amount("77-personal-laser-defense-mk3-equipment", 2, ({15, 30, 125})[diff_idx])
  modify_ingredient_amount("77-personal-laser-defense-mk3-equipment", 3, ({10, 20, 50})[diff_idx])
  modify_ingredient_amount("77-personal-laser-defense-mk3-equipment", 4, ({3, 5, 15})[diff_idx])
  
  -- { Personal laser defense mk5 equipment }
  table.insert(data.raw.technology["77-personal-laser-defense-mk5-equipment"].prerequisites, "quality-module-3")
  table.insert(data.raw.technology["77-personal-laser-defense-mk5-equipment"].prerequisites, "quantum-processor")
  table.insert(data.raw.technology["77-personal-laser-defense-mk5-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-personal-laser-defense-mk5-equipment"].unit.ingredients, {"metallurgic-science-pack", 1})
  table.insert(data.raw.technology["77-personal-laser-defense-mk5-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})
  table.insert(data.raw.technology["77-personal-laser-defense-mk5-equipment"].unit.ingredients, {"cryogenic-science-pack", 1})
  data.raw.recipe["77-personal-laser-defense-mk5-equipment"].ingredients =
  {
    { type = "item", name = "77-personal-laser-defense-mk4-equipment", amount = 1 },
    { type = "item", name = "quantum-processor", amount = 100 },
    { type = "item", name = "supercapacitor", amount = 20 },
    { type = "item", name = "quality-module-3", amount = 30 }
  }
  modify_ingredient_amount("77-personal-laser-defense-mk5-equipment", 2, ({50, 100, 250})[diff_idx])
  modify_ingredient_amount("77-personal-laser-defense-mk5-equipment", 3, ({10, 20, 50})[diff_idx])
  modify_ingredient_amount("77-personal-laser-defense-mk5-equipment", 4, ({15, 30, 50})[diff_idx])
end