local mod_name = "__ev-assets__"
local laser_equipment_tiers = {"mk2", "mk3", "mk4", "mk5"}

local laser_properties = {
  { 1.5, 2, 3, 5 },                 -- buffer_capacity      -- { v7.2.0: Changed to multipliers || Vanilla: 220kJ }
  { 0.75, 0.5, 0.25, 0.15 },        -- cooldown             -- { v7.2.0: Changed to multipliers || Vanilla: 40 every 60s }
  { 17.5, 20, 25, 30 },             -- range                -- { v7.2.0: Changed to multipliers || Vanilla: 15 }
  { 1.25, 1.50, 1.75, 2 },          -- damage_modifier      -- { v7.2.0: Changed to multipliers || Vanilla: 1 }
  { 2, 3, 4, 1.5 }                  -- energy_consumption   -- { v7.2.0: Changed to multipliers || Vanilla: 50kJ }
}

for i, laser_tier in pairs (laser_equipment_tiers) do
  data:extend(
  {
    {
      type = "active-defense-equipment",
      name = "77-personal-laser-defense-"..laser_tier.."-equipment",
      sprite =
      {
        filename = mod_name.."/graphics/equipment/personal-laser-defense-"..laser_tier.."-equipment.png",
        width = 128,
        height = 128,
        priority = "medium",
        scale = 0.5
      },
      shape =
      {
			  width = settings.startup["laser-equipment-width"].value,
			  height = settings.startup["laser-equipment-height"].value,
        type = "full"
      },
      energy_source =
      {
        type = "electric",
        usage_priority = "secondary-input",
        buffer_capacity = 220 * laser_properties[1][i] * settings.startup["laser-equipment-buffer-capacity-multiplier"].value .. "kJ"
      },
  
      attack_parameters =
      {
        type = "beam",
        cooldown = 40 * laser_properties[2][i] / settings.startup["laser-equipment-shooting-speed-multiplier"].value,
        range = laser_properties[3][i] * settings.startup["laser-equipment-range-multiplier"].value,
        range_mode = "center-to-bounding-box",
        damage_modifier = laser_properties[4][i] * settings.startup["laser-equipment-damage-multiplier"].value,
        ammo_category = "laser",
        ammo_type =
        {
          energy_consumption = 50 * laser_properties[5][i] * settings.startup["laser-equipment-consumption-multiplier"].value .. "kJ",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "beam",
              beam = "laser-beam",
              max_length = laser_properties[3][i] * settings.startup["laser-equipment-range-multiplier"].value,
              duration = 40 * laser_properties[2][i] / settings.startup["laser-equipment-shooting-speed-multiplier"].value,
              source_offset = {0, -1.31439 }
            }
          }
        }
      },
  
      automatic = true,
      categories = {"armor"}
    },
  })
end

