data:extend(
{

  {
    type = "recipe",
    name = "77-personal-laser-defense-mk2-equipment",
    enabled = false,
    energy_required = 12.5, -- - -- { v7.1.3: 15>>12.5 }
    ingredients =
    {
      { type = "item", name = "personal-laser-defense-equipment", amount = 1 },
      { type = "item", name = "processing-unit", amount = 30 },
      { type = "item", name = "speed-module", amount = 10 } -- - -- { v7.1.3: 2>>10 }
    },
    results = { {type = "item", name = "77-personal-laser-defense-mk2-equipment", amount = 1 } }
  },

  {
    type = "recipe",
    name = "77-personal-laser-defense-mk3-equipment",
    enabled = false,
    energy_required = 15, -- - -- { v7.1.3: 20>>15 }
    ingredients =
    {
      { type = "item", name = "77-personal-laser-defense-mk2-equipment", amount = 1 },
      { type = "item", name = "processing-unit", amount = 50 }, -- - -- { v7.1.3: 35>>50 }
      { type = "item", name = "speed-module-2", amount = 20 } -- - -- { v7.1.3: 5>>20 }
    },
    results = { {type = "item", name = "77-personal-laser-defense-mk3-equipment", amount = 1 } }
  },

  {
    type = "recipe",
    name = "77-personal-laser-defense-mk4-equipment",
    enabled = false,
    energy_required = 17.5, -- - -- { v7.1.3: 25>>17.5 }
    ingredients =
    {
      { type = "item", name = "77-personal-laser-defense-mk3-equipment", amount = 1 },
      { type = "item", name = "processing-unit", amount = 100 }, -- - -- { v7.1.3: 40>>100 }
      { type = "item", name = "speed-module-3", amount = 25 }, -- - -- { v7.1.3: 10>>25 }
    },
    results = { {type = "item", name = "77-personal-laser-defense-mk4-equipment", amount = 1 } }
  },

  {
    type = "recipe",
    name = "77-personal-laser-defense-mk5-equipment",
    enabled = false,
    energy_required = 20, -- - -- { v7.1.3: 40>>20 }
    ingredients =
    {
      { type = "item", name = "77-personal-laser-defense-mk4-equipment", amount = 1 },
      { type = "item", name = "processing-unit", amount = 150 }, -- - -- { v7.1.3: 50>>150 }
      { type = "item", name = "productivity-module-3", amount = 30 }, -- - -- { v7.1.3: 0>>30 }
      { type = "item", name = "efficiency-module-3", amount = 30 } -- - -- { v7.1.3: 0>>30 }
    },
    results = { {type = "item", name = "77-personal-laser-defense-mk5-equipment", amount = 1 } }
  },
  
})