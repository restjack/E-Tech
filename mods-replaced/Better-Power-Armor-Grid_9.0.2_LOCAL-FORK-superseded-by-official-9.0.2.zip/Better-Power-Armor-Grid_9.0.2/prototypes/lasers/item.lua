local mod_name = "__ev-assets__"
local item_sounds = require("__base__.prototypes.item_sounds")

local laser_equipment_tiers = {"mk2", "mk3", "mk4", "mk5"}
local properties = {
  { 20, 20, 20, 20 } -- (v9.0.0: flat 20 | v2.0.0 Changes: +0; -5; -5; -10)
}

data.raw.item["personal-laser-defense-equipment"].subgroup = "ev-lasers"
data.raw.item["personal-laser-defense-equipment"].order = "aa"

for i, laser_tier in pairs (laser_equipment_tiers) do
  data:extend({
    {
      type = "item",
      name = "77-personal-laser-defense-"..laser_tier.."-equipment",
      localised_description = {"item-description.personal-laser-equipment"},
		  icon = mod_name.."/graphics/icons/personal-laser-defense-"..laser_tier.."-equipment.png",
      icon_size = 64, icon_mipmaps = 4,
      place_as_equipment_result = "77-personal-laser-defense-"..laser_tier.."-equipment",
      subgroup = "ev-lasers",
      order = "ab",
      inventory_move_sound = item_sounds.turret_inventory_move,
      pick_sound = item_sounds.turret_inventory_pickup,
      drop_sound = item_sounds.turret_inventory_move,
      default_request_amount = 5,
      stack_size = properties[1][i]
    }
  })
end