local mod_name = "__ev-assets__"

-- - -- { v5.1.0 : Item changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

data.raw.item["personal-roboport-mk2-equipment"].icon = mod_name.."/graphics/icons/personal-roboport-mk2-equipment.png"

-- - -- { v5.1.0 : Recipe changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

data.raw.recipe["77-personal-roboport-mk3-equipment"].ingredients =
{
  { type = "item", name = "personal-roboport-mk2-equipment", amount = 4 },
  { type = "item", name = "kr-rare-metals", amount = 30 },

  { type = "item", name = "speed-module-2", amount = 5 }
}

data.raw.recipe["77-personal-roboport-mk4-equipment"].ingredients =
{
  { type = "item", name = "77-personal-roboport-mk3-equipment", amount = 3 },
  { type = "item", name = "kr-ai-core", amount = 15 },

  { type = "item", name = "speed-module-3", amount = 5 },
  { type = "item", name = "productivity-module-3", amount = 5 }
}

data.raw.recipe["77-personal-roboport-mk5-equipment"].ingredients =
{
  { type = "item", name = "77-personal-roboport-mk4-equipment", amount = 2 },
  { type = "item", name = "kr-imersium-plate", amount = 10 },
  { type = "item", name = "kr-imersium-gear-wheel", amount = 15 },

  { type = "item", name = "efficiency-module-3", amount = 5 }
}

data.raw.recipe["77-personal-roboport-mk6-equipment"].ingredients =
{
  { type = "item", name = "77-personal-roboport-mk5-equipment", amount = 1 },
  { type = "item", name = "kr-imersium-beam", amount = 15 },
  { type = "item", name = "kr-energy-control-unit", amount = 10 },

  { type = "item", name = "efficiency-module-3", amount = 10 }
}

-- - -- { v5.1.0 : Equipment changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

local mk2_sprite_fix = data.raw["roboport-equipment"]["personal-roboport-mk2-equipment"].sprite
mk2_sprite_fix.filename = mod_name.."/graphics/equipment/personal-roboport-mk2-equipment.png"
--mk2_sprite_fix.hr_version.filename = mod_name.."/graphics/equipment/hr-personal-roboport-mk2-equipment.png"

data.raw["roboport-equipment"]["personal-roboport-mk2-equipment"].sprite.filename = mod_name.."/graphics/equipment/personal-roboport-mk2-equipment.png"

-- - -- { v5.1.0 : Technology changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

data.raw.technology["77-personal-roboport-mk3-equipment"].unit.time = 30
data.raw.technology["77-personal-roboport-mk4-equipment"].unit.time = 45
data.raw.technology["77-personal-roboport-mk5-equipment"].unit.time = 60
data.raw.technology["77-personal-roboport-mk6-equipment"].unit.time = 90

data.raw.technology["77-personal-roboport-mk3-equipment"].prerequisites = {"personal-roboport-mk2-equipment", "kr-ai-core"}
data.raw.technology["77-personal-roboport-mk3-equipment"].unit.ingredients =
{
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"military-science-pack", 1},
  {"chemical-science-pack", 1},
  {"production-science-pack", 1},
  {"utility-science-pack", 1}
}
data.raw.technology["77-personal-roboport-mk3-equipment"].unit.count = 500

data.raw.technology["77-personal-roboport-mk4-equipment"].prerequisites = {"77-personal-roboport-mk3-equipment", "space-science-pack"}
data.raw.technology["77-personal-roboport-mk4-equipment"].unit.ingredients =
{
  {"utility-science-pack", 1 },
  {"production-science-pack", 1},
  {"space-science-pack", 1}
}
data.raw.technology["77-personal-roboport-mk4-equipment"].unit.count = 750

data.raw.technology["77-personal-roboport-mk5-equipment"].prerequisites = {"77-personal-roboport-mk4-equipment", "kr-advanced-tech-card"}
data.raw.technology["77-personal-roboport-mk5-equipment"].unit.ingredients =
{
  {"utility-science-pack", 1},
  {"production-science-pack", 1},
  { kr_optimization_tech_card_name, 1},
  {"kr-advanced-tech-card", 1}
}
data.raw.technology["77-personal-roboport-mk5-equipment"].unit.count = 1000

data.raw.technology["77-personal-roboport-mk6-equipment"].prerequisites = {"77-personal-roboport-mk5-equipment", "kr-advanced-tech-card"}
data.raw.technology["77-personal-roboport-mk6-equipment"].unit.ingredients =
{
  {"utility-science-pack", 1},
  {"production-science-pack", 1},
  { kr_optimization_tech_card_name, 1},
  {"kr-matter-tech-card", 1},
  {"kr-singularity-tech-card", 1}
}
data.raw.technology["77-personal-roboport-mk6-equipment"].unit.count = 1500