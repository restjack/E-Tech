local mod_name = "__ev-assets__"

-- - -- { v5.1.0 : Item changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Change the normal vanilla equipment graphics back to the Ev version

--data.raw["energy-shield-equipment"]["energy-shield-equipment"].icon = "__base__/graphics/icons/energy-shield-equipment.png"

--evanilla.item.edit_item("energy-shield-equipment", {icon = "__base__/graphics/icons/energy-shield-equipment.png", icon_size = 64})
--evanilla.item.edit_item("energy-shield-mk2-equipment", {icon = "__base__/graphics/icons/energy-shield-mk2-equipment.png", icon_size = 64})

data.raw.item["energy-shield-equipment"].subgroup = "ev-shields"
data.raw.item["energy-shield-equipment"].order = "aa"

data.raw.item["energy-shield-mk2-equipment"].subgroup = "ev-shields"
data.raw.item["energy-shield-mk2-equipment"].order = "ab"

-- - -- { v5.1.0 : Recipe changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Same fate have Krastorio shield technologies and recipes

if not mods ["space-exploration"] then
  data.raw.recipe["energy-shield-mk3-equipment"] = nil
  data.raw.recipe["energy-shield-mk4-equipment"] = nil
end

-- Change and adapts the Ev shields to the modpack

data.raw.recipe["77-energy-shield-mk3-equipment"].ingredients =
{
  { type = "item", name = "energy-shield-mk2-equipment", amount = 5 },
  { type = "item", name = "kr-electronic-components", amount = 20 },
  { type = "item", name = "kr-lithium-sulfur-battery", amount = 10 }
}

data.raw.recipe["77-energy-shield-mk4-equipment"].ingredients =
{
  { type = "item", name = "77-energy-shield-mk3-equipment", amount = 4 },
  { type = "item", name = "kr-rare-metals", amount = 15 },
  { type = "item", name = "processing-unit", amount = 10 }
}

data.raw.recipe["77-energy-shield-mk5-equipment"].ingredients =
{
  { type = "item", name = "77-energy-shield-mk4-equipment", amount = 3 },
  { type = "item", name = "kr-ai-core", amount = 5 },
  { type = "item", name = "kr-imersium-plate", amount = 10 }
}

-- - -- { v5.1.0 : Equipment changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Back to normal pt2

-- data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.filename = "__base__/graphics/equipment/energy-shield-equipment.png"
-- data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.hr_version.filename = "__base__/graphics/equipment/hr-energy-shield-equipment.png"

-- - -- { v5.1.0 : Technology changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Same fate have Krastorio shield technologies and recipes

data.raw.technology["kr-energy-shield-mk3-equipment"] = nil
data.raw.technology["kr-energy-shield-mk4-equipment"] = nil

-- Change and adapts the Ev shields to the modpack

data.raw.technology["77-energy-shield-mk3-equipment"].unit.time = 30
data.raw.technology["77-energy-shield-mk4-equipment"].unit.time = 45
data.raw.technology["77-energy-shield-mk5-equipment"].unit.time = 60

data.raw.technology["77-energy-shield-mk3-equipment"].prerequisites = {"energy-shield-mk2-equipment", "utility-science-pack", "kr-lithium-sulfur-battery"}
data.raw.technology["77-energy-shield-mk3-equipment"].unit.ingredients =
{
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"chemical-science-pack", 1},
  {"utility-science-pack", 1}
}
data.raw.technology["77-energy-shield-mk3-equipment"].unit.count = 350

data.raw.technology["77-energy-shield-mk4-equipment"].prerequisites = {"77-energy-shield-mk3-equipment", "space-science-pack"}
data.raw.technology["77-energy-shield-mk4-equipment"].unit.ingredients =
{
  {"utility-science-pack", 1 },
  {"production-science-pack", 1},
  {"space-science-pack", 1}
}
data.raw.technology["77-energy-shield-mk4-equipment"].unit.count = 500

data.raw.technology["77-energy-shield-mk5-equipment"].prerequisites = {"77-energy-shield-mk4-equipment", "kr-advanced-tech-card"}
data.raw.technology["77-energy-shield-mk5-equipment"].unit.ingredients =
{
  {"utility-science-pack", 1},
  {"production-science-pack", 1},
  { kr_optimization_tech_card_name, 1},
  {"kr-advanced-tech-card", 1}
}
data.raw.technology["77-energy-shield-mk5-equipment"].unit.count = 750