local mod_name = "__ev-assets__"

local armor_equipment_tiers = {"mk3", "mk4", "mk5", "mk6"}
local industrial_tiers = {"ind1", "ind2", "ind3"}

-- - -- { v5.1.0 : Grid equipment changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Adapt the new krastorio equipment to the different armors

if settings.startup["ev-armor-division"].value == true then

  table.insert(data.raw["generator-equipment"]["kr-fusion-reactor-equipment"].categories, "ind_armor")
  table.insert(data.raw["generator-equipment"]["kr-antimatter-reactor-equipment"].categories, "ind_armor")
  table.insert(data.raw["generator-equipment"]["kr-fusion-reactor-equipment"].categories, "armor")
  table.insert(data.raw["generator-equipment"]["kr-antimatter-reactor-equipment"].categories, "armor")

  --table.insert(data.raw["battery-equipment"]["kr-energy-absorber"].categories, "ind_armor")
  --table.insert(data.raw["battery-equipment"]["kr-energy-absorber"].categories, "armor")
  
  table.insert(data.raw["battery-equipment"]["kr-battery-mk3-equipment"].categories, "ind_armor")
  table.insert(data.raw["battery-equipment"]["kr-big-battery-equipment"].categories, "ind_armor")
  table.insert(data.raw["battery-equipment"]["kr-big-battery-mk2-equipment"].categories, "ind_armor")
  table.insert(data.raw["battery-equipment"]["kr-big-battery-mk3-equipment"].categories, "ind_armor")
  table.insert(data.raw["battery-equipment"]["kr-battery-mk3-equipment"].categories, "armor")
  table.insert(data.raw["battery-equipment"]["kr-big-battery-equipment"].categories, "armor")
  table.insert(data.raw["battery-equipment"]["kr-big-battery-mk2-equipment"].categories, "armor")
  table.insert(data.raw["battery-equipment"]["kr-big-battery-mk3-equipment"].categories, "armor")

  table.insert(data.raw["solar-panel-equipment"]["kr-big-solar-panel-equipment"].categories, "ind_armor")
  --table.insert(data.raw["solar-panel-equipment"]["kr-imersite-solar-panel-equipment"].categories, "ind_armor")
  --table.insert(data.raw["solar-panel-equipment"]["kr-big-imersite-solar-panel-equipment"].categories, "ind_armor")
  table.insert(data.raw["solar-panel-equipment"]["kr-big-solar-panel-equipment"].categories, "armor")
  --table.insert(data.raw["solar-panel-equipment"]["kr-imersite-solar-panel-equipment"].categories, "armor")
  --table.insert(data.raw["solar-panel-equipment"]["kr-big-imersite-solar-panel-equipment"].categories, "armor")
  
  table.insert(data.raw["active-defense-equipment"]["kr-personal-laser-defense-mk2-equipment"].categories, "armor")
  table.insert(data.raw["active-defense-equipment"]["kr-personal-laser-defense-mk3-equipment"].categories, "armor")
  table.insert(data.raw["active-defense-equipment"]["kr-personal-laser-defense-mk4-equipment"].categories, "armor")
  
  --table.insert(data.raw["active-defense-equipment"]["kr-personal-submachine-laser-defense-mk1-equipment"].categories, "armor")
  --table.insert(data.raw["active-defense-equipment"]["kr-personal-submachine-laser-defense-mk2-equipment"].categories, "armor")
  --table.insert(data.raw["active-defense-equipment"]["kr-personal-submachine-laser-defense-mk3-equipment"].categories, "armor")
  --table.insert(data.raw["active-defense-equipment"]["kr-personal-submachine-laser-defense-mk4-equipment"].categories, "armor")

else

  table.insert(data.raw["generator-equipment"]["kr-fusion-reactor-equipment"].categories, "armor")
  table.insert(data.raw["generator-equipment"]["kr-antimatter-reactor-equipment"].categories, "armor")

  --table.insert(data.raw["battery-equipment"]["kr-energy-absorber"].categories, "armor")
  
  table.insert(data.raw["battery-equipment"]["kr-battery-mk3-equipment"].categories, "armor")
  table.insert(data.raw["battery-equipment"]["kr-big-battery-equipment"].categories, "armor")
  table.insert(data.raw["battery-equipment"]["kr-big-battery-mk2-equipment"].categories, "armor")
  table.insert(data.raw["battery-equipment"]["kr-big-battery-mk3-equipment"].categories, "armor")

  table.insert(data.raw["solar-panel-equipment"]["kr-big-solar-panel-equipment"].categories, "armor")
  --table.insert(data.raw["solar-panel-equipment"]["kr-imersite-solar-panel-equipment"].categories, "armor")
  --table.insert(data.raw["solar-panel-equipment"]["kr-big-imersite-solar-panel-equipment"].categories, "armor")
  
  table.insert(data.raw["active-defense-equipment"]["kr-personal-laser-defense-mk2-equipment"].categories, "armor")
  table.insert(data.raw["active-defense-equipment"]["kr-personal-laser-defense-mk3-equipment"].categories, "armor")
  table.insert(data.raw["active-defense-equipment"]["kr-personal-laser-defense-mk4-equipment"].categories, "armor")
  
  --table.insert(data.raw["active-defense-equipment"]["kr-personal-submachine-laser-defense-mk1-equipment"].categories, "armor")
  --table.insert(data.raw["active-defense-equipment"]["kr-personal-submachine-laser-defense-mk2-equipment"].categories, "armor")
  --table.insert(data.raw["active-defense-equipment"]["kr-personal-submachine-laser-defense-mk3-equipment"].categories, "armor")
  --table.insert(data.raw["active-defense-equipment"]["kr-personal-submachine-laser-defense-mk4-equipment"].categories, "armor")

end

-- - -- { v5.1.0 : Item changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Substitute the original krastorio items with the ev ones and add radiactive resistances based on level

evanilla.item.replace_item("77-power-armor-mk3", "kr-power-armor-mk3")
table.insert(data.raw.armor["77-power-armor-mk3"].resistances, {type = "kr-radioactive",  decrease = 5,  percent = 60})

evanilla.item.replace_item("77-power-armor-mk4", "kr-power-armor-mk4")
table.insert(data.raw.armor["77-power-armor-mk4"].resistances, {type = "kr-radioactive",  decrease = 6,  percent = 70})

table.insert(data.raw.armor["77-power-armor-mk5"].resistances, {type = "kr-radioactive",  decrease = 7,  percent = 80})
table.insert(data.raw.armor["77-power-armor-mk6"].resistances, {type = "kr-radioactive",  decrease = 8,  percent = 90})

table.insert(data.raw.armor["industrial-armor-mk1"].resistances, {type = "kr-radioactive",  decrease = 10,  percent = 60})
table.insert(data.raw.armor["industrial-armor-mk2"].resistances, {type = "kr-radioactive",  decrease = 12.5,  percent = 80})
table.insert(data.raw.armor["industrial-armor-mk3"].resistances, {type = "kr-radioactive",  decrease = 15,  percent = 95})


-- - -- { v5.1.0 : Recipe changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

evanilla.recipe.replace_item_in_recipes("kr-power-armor-mk3", "77-power-armor-mk3")
evanilla.recipe.replace_item_in_recipes("kr-power-armor-mk4", "77-power-armor-mk4")
data.raw.recipe["kr-power-armor-mk3"] = nil
data.raw.recipe["kr-power-armor-mk3"] = nil

data.raw.recipe["77-power-armor-mk3"].ingredients =
{
  { type = "item", name = "power-armor-mk2", amount = 1 },
  { type = "item", name = "processing-unit", amount = 40 },
  { type = "item", name = "kr-ai-core", amount = 30 },

  { type = "item", name = "efficiency-module-2", amount = 30 }
}

data.raw.recipe["77-power-armor-mk4"].ingredients =
{
  { type = "item", name = "77-power-armor-mk3", amount = 1 },
  { type = "item", name = "processing-unit", amount = 50 },
  { type = "item", name = "kr-rare-metals", amount = 40 },

  { type = "item", name = "productivity-module-3", amount = 25 }
}

data.raw.recipe["77-power-armor-mk5"].ingredients =
{
  { type = "item", name = "77-power-armor-mk4", amount = 1 },
  { type = "item", name = "kr-energy-control-unit", amount = 25 },

  { type = "item", name = "speed-module-3", amount = 25 },
  { type = "item", name = "efficiency-module-3", amount = 25 }
}

data.raw.recipe["77-power-armor-mk6"].categories = {"crafting-with-fluid"} -- { LOCAL FORK 9.0.2: .category is a removed 2.0 field, crashes 2.1 load }
data.raw.recipe["77-power-armor-mk6"].ingredients =
{
  { type = "item", name = "77-power-armor-mk5", amount = 1 },
  { type = "item", name = "kr-ai-core", amount = 40 },
  { type = "item", name = "kr-imersium-plate", amount = 40 },
  { type = "item", name = "kr-imersite-crystal", amount = 10 },

  { type = "fluid", name = "kr-nitric-acid", amount = 50 }
}

data.raw.recipe["industrial-armor-mk1"].ingredients =
{
  { type = "item", name = "power-armor-mk2", amount = 1 },
  { type = "item", name = "electric-engine-unit", amount = 35 },
  { type = "item", name = "low-density-structure", amount = 20 },

  { type = "item", name = "efficiency-module-2", amount = 20 },
  { type = "item", name = "productivity-module-2", amount = 20 }
}

data.raw.recipe["industrial-armor-mk2"].ingredients =
{
  { type = "item", name = "industrial-armor-mk1", amount = 1 },
  { type = "item", name = "processing-unit", amount = 40 },
  { type = "item", name = "kr-rare-metals", amount = 40 },
  { type = "item", name = "kr-ai-core", amount = 20 },

  { type = "item", name = "speed-module-3", amount = 25 }
}


data.raw.recipe["industrial-armor-mk3"].categories = {"crafting-with-fluid"} -- { LOCAL FORK 9.0.2: same }
data.raw.recipe["industrial-armor-mk3"].ingredients =
{
  { type = "item", name = "industrial-armor-mk2", amount = 1 },
  { type = "item", name = "kr-ai-core", amount = 40 },
  { type = "item", name = "kr-imersium-plate", amount = 40 },
  { type = "item", name = "kr-imersite-crystal", amount = 15 },

  { type = "fluid", name = "kr-nitric-acid", amount = 50 }
}

-- - -- { v5.1.0 : Equipment changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- - -- { v5.1.0 : Technology changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Delete krastorio power armor technologies, adapt the ev ones to the modpack and then replace.
-- I didn't find a better approach I'm sorry but I've been coding for a whole night.

data.raw.technology["kr-power-armor-mk3"] = nil
data.raw.technology["kr-power-armor-mk4"] = nil

for i, tier in pairs (armor_equipment_tiers) do
  data.raw.technology["77-power-armor-"..tier].unit.time = 60
end
data.raw.technology["77-power-armor-mk6"].unit.time = 90

data.raw.technology["77-power-armor-mk3"].prerequisites = {"power-armor-mk2", "kr-ai-core"}
data.raw.technology["77-power-armor-mk3"].unit.ingredients =
{
  {"automation-science-pack", 2},
  {"logistic-science-pack", 2},
  {"military-science-pack", 2},
  {"chemical-science-pack", 1},
  {"utility-science-pack", 1},
  {"production-science-pack", 1}
}

data.raw.technology["77-power-armor-mk4"].prerequisites = {"77-power-armor-mk3", "space-science-pack"}
data.raw.technology["77-power-armor-mk4"].unit.ingredients =
{
  {"utility-science-pack", 1 },
  {"production-science-pack", 1},
  {"space-science-pack", 1}
}

data.raw.technology["77-power-armor-mk5"].prerequisites = {"77-power-armor-mk4", "kr-advanced-tech-card"}
data.raw.technology["77-power-armor-mk5"].unit.ingredients =
{
  {"utility-science-pack", 1},
  {"production-science-pack", 1},
  { kr_optimization_tech_card_name, 1},
  {"kr-advanced-tech-card", 1}
}

data.raw.technology["77-power-armor-mk6"].prerequisites = {"77-power-armor-mk5", "kr-singularity-tech-card"}
data.raw.technology["77-power-armor-mk6"].unit.ingredients =
{
  {"utility-science-pack", 1},
  {"production-science-pack", 1},
  { kr_optimization_tech_card_name, 1},
  {"kr-matter-tech-card", 1},
  {"kr-singularity-tech-card", 1}
}