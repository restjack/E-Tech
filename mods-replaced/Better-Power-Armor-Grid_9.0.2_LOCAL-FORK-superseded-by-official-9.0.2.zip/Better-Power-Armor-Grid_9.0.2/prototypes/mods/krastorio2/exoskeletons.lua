local mod_name = "__ev-assets__"

local exoskeleton_tiers = {"mk2", "mk3", "mk4", "mk5"}
local properties =
{
  {"300kW", "400kW", "750kW", "200kW"},
  {0.4, 0.5, 0.6, 0.8}
}

-- - -- { v5.1.0 : Item changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Changes the vanilla exoskeleton location in the inventory

data.raw.item["exoskeleton-equipment"].subgroup = "ev-exoskeletons"
data.raw.item["exoskeleton-equipment"].order = "aa"

-- - -- { v5.1.0 : Recipe changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Delete krastorio exoskeleton recipes, replaces if needed and adapt the ev exoskeletons to the modpack

evanilla.recipe.replace_item_in_recipes("advanced-exoskeleton-equipment", "77-exoskeleton-mk2-equipment")
evanilla.recipe.replace_item_in_recipes("superior-exoskeleton-equipment", "77-exoskeleton-mk3-equipment")
data.raw.recipe["advanced-exoskeleton-equipment"] = nil
data.raw.recipe["superior-exoskeleton-equipment"] = nil

data.raw.recipe["77-exoskeleton-mk2-equipment"].ingredients =
{
  { type = "item", name = "exoskeleton-equipment", amount = 1 },
  { type = "item", name = "low-density-structure", amount = 10 },
  { type = "item", name = "advanced-circuit", amount = 10 },

  { type = "item", name = "speed-module-2", amount = 10 }
}

data.raw.recipe["77-exoskeleton-mk3-equipment"].ingredients =
{
  { type = "item", name = "77-exoskeleton-mk2-equipment", amount = 1 },
  { type = "item", name = "processing-unit", amount = 15 },

  { type = "item", name = "speed-module-2", amount = 10 },
  { type = "item", name = "efficiency-module-2", amount = 10 }
}
data.raw.recipe["77-exoskeleton-mk3-equipment"].categories = {"crafting"} -- { LOCAL FORK 9.0.2: .category is a removed 2.0 field, crashes 2.1 load }

data.raw.recipe["77-exoskeleton-mk4-equipment"].ingredients =
{
  { type = "item", name = "77-exoskeleton-mk3-equipment", amount = 1 },
  { type = "item", name = "kr-rare-metals", amount = 25 },
  { type = "item", name = "kr-ai-core", amount = 10 },

  { type = "item", name = "speed-module-3", amount = 5 }
}
data.raw.recipe["77-exoskeleton-mk4-equipment"].categories = {"crafting"} -- { LOCAL FORK 9.0.2: same }

data.raw.recipe["77-exoskeleton-mk5-equipment"].ingredients =
{
  { type = "item", name = "77-exoskeleton-mk4-equipment", amount = 1 },
  { type = "item", name = "kr-ai-core", amount = 15 },
  { type = "item", name = "kr-imersium-plate", amount = 10 },

  { type = "item", name = "kr-fusion-reactor-equipment", amount = 1 }
}
data.raw.recipe["77-exoskeleton-mk5-equipment"].categories = {"crafting"} -- { LOCAL FORK 9.0.2: same }

-- - -- { v5.1.0 : Equipment changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Apply the modified values

for i, tier in pairs (exoskeleton_tiers) do
  data.raw["movement-bonus-equipment"]["77-exoskeleton-"..tier.."-equipment"].energy_consumption = properties[1][i]
  data.raw["movement-bonus-equipment"]["77-exoskeleton-"..tier.."-equipment"].movement_bonus = properties[2][i]
end

-- - -- { v5.1.0 : Technology changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Delete krastorio exoskeleton technologies, adapt the ev ones to the modpack and then replace.

data.raw.technology["kr-advanced-exoskeleton-equipment"] = nil
data.raw.technology["kr-superior-exoskeleton-equipment"] = nil

data.raw.technology["77-exoskeleton-mk2-equipment"].unit.time = 30
data.raw.technology["77-exoskeleton-mk3-equipment"].unit.time = 30
data.raw.technology["77-exoskeleton-mk4-equipment"].unit.time = 45
data.raw.technology["77-exoskeleton-mk5-equipment"].unit.time = 60

data.raw.technology["77-exoskeleton-mk2-equipment"].prerequisites = {"exoskeleton-equipment", "utility-science-pack"}
data.raw.technology["77-exoskeleton-mk2-equipment"].unit.ingredients =
{
  {"automation-science-pack", 2},
  {"logistic-science-pack", 2},
  {"military-science-pack", 2},
  {"chemical-science-pack", 1},
  {"utility-science-pack", 1}
}
data.raw.technology["77-exoskeleton-mk2-equipment"].unit.count = 250

data.raw.technology["77-exoskeleton-mk3-equipment"].prerequisites = {"77-exoskeleton-mk2-equipment", "kr-ai-core"}
data.raw.technology["77-exoskeleton-mk3-equipment"].unit.ingredients =
{
  {"automation-science-pack", 2},
  {"logistic-science-pack", 2},
  {"military-science-pack", 2},
  {"chemical-science-pack", 1},
  {"utility-science-pack", 1},
  {"production-science-pack", 1}
}
data.raw.technology["77-exoskeleton-mk3-equipment"].unit.count = 400

data.raw.technology["77-exoskeleton-mk4-equipment"].prerequisites = {"77-exoskeleton-mk3-equipment", "space-science-pack"}
data.raw.technology["77-exoskeleton-mk4-equipment"].unit.ingredients =
{
  {"utility-science-pack", 1 },
  {"production-science-pack", 1},
  {"space-science-pack", 1}
}
data.raw.technology["77-exoskeleton-mk4-equipment"].unit.count = 600

data.raw.technology["77-exoskeleton-mk5-equipment"].prerequisites = {"77-exoskeleton-mk4-equipment", "kr-advanced-tech-card"}
data.raw.technology["77-exoskeleton-mk5-equipment"].unit.ingredients =
{
  {"utility-science-pack", 1},
  {"production-science-pack", 1},
  { kr_optimization_tech_card_name, 1},
  {"kr-advanced-tech-card", 1}
}
data.raw.technology["77-exoskeleton-mk5-equipment"].unit.count = 750