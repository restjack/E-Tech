local mod_name = "__ev-assets__"

local laser_equipment_tiers = {"mk2", "mk3", "mk4", "mk5"}

-- - -- { v5.1.0 : Item changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

for i, laser_tier in pairs (laser_equipment_tiers) do
  data.raw.item["77-personal-laser-defense-"..laser_tier.."-equipment"].localised_name = "Long-range personal defense "..laser_tier.." equipment"
end

-- - -- { v5.1.0 : Recipe changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

data.raw.recipe["77-personal-laser-defense-mk2-equipment"].ingredients =
{
  --{ type = "item", name = "personal-submachine-laser-defense-mk1-equipment", amount = 1 },
  { type = "item", name = "personal-laser-defense-equipment", amount = 1 },
  { type = "item", name = "kr-lithium-sulfur-battery", amount = 3 },
  { type = "item", name = "battery", amount = 2 },
  { type = "item", name = "advanced-circuit", amount = 10 }
}

data.raw.recipe["77-personal-laser-defense-mk3-equipment"].ingredients =
{
  { type = "item", name = "77-personal-laser-defense-mk2-equipment", amount = 1 },
  { type = "item", name = "processing-unit", amount = 10 },
  { type = "item", name = "kr-lithium-sulfur-battery", amount = 10 },
  { type = "item", name = "kr-imersium-plate", amount = 5 }
}

data.raw.recipe["77-personal-laser-defense-mk4-equipment"].ingredients =
{
  { type = "item", name = "77-personal-laser-defense-mk3-equipment", amount = 1 },
  { type = "item", name = "kr-ai-core", amount = 10 },
  { type = "item", name = "kr-lithium-sulfur-battery", amount = 20 },
  { type = "item", name = "kr-energy-control-unit", amount = 7 }
}

data.raw.recipe["77-personal-laser-defense-mk5-equipment"].ingredients =
{
  { type = "item", name = "77-personal-laser-defense-mk4-equipment", amount = 1 },
  { type = "item", name = "kr-ai-core", amount = 15 },
  { type = "item", name = "kr-imersium-plate", amount = 10 },
  { type = "item", name = "kr-energy-control-unit", amount = 10 }
}

-- - -- { v5.1.0 : Equipment changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- - -- { v5.1.0 : Technology changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

for i, laser_tier in pairs ({"mk2", "mk3", "mk4"}) do
    data.raw.technology["kr-personal-laser-defense-"..laser_tier.."-equipment"] = nil
end

data.raw.technology["77-personal-laser-defense-mk3-equipment"].unit.ingredients =
{
  { "production-science-pack", 1 },
  { "utility-science-pack", 1 },
  { "space-science-pack", 1 }
}

data.raw.technology["77-personal-laser-defense-mk4-equipment"].unit.ingredients =
{
  { "production-science-pack", 1 },
  { "utility-science-pack", 1 },
  { "space-science-pack", 1 },
  { "kr-advanced-tech-card", 1 }
}

data.raw.technology["77-personal-laser-defense-mk5-equipment"].unit.ingredients =
{
  { "utility-science-pack", 1 },
  { kr_optimization_tech_card_name, 1 },
  { "kr-advanced-tech-card", 1 },
  { "kr-singularity-tech-card", 1 }
}

for i, laser_tier in pairs ({"mk2", "mk3", "mk4"}) do
  evanilla.tech.add_recipe_unlock("77-personal-laser-defense-"..laser_tier.."-equipment", "kr-personal-laser-defense-"..laser_tier.."-equipment")
end

evanilla.tech.add_prerequisite("77-personal-laser-defense-mk2-equipment", "kr-lithium-sulfur-battery")
evanilla.tech.add_prerequisite("77-personal-laser-defense-mk3-equipment", "kr-imersium-processing")
evanilla.tech.add_prerequisite("77-personal-laser-defense-mk4-equipment", "kr-advanced-tech-card")
evanilla.tech.add_prerequisite("77-personal-laser-defense-mk5-equipment", "kr-singularity-tech-card")