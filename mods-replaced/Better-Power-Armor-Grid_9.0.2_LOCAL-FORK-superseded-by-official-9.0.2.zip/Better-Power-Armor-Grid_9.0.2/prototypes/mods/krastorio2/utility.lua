local mod_name = "__ev-assets__"

-- - -- { v5.1.0 : Item changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- - -- { v5.1.0 : Recipe changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Change and adapt the utility equipment to the modpack

data.raw.recipe["personal-backpack-mk3-equipment"].ingredients =
{
  { type = "item", name = "personal-backpack-mk2-equipment", amount = 2 },
  { type = "item", name = "kr-rare-metals", amount = 30 },
  { type = "item", name = "efficiency-module-3", amount = 5 }
}

-- - -- { v5.1.0 : Equipment changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --