local mod_name = "__ev-assets__"

-- - -- { v5.1.0 : Item changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- - -- { v5.1.0 : Recipe changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Change and adapt the utility equipments to the modpack

data.raw.recipe["personal-backpack-mk1-equipment"].ingredients =
{
  { type = "item", name = "belt-immunity-equipment", amount = 4 },
  { type = "item", name = "low-density-structure", amount = 20 },
  { type = "item", name = "HDPE-alloy", amount = 10 }
}

if mods ["space-age"] then
  data.raw.recipe["personal-backpack-mk1-equipment"].ingredients =
  {
    { type = "item", name = "toolbelt-equipment", amount = 3 },
    { type = "item", name = "carbon-fiber", amount = 20 },
    { type = "item", name = "HDPE-alloy", amount = 10 }
  }
  data.raw.recipe["personal-backpack-mk2-equipment"].ingredients =
  {
    { type = "item", name = "personal-backpack-mk1-equipment", amount = 2 },
    { type = "item", name = "carbon-fiber", amount = 25 },
    { type = "item", name = "HDPE-alloy", amount = 20 },
    { type = "item", name = "efficiency-module-2", amount = 5 }
  }
  data.raw.recipe["personal-backpack-mk3-equipment"].ingredients =
  {
    { type = "item", name = "personal-backpack-mk2-equipment", amount = 1 },
    { type = "item", name = "carbon-fiber", amount = 50 },
    { type = "item", name = "HDPE-alloy", amount = 25 },
    { type = "item", name = "efficiency-module-2", amount = 5 }
  }
end

-- - -- { v5.1.0 : Equipment changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

