local mod_name = "__ev-assets__"

-- - -- { v5.1.0 : Item changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- - -- { v5.1.0 : Recipe changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

-- Change and adapt the fusion reactor equipments to the modpack

-- - -- { v5.1.0 : Equipment changes } -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - -- -- - --

