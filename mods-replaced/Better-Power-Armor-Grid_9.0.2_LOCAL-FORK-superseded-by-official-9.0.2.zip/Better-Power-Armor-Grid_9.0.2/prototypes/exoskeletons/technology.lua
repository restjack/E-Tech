local mod_name = "__ev-assets__"

data:extend(
{
  {
	type = "technology",
	name = "77-exoskeleton-mk2-equipment",
	icon_size = 256, icon_mipmaps = 4,
	icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/exoskeleton-mk2-equipment.png"),
	effects =
	{
	  {
		type = "unlock-recipe",
		recipe = "77-exoskeleton-mk2-equipment"
	  }
	},
	prerequisites = {"exoskeleton-equipment", "speed-module-2", "low-density-structure"},
	unit =
	{
	  count = 150, -- - -- { v6.3.0: 100 -> 150 }
	  ingredients =
	  {
		{"automation-science-pack", 1}, -- - -- { v6.3.0: 2 -> 1 / v4.0.0 Changes: +1 }
		{"logistic-science-pack", 1}, -- - -- { v6.3.0: 2 -> 1 / v4.0.0 Changes: +1 }
		{"chemical-science-pack", 1},
		{"utility-science-pack", 1}
	  },
	  time = 30 -- - -- { v6.3.0: 40 -> 30 / v4.0.0 Changes: -5s }
	},
	  order = "g-ha"
	},
	{
	type = "technology",
	name = "77-exoskeleton-mk3-equipment",
	icon_size = 256, icon_mipmaps = 4,
	icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/exoskeleton-mk3-equipment.png"),
	effects =
	{
	  {
		type = "unlock-recipe",
		recipe = "77-exoskeleton-mk3-equipment"
	  }
	},
	prerequisites = {"77-exoskeleton-mk2-equipment", "productivity-module-2", "efficiency-module-2"},
	unit =
	{
	  count = 350, -- - -- { v6.3.0: 200 -> 350 / v4.0.0 Changes: -100 }
	  ingredients =
	  {
		{"automation-science-pack", 1}, -- - -- { v6.3.0: 2 -> 1 / v4.0.0 Changes: +1 }
		{"logistic-science-pack", 1}, -- - -- { v6.3.0: 2 -> 1 / v4.0.0 Changes: +1 }
		{"chemical-science-pack", 1}, -- - -- { v6.3.0: 2 -> 1 / v4.0.0 Changes: +1 }
		{"utility-science-pack", 1}
	  },
	  time = 45 -- - -- { v6.3.0: 50 -> 45 / v4.0.0 Changes: -10s }
	},
	  order = "g-hb"
	},
	{
	type = "technology",
	name = "77-exoskeleton-mk4-equipment",
	icon_size = 256, icon_mipmaps = 4,
	icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/exoskeleton-mk4-equipment.png"),
	effects =
	{
	  {
		type = "unlock-recipe",
		recipe = "77-exoskeleton-mk4-equipment"
	  }
	},
	prerequisites = {"77-exoskeleton-mk3-equipment", "speed-module-3"},
	unit =
	{
	  count = 500, -- - -- { v6.3.0: 300 -> 500 / v4.0.0 Changes: -200 }
	  ingredients =
	  {
		{"automation-science-pack", 1}, -- - -- { v6.3.0: 2 -> 1 / v4.0.0 Changes: +1 }
		{"logistic-science-pack", 1}, -- - -- { v6.3.0: 2 -> 1 / v4.0.0 Changes: +1 }
		{"chemical-science-pack", 1}, -- - -- { v6.3.0: 2 -> 1 / v4.0.0 Changes: +1 }
		{"production-science-pack", 1},
		{"utility-science-pack", 1}
	  },
      time = 45 -- - -- { v6.3.0: 60 -> 45 / v4.0.0 Changes: -15s }
	},
	  order = "g-hc"
	},
	{
	type = "technology",
	name = "77-exoskeleton-mk5-equipment",
	icon_size = 256, icon_mipmaps = 4,
	icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/exoskeleton-mk5-equipment.png"),
	effects =
	{
	  {
		type = "unlock-recipe",
		recipe = "77-exoskeleton-mk5-equipment"
	  }
	},
	prerequisites = {"77-exoskeleton-mk4-equipment", "efficiency-module-3", "productivity-module-3"},
	unit =
	{
	  count = 750, -- - -- { v6.3.0: 500 -> 750 / v4.0.0 Changes: -300 }
	  ingredients =
	  {
		{"automation-science-pack", 1}, -- - -- { v6.3.0: 3 -> 1 / v4.0.0 Changes: +1 }
		{"logistic-science-pack", 1}, -- - -- { v6.3.0: 3 -> 1 / v4.0.0 Changes: +1 }
		{"chemical-science-pack", 1}, -- - -- { v6.3.0: 2 -> 1 }
		{"utility-science-pack", 1},
		{"production-science-pack", 1}
	  },
	  time = 60 -- - -- { v6.3.0: 75 -> 60 / v4.0.0 Changes: -15s }
	},
	  order = "g-hd"
	},

})