-- - -- { v6.3.0: All recipes were changed } -- - --

data:extend(
{

  {
    type = "recipe",
    name = "77-exoskeleton-mk2-equipment",
    enabled = false,
    energy_required = 12.5, -- - -- { v7.1.3: 15>>12.5 }
    ingredients = 
    {
      { type = "item", name = "exoskeleton-equipment", amount = 1 },
      { type = "item", name = "low-density-structure", amount = 30 },
      { type = "item", name = "steel-plate", amount = 30 },
      
	    { type = "item", name = "speed-module-2", amount = 5 }
    },
    results = { {type = "item", name = "77-exoskeleton-mk2-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "77-exoskeleton-mk3-equipment",
	  categories = {"crafting-with-fluid"},
    enabled = false,
    energy_required = 15, -- - -- { v7.1.3: 20>>15 }
    ingredients = 
    {
      { type = "item", name = "77-exoskeleton-mk2-equipment", amount = 1 },
      
      { type = "item", name = "productivity-module-2", amount = 20 }, -- - -- { v7.1.3: 10>>20 }
      { type = "item", name = "efficiency-module-2", amount = 20 } -- - -- { v7.1.3: 10>>20 }
    },
    results = { {type = "item", name = "77-exoskeleton-mk3-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "77-exoskeleton-mk4-equipment",
	  categories = {"crafting-with-fluid"},
    enabled = false,
    energy_required = 17.5, -- - -- { v7.1.3: 25>>17.5 }
    ingredients = 
    {
      { type = "item", name = "77-exoskeleton-mk3-equipment", amount = 1 },
      { type = "item", name = "speed-module-3", amount = 25 }, -- - -- { v7.1.3: 10>>25 }
      
	    { type = "fluid", name = "lubricant", amount = 500 } -- - -- { v6.3.0: 350>>500 / v4.0.0 Changes: 250>>350 }
    },
    results = { {type = "item", name = "77-exoskeleton-mk4-equipment", amount = 1 } }
  },
  {
    type = "recipe",
	  categories = {"crafting-with-fluid"},
    name = "77-exoskeleton-mk5-equipment",
    enabled = false,
    energy_required = 20, -- - -- { v7.1.3: 30>>20 }
    ingredients = 
    {
      { type = "item", name = "77-exoskeleton-mk4-equipment", amount = 1 },
      { type = "item", name = "productivity-module-3", amount = 25 }, -- - -- { v7.1.3: 10>>25 }
      { type = "item", name = "efficiency-module-3", amount = 25 }, -- - -- { v7.1.3: 10>>25 }
      
	    { type = "fluid", name = "lubricant", amount = 750 } -- - -- { v6.3.0: 500>>750 / v4.0.0 Changes: 400>500 }
    },
    results = { {type = "item", name = "77-exoskeleton-mk5-equipment", amount = 1 } }
  }

})