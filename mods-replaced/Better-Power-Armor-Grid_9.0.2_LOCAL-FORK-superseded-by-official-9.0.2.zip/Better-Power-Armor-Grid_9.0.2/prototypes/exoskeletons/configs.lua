local mod_name = "__ev-assets__"
local tiers = {"mk2", "mk3", "mk4", "mk5"}

-- <> -- { v6.3.0: Vanilla changes moved here } -- <> --

data.raw["movement-bonus-equipment"]["exoskeleton-equipment"].energy_consumption = "375kW" -- <> -- { v6.3.0: 150kW -> 375kW / v4.0.0 Changes: -150kW }
data.raw["movement-bonus-equipment"]["exoskeleton-equipment"].movement_bonus = 0.2 -- <> -- { v4.0.0 Changes: -0.3 }

-- <> -- { v6.3.0: Equipment division changes } -- <> --

if settings.startup["ev-armors-enabled"].value == true and settings.startup["ev-armor-division"].value == true then
  for i, tier in pairs (tiers) do
    table.insert(data.raw["movement-bonus-equipment"]["77-exoskeleton-"..tier.."-equipment"].categories, "ind_armor")
  end
end

-- <> -- { v7.1.0: Space age changes } -- <> --

if mods ["space-age"] then
    
  -- <> -- { Set the weight of every exoskeleton } -- <> --
  
  for i, tier in pairs (tiers) do
    if data.raw.item["77-exoskeleton-"..tier.."-equipment"] then
      data.raw.item["77-exoskeleton-"..tier.."-equipment"].weight = 0.10*tons
    end
  end

  -- table.insert(data.raw.technology["77-exoskeleton-mk3-equipment"].prerequisites, "electromagnetic-science-pack")
  table.insert(data.raw.technology["77-exoskeleton-mk3-equipment"].unit.ingredients, {"space-science-pack", 1})
  
  table.insert(data.raw.technology["77-exoskeleton-mk4-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-exoskeleton-mk4-equipment"].unit.ingredients, {"metallurgic-science-pack", 1})
  
  data.raw.technology["77-exoskeleton-mk5-equipment"].unit.count = 1000
  table.insert(data.raw.technology["77-exoskeleton-mk5-equipment"].prerequisites, "quantum-processor")
  table.insert(data.raw.technology["77-exoskeleton-mk5-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-exoskeleton-mk5-equipment"].unit.ingredients, {"metallurgic-science-pack", 1})
  table.insert(data.raw.technology["77-exoskeleton-mk5-equipment"].unit.ingredients, {"agricultural-science-pack", 1})
  table.insert(data.raw.technology["77-exoskeleton-mk5-equipment"].unit.ingredients, {"cryogenic-science-pack", 1})
end

-- <> -- { v6.3.0: Recipe difficulty changes via settings } -- <> --

local diff_setting = settings.startup["ev-equipment-recipe-difficulty"].value
local diff_idx = (diff_setting == "Easy" and 1) or (diff_setting == "Normal" and 2) or 3

-- Helper functions for adding prerequisites and modifying ingredients
local function add_prerequisite(tech_name, prereq_name)
    local tech = data.raw.technology[tech_name]
    if tech then
        tech.prerequisites = tech.prerequisites or {}
        table.insert(tech.prerequisites, prereq_name)
    end
end

-- Helper function to set or modify recipe ingredients
local function set_ingredient(recipe_name, index, item_name, amount)
    local recipe = data.raw.recipe[recipe_name]
    if recipe then
        recipe.ingredients = recipe.ingredients or {}
        recipe.ingredients[index] = { type = "item", name = item_name, amount = amount }
    end
end

local function modify_ingredient_amount(recipe_name, index, new_amount)
    if not new_amount then return end 
    
    local recipe = data.raw.recipe[recipe_name]
    if recipe and recipe.ingredients and recipe.ingredients[index] then
        local ing = recipe.ingredients[index]
        
        if ing.amount then
            ing.amount = new_amount
        else
            ing[2] = new_amount
        end
    end
end

-- Apply changes to recipe ingredients based on difficulty settings
if mods["space-age"] then
  modify_ingredient_amount("77-exoskeleton-mk2-equipment", 4, ({2, 4, 8})[diff_idx])

  modify_ingredient_amount("77-exoskeleton-mk3-equipment", 2, ({3, 7, 20})[diff_idx])
  modify_ingredient_amount("77-exoskeleton-mk3-equipment", 3, ({7, 15, 40})[diff_idx])

  modify_ingredient_amount("77-exoskeleton-mk4-equipment", 2, ({7, 15, 40})[diff_idx])

  modify_ingredient_amount("77-exoskeleton-mk5-equipment", 2, ({3, 7, 20})[diff_idx])
  modify_ingredient_amount("77-exoskeleton-mk5-equipment", 3, ({7, 15, 40})[diff_idx])
else
  modify_ingredient_amount("77-exoskeleton-mk2-equipment", 4, ({3, 5, 10})[diff_idx])

  modify_ingredient_amount("77-exoskeleton-mk3-equipment", 2, ({5, 10, 30})[diff_idx])
  modify_ingredient_amount("77-exoskeleton-mk3-equipment", 3, ({10, 20, 50})[diff_idx])

  modify_ingredient_amount("77-exoskeleton-mk4-equipment", 2, ({10, 25, 50})[diff_idx])

  modify_ingredient_amount("77-exoskeleton-mk5-equipment", 2, ({5, 15, 30})[diff_idx])
  modify_ingredient_amount("77-exoskeleton-mk5-equipment", 3, ({10, 25, 50})[diff_idx])
end

-- <> -- { Space age changes } -- <> --

if mods["space-age"] then
  local recipe_mk4 = data.raw.recipe["77-exoskeleton-mk4-equipment"]
  if recipe_mk4 then
    recipe_mk4.ingredients = recipe_mk4.ingredients or {}
    
    table.insert(recipe_mk4.ingredients, { 
      type = "item", 
      name = "tungsten-plate", 
      amount = ({20, 50, 80})[diff_idx] 
    })
  end

  local recipe_mk5 = data.raw.recipe["77-exoskeleton-mk5-equipment"]
  if recipe_mk5 then
    recipe_mk5.ingredients = recipe_mk5.ingredients or {}
    
    table.insert(recipe_mk5.ingredients, { 
      type = "item", 
      name = "quantum-processor", 
      amount = ({30, 60, 100})[diff_idx] 
    })
  end
end