local mod_name = "__ev-assets__"
local item_sounds = require("__base__.prototypes.item_sounds")

local tiers = {"mk2", "mk3", "mk4", "mk5"}
local properties = {
  { 20, 20, 20, 20 } -- Stack Sizes -- (v4.0.0 Changes: -10; -15; -15; -20)
}

data.raw.item["exoskeleton-equipment"].subgroup = "ev-exoskeletons"
data.raw.item["exoskeleton-equipment"].order = "aa"

for i, tier in pairs (tiers) do
	data:extend(
	{
		{
		  type = "item",
		  name = "77-exoskeleton-"..tier.."-equipment",
		  localized_name = "Exoskeleton "..tier.." equipment",
		  icon = mod_name.."/graphics/icons/exoskeleton-"..tier.."-equipment.png",
		  icon_size = 64, icon_mipmaps = 4,
		  place_as_equipment_result = "77-exoskeleton-"..tier.."-equipment",
		  subgroup = "ev-exoskeletons",
		  order = "ab",
		  inventory_move_sound = item_sounds.exoskeleton_inventory_move,
		  pick_sound = item_sounds.exoskeleton_inventory_pickup,
		  drop_sound = item_sounds.exoskeleton_inventory_move,
		  default_request_amount = 5,
		  stack_size = properties[1][i]
		}
	}) 
end