local mod_name = "__ev-assets__"

local tiers = {"mk2", "mk3", "mk4", "mk5"}
local properties = {
	-- Energy Consuption
	{
		"750kW", 		-- - -- { v6.3.0: 400kW -> 750kW / v4.0.0 Changes: -100kW }
		"1000kW", 		-- - -- { v6.3.0: 750kW -> 1000kW / v4.0.0 Changes: -0kW }
		"1250kW", 		-- - -- { v6.3.0: 1000kW -> 1250kW / v4.0.0 Changes: -500kW }
		"500kW" 		-- - -- { v6.3.0: 300kW -> 500kW / v4.0.0 Changes: +100kW }
	},
		-- Movement Bonus
	{
		0.4, 		-- - -- { v4.0.0 Changes: -0.35 }
		0.6, 		-- - -- { v4.0.0 Changes: -0.4 }
		0.8, 		-- - -- { v4.0.0 Changes: -0.45 }
		1.0 		-- - -- { v4.0.0 Changes: -0.5 }
	}
}

for i, tier in pairs (tiers) do
	data:extend({
		{
			type = "movement-bonus-equipment",
			name = "77-exoskeleton-"..tier.."-equipment",
			sprite =
			{
			  filename = mod_name.."/graphics/equipment/exoskeleton-"..tier.."-equipment.png",
			  width = 128,
			  height = 256,
			  priority = "medium",
			  scale = 0.5
			},
			shape =
			{
			  width = settings.startup["exoskeleton-equipment-width"].value,
			  height = settings.startup["exoskeleton-equipment-height"].value,
			  type = "full"
			},
			energy_source =
			{
			  type = "electric",
			  usage_priority = "secondary-input"
			},
			energy_consumption = properties[1][i],
			movement_bonus = properties[2][i] * settings.startup["exoskeleton-movement-bonus-multiplier"].value,
			categories = {"armor"}
		}
	})
end