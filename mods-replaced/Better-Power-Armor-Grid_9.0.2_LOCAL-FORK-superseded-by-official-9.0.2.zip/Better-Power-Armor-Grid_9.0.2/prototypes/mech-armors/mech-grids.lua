data:extend(
{
  {
    type = "equipment-grid",
    name = "huge-equipment-grid-mk2",
    width = settings.startup["ev-mech-grid-2"].value,
    height = settings.startup["ev-mech-grid-2"].value + 2,
    equipment_categories = {"armor"}
  },
  {
    type = "equipment-grid",
    name = "huge-equipment-grid-mk3",
    width = settings.startup["ev-mech-grid-3"].value,
    height = settings.startup["ev-mech-grid-3"].value + 2,
    equipment_categories = {"armor"}
  }
})

-- Adjust default mech equipment grid via settings
data.raw["equipment-grid"]["huge-equipment-grid"].width = settings.startup["ev-mech-grid-1"].value
data.raw["equipment-grid"]["huge-equipment-grid"].height = settings.startup["ev-mech-grid-1"].value + 2

if settings.startup["ev-armor-division"].value == true then
  table.insert(data.raw["equipment-grid"]["huge-equipment-grid-mk2"].equipment_categories, "ind_armor")
  table.insert(data.raw["equipment-grid"]["huge-equipment-grid-mk3"].equipment_categories, "ind_armor")
end