local mod_name = "__ev-assets__"

if settings.startup["ev-mech-max-tier"].value > 1 then
  data:extend(
  {
    {
      type = "technology",
      name = "77-mech-armor-mk2",
      icon = mod_name.."/graphics/technology/mech-armor-mk2.png",
      icon_size = 547,
      order = "g-e-c",
      prerequisites = {"mech-armor", "cryogenic-science-pack"},
      effects =
      {
        { type = "unlock-recipe", recipe = "77-mech-armor-mk2" }
      },
      unit =
      {
        count = 7500, -- x2 the mk1 amount
        ingredients =
        {
          {"automation-science-pack", 1},
          {"logistic-science-pack", 1},
          {"chemical-science-pack", 1},
          {"military-science-pack", 1},
          {"utility-science-pack", 1},
          {"space-science-pack", 1},
          {"electromagnetic-science-pack", 1},
          {"cryogenic-science-pack", 1}
        },
        time = 60
      }
    },
  })
end

if settings.startup["ev-mech-max-tier"].value > 2 then
  data:extend(
  {
    {
      type = "technology",
      name = "77-mech-armor-mk3",
      icon = mod_name.."/graphics/technology/mech-armor-mk3.png",
      icon_size = 547,
      order = "g-e-d",
      prerequisites = {"77-mech-armor-mk2", "promethium-science-pack"},
      effects =
      {
        { type = "unlock-recipe", recipe = "77-mech-armor-mk3" }
      },
      unit =
      {
        count = 15000, -- x5 the mk1 amount
        ingredients =
        {
          {"automation-science-pack", 1},
          {"logistic-science-pack", 1},
          {"chemical-science-pack", 1},
          {"military-science-pack", 1},
          {"utility-science-pack", 1},
          {"space-science-pack", 1},
          {"electromagnetic-science-pack", 1},
          {"cryogenic-science-pack", 1},
          {"promethium-science-pack", 1 }
        },
        time = 60
      }
    }
  })
end
