
if settings.startup["ev-mech-max-tier"].value > 1 then
  data:extend(
  {
    {
      type = "recipe",
      name = "77-mech-armor-mk2",
      enabled = false,
      energy_required = 80,
      ingredients =
      {
        { type = "item", name = settings.startup["ev-mech-grid-2-ingredient-1"].value, amount = settings.startup["ev-mech-grid-2-ingredient-1-amount"].value },
        { type = "item", name = settings.startup["ev-mech-grid-2-ingredient-2"].value, amount = settings.startup["ev-mech-grid-2-ingredient-2-amount"].value },
        { type = "item", name = settings.startup["ev-mech-grid-2-ingredient-3"].value, amount = settings.startup["ev-mech-grid-2-ingredient-3-amount"].value },
        { type = "item", name = settings.startup["ev-mech-grid-2-ingredient-4"].value, amount = settings.startup["ev-mech-grid-2-ingredient-4-amount"].value },
        { type = "item", name = "mech-armor", amount = 1 },
        { type = "item", name = "industrial-armor-mk2", amount = 1 }
      },
      results =
      {
        { type = "item", name = "77-mech-armor-mk2", amount = 1 }
      }
    }
  })
end

if settings.startup["ev-mech-max-tier"].value > 2 then
  data:extend(
  {
    {
      type = "recipe",
      name = "77-mech-armor-mk3",
      enabled = false,
      energy_required = 100,
      ingredients =
      {
        { type = "item", name = settings.startup["ev-mech-grid-3-ingredient-1"].value, amount = settings.startup["ev-mech-grid-3-ingredient-1-amount"].value },
        { type = "item", name = settings.startup["ev-mech-grid-3-ingredient-2"].value, amount = settings.startup["ev-mech-grid-3-ingredient-2-amount"].value },
        { type = "item", name = settings.startup["ev-mech-grid-3-ingredient-3"].value, amount = settings.startup["ev-mech-grid-3-ingredient-3-amount"].value },
        { type = "item", name = settings.startup["ev-mech-grid-3-ingredient-4"].value, amount = settings.startup["ev-mech-grid-3-ingredient-4-amount"].value },
        { type = "item", name = "77-mech-armor-mk2", amount = 1 }
      },
      results =
      {
        { type = "item", name = "77-mech-armor-mk3", amount = 1 }
      }
    }
  })
end