local mod_name = "__ev-assets__"

if settings.startup["ev-mech-max-tier"].value > 1 then
  data:extend(
  {
    {
      type = "armor",
      name = "77-mech-armor-mk2",
      icon = mod_name.."/graphics/icons/mech-armor-mk2.png",
      resistances =
      {
        {
          type = "physical",
          decrease = 25, -- base 10 +15 per tier
          percent = 60   -- base 50 +10% per tier
        },
        {
          type = "acid",
          decrease = 15, -- base 0 +15
          percent = 80   -- base 70 +10%
        },
        {
          type = "explosion",
          decrease = 75, -- base 60 +15
          percent = 60   -- base 50 +10%
        },
        {
          type = "fire",
          decrease = 25, -- base 10 +15
          percent = 80   -- base 70 +10%
        }
      },
      subgroup = "armor",
      order = "f[mech-armor]-b[77-mech-armor-mk2]",
      factoriopedia_simulation = nil,
      inventory_move_sound = nil,
      pick_sound = nil,
      drop_sound = nil,
      stack_size = 1,
      infinite = true,
      equipment_grid = "huge-equipment-grid-mk2",
      inventory_size_bonus = 75,
      provides_flight = true,
      takeoff_sound = nil,
      landing_sound = nil,
      flight_sound = nil,
      steps_sound = nil,
      moving_sound = nil,
      collision_box = {{-0.25, -0.25}, {0.25, 0.25}},
      drawing_box = {{-0.4, -2}, {0.4, 0}},
      open_sound = nil,
      close_sound = nil,
      weight = 1*tons
    },
  })
end

if settings.startup["ev-mech-max-tier"].value > 2 then
  data:extend(
  {
    {
      type = "armor",
      name = "77-mech-armor-mk3",
      icon = mod_name.."/graphics/icons/mech-armor-mk3.png",
      resistances =
      {
        {
          type = "physical",
          decrease = 40, -- base 10 +30
          percent = 70   -- base 50 +20%
        },
        {
          type = "acid",
          decrease = 30, -- base 0 +30
          percent = 90   -- base 70 +20%
        },
        {
          type = "explosion",
          decrease = 90, -- base 60 +30
          percent = 70   -- base 50 +20%
        },
        {
          type = "fire",
          decrease = 40, -- base 10 +30
          percent = 90   -- base 70 +20%
        }
      },
      subgroup = "armor",
      order = "f[mech-armor]-c[77-mech-armor-mk3]",
      factoriopedia_simulation = nil,
      inventory_move_sound = nil,
      pick_sound = nil,
      drop_sound = nil,
      stack_size = 1,
      infinite = true,
      equipment_grid = "huge-equipment-grid-mk3",
      inventory_size_bonus = 100,
      provides_flight = true,
      takeoff_sound = nil,
      landing_sound = nil,
      flight_sound = nil,
      steps_sound = nil,
      moving_sound = nil,
      collision_box = {{-0.25, -0.25}, {0.25, 0.25}},
      drawing_box = {{-0.4, -2}, {0.4, 0}},
      open_sound = nil,
      close_sound = nil,
      weight = 1*tons
    }
  })
end