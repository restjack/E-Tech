local mod_name = "__ev-assets__"

data:extend(
{

  {
    type = "technology",
    name = "77-fission-reactor-mk2-equipment",
    icon_size = 256,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/fission-reactor-mk2-equipment.png"),
    prerequisites =
    {
      "fission-reactor-equipment",
      "productivity-module-2",
      "efficiency-module-2"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-fission-reactor-mk2-equipment"
      }
    },
    unit =
    {
      count = 500, -- - -- { v7.1.0: 400>>500 | v6.2.0: 250>>400 | v4.0.0: +50 }
      ingredients =
      {
        {"automation-science-pack", 2}, -- - -- { v7.1.0: 2>>1 | v4.0.0: +1 }
        {"logistic-science-pack", 2}, -- - -- { v7.1.0: 2>>1 | v4.0.0: +1 }
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 30 -- - -- { v6.2.0: 45>>30 | v4.0.0: 50>>45 }
    },
  },
  {
    type = "technology",
    name = "77-fission-reactor-mk3-equipment",
    icon_size = 256,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/fission-reactor-mk3-equipment.png"),
    prerequisites =
    {
      "77-fission-reactor-mk2-equipment",
      "speed-module-2",
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-fission-reactor-mk3-equipment"
      }
    },
    unit =
    {
      count = 750, -- - -- { v7.1.0: 500>>750 }
      ingredients =
      {
        {"automation-science-pack", 1}, -- - -- { v7.1.0: 2>>1 | v4.0.0: +1 }
        {"logistic-science-pack", 1}, -- - -- { v7.1.0: 2>>1 | v4.0.0: +1 }
        {"chemical-science-pack", 1}, -- - -- { v7.1.0: 2>>1 | v4.0.0: +1 }
        {"military-science-pack", 1},
        {"production-science-pack", 1}, -- - -- { v7.1.0: 0>>1 }
        {"utility-science-pack", 1}
      },
      time = 45 -- - -- { v6.2.0: 60>>45 / v4.0.0 Changes: 150>>60 }
    },
  },
  {
    type = "technology",
    name = "77-fission-reactor-mk4-equipment",
    icon_size = 256,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/fission-reactor-mk4-equipment.png"),
    prerequisites =
    {
      "77-fission-reactor-mk3-equipment",
      "productivity-module-3",
      "efficiency-module-3",
      "speed-module-3"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-fission-reactor-mk4-equipment"
      }
    },
    unit =
    {
      count = 1000, -- - -- { v7.1.0: 750>>1000 }
      ingredients =
      {
        {"automation-science-pack", 1}, -- - -- { v7.1.0: 2>>1 | v4.0.0: +1 / +750 }
        {"logistic-science-pack", 1}, -- - -- { v7.1.0: 2>>1 | v4.0.0: +1 / +750 }
        {"chemical-science-pack", 1}, -- - -- { v7.1.0: 2>>1 | v4.0.0: +1 / +750 }
        {"military-science-pack", 1},
        {"production-science-pack", 1}, -- - -- { v6.2.0: 0>>1 }
        {"utility-science-pack", 1},
        {"space-science-pack", 1} -- - -- { v7.1.0: 0>>1 }
      },
      time = 60 -- - -- { v7.1.0: 45>>60 | v6.2.0: 75>>45 / v4.0.0: -225s }
    },
  },
})