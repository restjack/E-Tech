local mod_name = "__ev-assets__"

-- <> -- { v7.1.0: Reactor recipes } -- <> --

data:extend(
{
  {
    type = "recipe",
    name = "77-fission-reactor-mk2-equipment",
    enabled = false,
    energy_required = 12.5,
    ingredients =
    {
      { type = "item", name = "fission-reactor-equipment", amount = 1 },
      { type = "item", name = "productivity-module-2", amount = 10 },
      { type = "item", name = "efficiency-module-2", amount = 10 },

      { type = "item", name = "uranium-fuel-cell", amount = 10 }
    },
    results = { {type = "item", name = "77-fission-reactor-mk2-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "77-fission-reactor-mk3-equipment",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      { type = "item", name = "77-fission-reactor-mk2-equipment", amount = 1 },
      { type = "item", name = "productivity-module-2", amount = 5 },
      { type = "item", name = "efficiency-module-2", amount = 5 },
      { type = "item", name = "speed-module-2", amount = 5 },

      { type = "item", name = "uranium-fuel-cell", amount = 20 }
    },
    results = { {type = "item", name = "77-fission-reactor-mk3-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "77-fission-reactor-mk4-equipment",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      { type = "item", name = "77-fission-reactor-mk3-equipment", amount = 1 },
      { type = "item", name = "productivity-module-3", amount = 5 },
      { type = "item", name = "efficiency-module-3", amount = 5 },
      { type = "item", name = "speed-module-3", amount = 5 },

      { type = "item", name = "uranium-fuel-cell", amount = 40 }
    },
    results = { {type = "item", name = "77-fission-reactor-mk4-equipment", amount = 1 } }
  },
})