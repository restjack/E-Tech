local mod_name = "__ev-assets__"
local item_sounds = require("__base__.prototypes.item_sounds")

local tiers = {"mk2", "mk3", "mk4"}

-- <> -- { v7.1.0: Reactor properties } -- <> --

local properties = {
  { 20, 20, 20, 20, 20 } -- - -- Stack Sizes
}

-- <> -- { v7.1.0: Reactor items } -- <> --

for i, tier in pairs (tiers) do
	data:extend(
	{
	  {
		type = "item",
		name = "77-fission-reactor-"..tier.."-equipment",
		icon = mod_name.."/graphics/icons/fission-reactor-"..tier.."-equipment.png",
		icon_size = 64, icon_mipmaps = 4,
		place_as_equipment_result = "77-fission-reactor-"..tier.."-equipment",
		subgroup = "ev-fission",
		order = "ab",
		inventory_move_sound = item_sounds.reactor_inventory_move,
		pick_sound = item_sounds.reactor_inventory_pickup,
		drop_sound = item_sounds.reactor_inventory_move,
		default_request_amount = 5, -- { v6.2.0: 1 -> 5 }
		stack_size = properties[1][i]
	  }
	})
end