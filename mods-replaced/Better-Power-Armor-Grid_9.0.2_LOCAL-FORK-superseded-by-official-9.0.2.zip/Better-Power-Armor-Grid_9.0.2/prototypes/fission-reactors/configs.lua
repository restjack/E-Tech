local mod_name = "__ev-assets__"
local item_sounds = require("__base__.prototypes.item_sounds")

-- - -- { File edited in version: v7.1.0 } -- - --

-- - -- { v7.1.0: Vanilla changes } -- - --

data.raw.item["fission-reactor-equipment"].subgroup = "ev-fission"
data.raw.item["fission-reactor-equipment"].order = "aa"

-- - -- { v7.1.0: Equipment division } -- - --

local tiers = {"mk2", "mk3", "mk4"}

if settings.startup["ev-armors-enabled"].value == true and settings.startup["ev-armor-division"].value == true then
    for i, tier in pairs (tiers) do
        table.insert(data.raw["generator-equipment"]["77-fission-reactor-"..tier.."-equipment"].categories, "ind_armor")
    end
end

-- - -- { v7.1.0: Fission equipment startup settings } -- - --

if mods ["space-age"] then
else
    for i, tier in pairs (tiers) do
        local width = settings.startup["fission-reactor-equipment-width"].value
        local height = settings.startup["fission-reactor-equipment-height"].value
        local power = {1.0, 1.5, 3.0}
        data.raw["generator-equipment"]["77-fission-reactor-"..tier.."-equipment"].shape.width = width
        data.raw["generator-equipment"]["77-fission-reactor-"..tier.."-equipment"].shape.height = height
        data.raw["generator-equipment"]["77-fission-reactor-"..tier.."-equipment"].power = power[i] * settings.startup["fission-reactor-power-multiplier"].value .."MW"
    end
end

-- - -- { v7.1.0: Space age changes } -- - --

if mods ["space-age"] then
    
    -- <> -- { Set the weight of every fission reactor } -- <> --
    for i, tier in pairs (tiers) do
        if data.raw.item["77-fission-reactor-"..tier.."-equipment"] then
            data.raw.item["77-fission-reactor-"..tier.."-equipment"].weight = 0.25*tons
        end
    end

    -- - -- { v7.1.0: Power output changes } -- - --
    for i, tier in pairs (tiers) do
        local width = settings.startup["fission-reactor-equipment-width"].value
        local height = settings.startup["fission-reactor-equipment-height"].value
        local power = {1.0, 1.5, 2.0}
        data.raw["generator-equipment"]["77-fission-reactor-"..tier.."-equipment"].shape.width = width
        data.raw["generator-equipment"]["77-fission-reactor-"..tier.."-equipment"].shape.height = height
        data.raw["generator-equipment"]["77-fission-reactor-"..tier.."-equipment"].power = power[i] * settings.startup["fission-reactor-power-multiplier"].value .."MW"
    end
    
    -- - -- { v7.1.0: Recipe changes } -- - --
    data.raw.recipe["77-fission-reactor-mk3-equipment"].ingredients =
    {
        { type = "item", name = "77-fission-reactor-mk2-equipment", amount = 1 },
        { type = "item", name = "speed-module-2", amount = 10 },

        { type = "item", name = "superconductor", amount = 25 },
        { type = "item", name = "supercapacitor", amount = 10 }
    }
    data.raw.recipe["77-fission-reactor-mk4-equipment"].ingredients =
    {
        { type = "item", name = "77-fission-reactor-mk3-equipment", amount = 1 },
        { type = "item", name = "productivity-module-3", amount = 2 },
        { type = "item", name = "efficiency-module-3", amount = 3 },
        { type = "item", name = "quality-module-3", amount = 2 },
        { type = "item", name = "speed-module-3", amount = 3 }
    }
    
    -- - -- { v7.1.0: Technology changes } -- - --
    table.insert(data.raw.technology["77-fission-reactor-mk2-equipment"].unit.ingredients, {"space-science-pack", 1})

    table.insert(data.raw.technology["77-fission-reactor-mk3-equipment"].prerequisites, "electromagnetic-science-pack")
    table.insert(data.raw.technology["77-fission-reactor-mk3-equipment"].unit.ingredients, {"space-science-pack", 1})
    table.insert(data.raw.technology["77-fission-reactor-mk3-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})

    table.insert(data.raw.technology["77-fission-reactor-mk4-equipment"].prerequisites, "quality-module-3")
    table.insert(data.raw.technology["77-fission-reactor-mk4-equipment"].unit.ingredients, {"metallurgic-science-pack", 1})
    table.insert(data.raw.technology["77-fission-reactor-mk4-equipment"].unit.ingredients, {"agricultural-science-pack", 1})
    table.insert(data.raw.technology["77-fission-reactor-mk4-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})
end

-- <> -- { v9.0.0: Recipe difficulty changes via settings } -- <> --

local diff_setting = settings.startup["ev-equipment-recipe-difficulty"].value
local diff_idx = (diff_setting == "Easy" and 1) or (diff_setting == "Normal" and 2) or 3

local function modify_ingredient_amount(recipe_name, index, new_amount)
    if not new_amount then return end 
    
    local recipe = data.raw.recipe[recipe_name]
    if recipe and recipe.ingredients and recipe.ingredients[index] then
        local ing = recipe.ingredients[index]
        
        if ing.amount then
            ing.amount = new_amount
        else
            ing[2] = new_amount
        end
    end
end

if mods ["space-age"] then
  modify_ingredient_amount("77-fission-reactor-mk2-equipment", 2, ({3, 7, 15})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk2-equipment", 3, ({5, 10, 25})[diff_idx])
  
  modify_ingredient_amount("77-fission-reactor-mk3-equipment", 2, ({1, 3, 10})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk3-equipment", 3, ({3, 5, 15})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk3-equipment", 4, ({3, 5, 15})[diff_idx])
  
  modify_ingredient_amount("77-fission-reactor-mk4-equipment", 2, ({1, 3, 10})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk4-equipment", 3, ({3, 5, 15})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk4-equipment", 4, ({3, 5, 15})[diff_idx])
else
  modify_ingredient_amount("77-fission-reactor-mk2-equipment", 2, ({5, 10, 25})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk2-equipment", 3, ({5, 10, 25})[diff_idx])
  
  modify_ingredient_amount("77-fission-reactor-mk3-equipment", 2, ({2, 5, 15})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk3-equipment", 3, ({3, 5, 15})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk3-equipment", 4, ({3, 5, 15})[diff_idx])
  
  modify_ingredient_amount("77-fission-reactor-mk4-equipment", 2, ({2, 5, 15})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk4-equipment", 3, ({3, 5, 15})[diff_idx])
  modify_ingredient_amount("77-fission-reactor-mk4-equipment", 4, ({3, 5, 15})[diff_idx])
end