local mod_name = "__ev-assets__"
local tiers = {"mk2", "mk3", "mk4"}

local properties = {
	{ 4, 4, 4 }, -- - -- Width
	{ 4, 4, 4 }, -- - -- Height
	{"1.0MW", "1.5MW", "3.0MW"} -- - -- Power generation
}

-- <> -- { v7.1.0: Reactor equipments } -- <> --

for i, tier in pairs (tiers) do
  data:extend(
  {
		{
			type = "generator-equipment",
			name = "77-fission-reactor-"..tier.."-equipment",
			sprite =
			{
				filename = mod_name.."/graphics/equipment/fission-reactor-"..tier.."-equipment.png",
				width = 256,
				height = 256,
				priority = "medium",
				scale = 0.5
			},
			shape =
			{
				width = properties[1][i],
				height = properties[2][i],
				type = "full"
			},
			energy_source =
			{
				type = "electric",
				usage_priority = "primary-output"
			},
			power = properties[3][i],
			categories = {"armor"}
		}
  })
end