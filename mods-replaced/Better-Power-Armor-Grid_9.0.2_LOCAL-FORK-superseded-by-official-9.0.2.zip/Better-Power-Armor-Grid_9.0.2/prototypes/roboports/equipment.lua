local mod_name = "__ev-assets__"

local tiers = {"mk3", "mk4", "mk5", "mk6"}

local roboport_base_size = settings.startup["roboports-equipment-size"].value
local largeness = { -- (v4.0.0 Balances: -1; -2; -2; -1)
  roboport_base_size,
  roboport_base_size,
  roboport_base_size + 1,
  roboport_base_size + 1
}
local energy = {
  {"75MJ", "150MJ", "300MJ", "500MJ"}, -- buffer_capacity -- (v4.0.0 Balances: -25MJ; +0MJ; 50MJ; 200MJ)
  {"7.5MW", "22.5MW", "60MW", "125MW"}, -- input_flow_limit -- (v4.0.0 Balances: -2.5MW; +7.5MW; +35MW; +65MW)
  {"1250kW", "1500kW", "2500kW", "5000kW"} -- charging_energy -- (v4.0.0 Balances: -250kW; -1000kW; -2500kW; -3000kW)
}
local properties = {
  { 75, 125, 225, 250 }, -- robot_limit -- (v4.0.0 Balances: -25; +0; +75; +75)
  { 37.5, 50, 75, 100 }, -- construction_radius -- (v4.0.0 Balances: +12.5; +20; +35; +100)
  { 0.5, 1.0, 1.5, 2.0 }, -- spawn_and_station_height
  { 0.4, 0.9, 1.4, 1.9 }, -- spawn_and_station_shadow_height_offset
  { 2.7, 3.2, 3.7, 4.2 }, -- charge_approach_distance -- (v4.0.0 Balances: +12.5; +20; +35; +100)
  { 10, 15, 25, 30 }, -- charging_station_count -- (v4.0.0 Balances: +4; +8; +17; +20)
  { 1.7, 2.2, 2.7, 3.2 } -- charging_distance -- (v4.0.0 Balances: +0.2; +0; +0.5; +0.5)
}



-- - -- { v5.0.0: change size via settings } -- - --

if settings.startup["roboports-robot-limit"].value == "Small" then
  properties[2] = { 50, 100, 150, 200 }
elseif settings.startup["roboports-robot-limit"].value == "Medium" then
  properties[2] = { 75, 125, 225, 250 }
elseif settings.startup["roboports-robot-limit"].value == "Large" then
  properties[2] = { 100, 150, 250, 300 }
elseif settings.startup["roboports-robot-limit"].value == "Behemoth" then
  properties[2] = { 150, 250, 350, 500 }
end

if settings.startup["roboports-construction-radious"].value == "Small" then
  properties[2] = { 37.5, 40, 50, 75 }
elseif settings.startup["roboports-construction-radious"].value == "Medium" then
  properties[2] = { 37.5, 50, 75, 100 }
elseif settings.startup["roboports-construction-radious"].value == "Large" then
  properties[2] = { 40, 55, 80, 110 }
elseif settings.startup["roboports-construction-radious"].value == "Behemoth" then
  properties[2] = { 50, 75, 100, 150 }
end



-- - -- { Equipment } -- - --

local mk2_sprite_fix = data.raw["roboport-equipment"]["personal-roboport-mk2-equipment"].sprite
mk2_sprite_fix.filename = mod_name.."/graphics/equipment/personal-roboport-mk2-equipment.png"
--mk2_sprite_fix.hr_version.filename = mod_name.."/graphics/equipment/hr-personal-roboport-mk2-equipment.png"

for i, tier in pairs (tiers) do

  data:extend(
  {
    {
      type = "roboport-equipment",
      name = "77-personal-roboport-"..tier.."-equipment",
      take_result = "77-personal-roboport-"..tier.."-equipment",
      sprite =
      {
        filename = mod_name.."/graphics/equipment/personal-roboport-"..tier.."-equipment.png",
        width = 128,
        height = 128,
        priority = "medium",
        scale = 0.5
      },
      shape =
      {
        width = largeness[i],
        height = largeness[i],
        type = "full"
      },
      energy_source =
      {
        type = "electric",
        buffer_capacity = energy[1][i],
        input_flow_limit = energy[2][i],
        usage_priority = "secondary-input"
      },
      charging_energy = energy[3][i],
  
      robot_limit = properties[1][i],
      construction_radius = properties[2][i],
      spawn_and_station_height = properties[3][i],
      spawn_and_station_shadow_height_offset = properties[4][i],
      charge_approach_distance = properties[5][i],
      robots_shrink_when_entering_and_exiting = true,
  
      recharging_animation =
      {
        filename = "__base__/graphics/entity/roboport/roboport-recharging.png",
        draw_as_glow = true,
        priority = "high",
        width = 37,
        height = 35,
        frame_count = 16,
        scale = 1.5,
        animation_speed = 0.5
      },
      recharging_light = {intensity = 0.2, size = 3, color = {r = 0.5, g = 0.5, b = 1.0}},
      stationing_offset = {0, -0.6},
      charging_station_shift = {0, 0.5},
      charging_station_count = properties[6][i],
      charging_distance = properties[7][i],
      charging_threshold_distance = 5,
      categories = {"armor"}
    }
  })

end