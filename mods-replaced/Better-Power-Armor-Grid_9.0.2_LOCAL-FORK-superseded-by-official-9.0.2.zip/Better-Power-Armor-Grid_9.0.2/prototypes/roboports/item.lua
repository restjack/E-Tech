local mod_name = "__ev-assets__"
local item_sounds = require("__base__.prototypes.item_sounds")

local tiers = {"mk3", "mk4", "mk5", "mk6"}

local tier_stack_size =
{
	10, -- - -- { v4.0.0: 15>>10 }
	10, -- - -- { v4.0.0: 15>>10 }
	5, -- - -- { v4.0.0: 10>>5 }
	5 -- - -- { v4.0.0: 10>>5 }
}

for i, tier in pairs (tiers) do
	data:extend(
	{
		{
			type = "item",
			name = "77-personal-roboport-"..tier.."-equipment",
			icon = mod_name.."/graphics/icons/personal-roboport-"..tier.."-equipment.png",
			icon_size = 64,
			place_as_equipment_result = "77-personal-roboport-"..tier.."-equipment",
			subgroup = "ev-roboports",
			order = "ac",
			inventory_move_sound = item_sounds.roboport_inventory_move,
			pick_sound = item_sounds.roboport_inventory_pickup,
			drop_sound = item_sounds.roboport_inventory_move,
			stack_size = tier_stack_size[i]
		}
	})
end