local mod_name = "__ev-assets__"

local tiers = {"mk3", "mk4", "mk5", "mk6"}

-- <> -- { v7.0.0: Custom roboport settings can be found in the equipment.lua/item.lua files } -- <> --

-- <> -- { v3.0.0: Vanilla changes } -- <> --

data.raw.item["personal-roboport-mk2-equipment"].icon = mod_name.."/graphics/icons/personal-roboport-mk2-equipment.png"
data.raw["roboport-equipment"]["personal-roboport-mk2-equipment"].sprite.filename = mod_name.."/graphics/equipment/personal-roboport-mk2-equipment.png"

data.raw.item["personal-roboport-equipment"].subgroup = "ev-roboports"
data.raw.item["personal-roboport-equipment"].order = "aa"

data.raw.item["personal-roboport-mk2-equipment"].subgroup = "ev-roboports"
data.raw.item["personal-roboport-mk2-equipment"].order = "ab"

-- <> -- { v3.0.0: Ev modpack tweaks } -- <> -- <> --

if settings.startup["ev-armors-enabled"].value == true then
  if settings.startup["ev-armor-division"].value == true then
    for i, tier in pairs (tiers) do 
        data.raw["roboport-equipment"]["77-personal-roboport-"..tier.."-equipment"].categories = {"ind_armor"}
    end
  else
    for i, tier in pairs (tiers) do 
        data.raw["roboport-equipment"]["77-personal-roboport-"..tier.."-equipment"].categories = {"armor", "ind_armor"}
    end
  end
end

-- <> -- { v9.0.0: Recipe difficulty changes via settings } -- <> --

local diff_setting = settings.startup["ev-equipment-recipe-difficulty"].value
local diff_idx = (diff_setting == "Easy" and 1) or (diff_setting == "Normal" and 2) or 3

local function modify_ingredient_amount(recipe_name, index, new_amount)
    if not new_amount then return end 
    
    local recipe = data.raw.recipe[recipe_name]
    if recipe and recipe.ingredients and recipe.ingredients[index] then
        local ing = recipe.ingredients[index]
        
        if ing.amount then
            ing.amount = new_amount
        else
            ing[2] = new_amount
        end
    end
end

-- <> -- { v7.1.0: Space age changes } -- <> --

if mods ["space-age"] then
    
  -- <> -- { Set the weight of every roboport } -- <> --
  for i, tier in pairs (tiers) do
      if data.raw.item["77-personal-roboport-"..tier.."-equipment"] then
        data.raw.item["77-personal-roboport-"..tier.."-equipment"].weight = 0.5*tons
      end
  end

  -- { Personal laser defense mk3 equipment }
  table.insert(data.raw.technology["77-personal-roboport-mk3-equipment"].prerequisites, "tungsten-carbide")
  table.insert(data.raw.technology["77-personal-roboport-mk3-equipment"].prerequisites, "quality-module-3")
  table.insert(data.raw.technology["77-personal-roboport-mk3-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk3-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})
  data.raw.recipe["77-personal-roboport-mk3-equipment"].ingredients =
  {
    { type = "item", name = "personal-roboport-mk2-equipment", amount = 4 },
    { type = "item", name = "tungsten-carbide", amount = 30 },
    { type = "item", name = "quality-module-3", amount = 10 }
  }
  modify_ingredient_amount("77-personal-roboport-mk3-equipment", 2, ({15, 30, 75})[diff_idx])
  modify_ingredient_amount("77-personal-roboport-mk3-equipment", 3, ({5, 10, 25})[diff_idx])
  
  -- { Personal laser defense mk4 equipment }
  table.insert(data.raw.technology["77-personal-roboport-mk4-equipment"].prerequisites, "carbon-fiber")
  table.insert(data.raw.technology["77-personal-roboport-mk4-equipment"].prerequisites, "speed-module-3")
  table.insert(data.raw.technology["77-personal-roboport-mk4-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk4-equipment"].unit.ingredients, {"metallurgic-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk4-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})
  data.raw.recipe["77-personal-roboport-mk4-equipment"].ingredients =
  {
    { type = "item", name = "77-personal-roboport-mk3-equipment", amount = 3 },
    { type = "item", name = "tungsten-plate", amount = 50 },
    { type = "item", name = "carbon-fiber", amount = 100 },
    { type = "item", name = "speed-module-3", amount = 10 }
  }
  modify_ingredient_amount("77-personal-roboport-mk4-equipment", 2, ({25, 50, 125})[diff_idx])
  modify_ingredient_amount("77-personal-roboport-mk4-equipment", 3, ({50, 100, 200})[diff_idx])
  modify_ingredient_amount("77-personal-roboport-mk4-equipment", 4, ({5, 10, 25})[diff_idx])
  
  -- { Personal laser defense mk5 equipment }
  table.insert(data.raw.technology["77-personal-roboport-mk5-equipment"].prerequisites, "cryogenic-science-pack")
  table.insert(data.raw.technology["77-personal-roboport-mk5-equipment"].prerequisites, "efficiency-module-3")
  table.insert(data.raw.technology["77-personal-roboport-mk5-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk5-equipment"].unit.ingredients, {"cryogenic-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk5-equipment"].unit.ingredients, {"metallurgic-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk5-equipment"].unit.ingredients, {"agricultural-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk5-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})
  data.raw.recipe["77-personal-roboport-mk5-equipment"].ingredients =
  {
    { type = "item", name = "77-personal-roboport-mk4-equipment", amount = 2 },
    { type = "item", name = "lithium-plate", amount = 50 },
    { type = "item", name = "efficiency-module-3", amount = 10 }
  }
  modify_ingredient_amount("77-personal-roboport-mk5-equipment", 2, ({25, 50, 150})[diff_idx])
  modify_ingredient_amount("77-personal-roboport-mk5-equipment", 3, ({5, 10, 25})[diff_idx])
  
  -- { Personal laser defense mk6 equipment }
  table.insert(data.raw.technology["77-personal-roboport-mk6-equipment"].prerequisites, "promethium-science-pack")
  table.insert(data.raw.technology["77-personal-roboport-mk6-equipment"].unit.ingredients, {"cryogenic-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk6-equipment"].unit.ingredients, {"metallurgic-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk6-equipment"].unit.ingredients, {"agricultural-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk6-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})
  table.insert(data.raw.technology["77-personal-roboport-mk6-equipment"].unit.ingredients, {"promethium-science-pack", 1})
  data.raw.recipe["77-personal-roboport-mk6-equipment"].ingredients =
  {
    { type = "item", name = "77-personal-roboport-mk5-equipment", amount = 1 },
    { type = "item", name = "quantum-processor", amount = 200 },
    { type = "item", name = "productivity-module-3", amount = 20 }
  }
  modify_ingredient_amount("77-personal-roboport-mk6-equipment", 2, ({100, 200, 500})[diff_idx])
  modify_ingredient_amount("77-personal-roboport-mk6-equipment", 3, ({10, 20, 40})[diff_idx])
end