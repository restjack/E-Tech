data:extend(
{

  {
    type = "recipe",
    name = "77-personal-roboport-mk3-equipment",
    enabled = false,
    energy_required = 30, -- - -- { v4.0.0: 25>>30 }
    ingredients =
    {
      { type = "item", name = "personal-roboport-mk2-equipment", amount = 4 },
      { type = "item", name = "low-density-structure", amount = 30 },
      { type = "item", name = "processing-unit", amount = 100 }, -- - -- { v7.1.3: 120>>100 }
      { type = "item", name = "speed-module-2", amount = 10 }
    },
    results = { {type = "item", name = "77-personal-roboport-mk3-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "77-personal-roboport-mk4-equipment",
    enabled = false,
    energy_required = 32.5, -- - -- { v7.1.3: 35>>32.5 | v4.0.0: 30>>35 }
    ingredients =
    {
      { type = "item", name = "77-personal-roboport-mk3-equipment", amount = 3 },
      { type = "item", name = "low-density-structure", amount = 100 },
      { type = "item", name = "processing-unit", amount = 150 }, -- - -- { v7.1.3: 200>>150 }
      { type = "item", name = "productivity-module-2", amount = 20 }, -- - -- { v7.1.3: 25>>20 }
      { type = "item", name = "efficiency-module-2", amount = 20 } -- - -- { v7.1.3: 25>>20 }
    },
    results = { {type = "item", name = "77-personal-roboport-mk4-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "77-personal-roboport-mk5-equipment",
    enabled = false,
    energy_required = 35, -- - -- { v7.1.3: 55>>35 | v4.0.0: 35>>55 }
    ingredients =
    {
      { type = "item", name = "77-personal-roboport-mk4-equipment", amount = 2 },
      { type = "item", name = "low-density-structure", amount = 150 }, -- - -- { v7.1.3: 200>>150 }
      { type = "item", name = "speed-module-3", amount = 30 } -- - -- { v7.1.3: 25>>30 }
    },
    results = { {type = "item", name = "77-personal-roboport-mk5-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "77-personal-roboport-mk6-equipment",
    enabled = false,
    energy_required = 40, -- - -- { v7.1.3: 60>>40 | v4.0.0: 40>>60 }
    ingredients =
    {
      { type = "item", name = "77-personal-roboport-mk5-equipment", amount = 1 },
      { type = "item", name = "productivity-module-3", amount = 30 }, -- - -- { v7.1.3: 0>>30 }
      { type = "item", name = "efficiency-module-3", amount = 30 } -- - -- { v7.1.3: 35>>30 }
    },
    results = { {type = "item", name = "77-personal-roboport-mk6-equipment", amount = 1 } }
  }
  
})