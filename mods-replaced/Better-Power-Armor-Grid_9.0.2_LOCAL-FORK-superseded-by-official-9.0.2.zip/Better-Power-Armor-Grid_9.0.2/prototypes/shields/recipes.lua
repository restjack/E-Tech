data:extend(
{

  {
    type = "recipe",
    name = "77-energy-shield-mk3-equipment",
    enabled = false,
    energy_required = 12.5, -- - -- { v7.1.3: 15>>12.5 }
    ingredients =
    {
      { type = "item", name = "energy-shield-mk2-equipment", amount = 5 }, -- - -- { v7.1.3: 6>>5 }
      { type = "item", name = "processing-unit", amount = 15 },
      { type = "item", name = "efficiency-module-2", amount = 5 }, -- - -- { v7.1.3: 0>>5 }
      { type = "item", name = "speed-module-2", amount = 5 } -- - -- { v7.1.3: 0>>5 }
    },
    results = { {type = "item", name = "77-energy-shield-mk3-equipment", amount = 1 } }
  },

  {
    type = "recipe",
    name = "77-energy-shield-mk4-equipment",
    enabled = false,
    energy_required = 17.5, -- - -- { v7.1.3: 20>>17.5 }
    ingredients =
    {
      { type = "item", name = "77-energy-shield-mk3-equipment", amount = 3 }, -- - -- { v7.1.3: 5>>3 }
      { type = "item", name = "processing-unit", amount = 25 }, -- - -- { v7.1.3: 20>>25 }
      { type = "item", name = "efficiency-module-3", amount = 5 }, -- - -- { v7.1.3: 3>>5 }
    },
    results = { {type = "item", name = "77-energy-shield-mk4-equipment", amount = 1 } }
  },

  {
    type = "recipe",
    name = "77-energy-shield-mk5-equipment",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      { type = "item", name = "77-energy-shield-mk4-equipment", amount = 1 }, -- - -- { v7.1.3: 4>>1 }
      { type = "item", name = "processing-unit", amount = 50 }, -- - -- { v7.1.3: 20>>50 }
      { type = "item", name = "productivity-module-3", amount = 5 }, -- - -- { v7.1.3: 0>>5 }
      { type = "item", name = "speed-module-3", amount = 5 }, -- - -- { v7.1.3: 0>>5 }
    },
    results = { {type = "item", name = "77-energy-shield-mk5-equipment", amount = 1 } }
  }
	
})