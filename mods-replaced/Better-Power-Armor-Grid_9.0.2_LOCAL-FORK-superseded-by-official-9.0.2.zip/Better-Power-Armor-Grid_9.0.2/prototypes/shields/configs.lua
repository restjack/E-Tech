-- - { Ev modpack tweaks } - --

local tiers = {"mk3", "mk4", "mk5"}

if settings.startup["ev-armors-enabled"].value == true and settings.startup["ev-armor-division"].value == false then
  for i, tier in pairs (tiers) do 
      data.raw["energy-shield-equipment"]["77-energy-shield-"..tier.."-equipment"].categories = {"armor", "ind_armor"}
  end
end

if mods ["space-age"] then
else
  if settings.startup["ev-armors-enabled"].value == true then
    evanilla.tech.add_prerequisite("77-energy-shield-mk3-equipment", "77-power-armor-mk3")
    evanilla.tech.add_prerequisite("77-energy-shield-mk4-equipment", "77-power-armor-mk4")
    evanilla.tech.add_prerequisite("77-energy-shield-mk5-equipment", "77-power-armor-mk5")
  end
end

-- <> -- { v9.0.0: Recipe difficulty changes via settings } -- <> --

local diff_setting = settings.startup["ev-equipment-recipe-difficulty"].value
local diff_idx = (diff_setting == "Easy" and 1) or (diff_setting == "Normal" and 2) or 3

local function modify_ingredient_amount(recipe_name, index, new_amount)
    if not new_amount then return end 
    
    local recipe = data.raw.recipe[recipe_name]
    if recipe and recipe.ingredients and recipe.ingredients[index] then
        local ing = recipe.ingredients[index]
        
        if ing.amount then
            ing.amount = new_amount
        else
            ing[2] = new_amount
        end
    end
end

-- <> -- { v7.1.0: Space age changes } -- <> --

if mods ["space-age"] then
    
  -- <> -- { Set the weight of every shield } -- <> --
  for i, tier in pairs (tiers) do
      if data.raw.item["77-energy-shield-"..tier.."-equipment"] then
        data.raw.item["77-energy-shield-"..tier.."-equipment"].weight = 0.1*tons
      end
  end

  -- { Energy shield mk3 equipment }
  table.insert(data.raw.technology["77-energy-shield-mk3-equipment"].prerequisites, "quality-module-3")
  table.insert(data.raw.technology["77-energy-shield-mk3-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-energy-shield-mk3-equipment"].unit.ingredients, {"utility-science-pack", 1})
  table.insert(data.raw.technology["77-energy-shield-mk3-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})
  data.raw.recipe["77-energy-shield-mk3-equipment"].ingredients =
  {
    { type = "item", name = "energy-shield-mk2-equipment", amount = 5 },
    { type = "item", name = "supercapacitor", amount = 20 },
    { type = "item", name = "quality-module-3", amount = 10 }
  }
  modify_ingredient_amount("77-energy-shield-mk3-equipment", 2, ({10, 20, 50})[diff_idx])
  modify_ingredient_amount("77-energy-shield-mk3-equipment", 3, ({5, 10, 20})[diff_idx])
  
  -- { Energy shield mk4 equipment }
  table.insert(data.raw.technology["77-energy-shield-mk4-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-energy-shield-mk4-equipment"].unit.ingredients, {"agricultural-science-pack", 1})
  table.insert(data.raw.technology["77-energy-shield-mk4-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})
  data.raw.recipe["77-energy-shield-mk4-equipment"].ingredients =
  {
    { type = "item", name = "77-energy-shield-mk3-equipment", amount = 3 },
    { type = "item", name = "supercapacitor", amount = 25 },
    { type = "item", name = "efficiency-module-3", amount = 5 },
  }
  modify_ingredient_amount("77-energy-shield-mk4-equipment", 2, ({10, 25, 50})[diff_idx])
  modify_ingredient_amount("77-energy-shield-mk4-equipment", 3, ({2, 5, 15})[diff_idx])
  
  -- { Energy shield mk5 equipment }
  table.insert(data.raw.technology["77-energy-shield-mk5-equipment"].prerequisites, "quantum-processor")
  table.insert(data.raw.technology["77-energy-shield-mk5-equipment"].unit.ingredients, {"space-science-pack", 1})
  table.insert(data.raw.technology["77-energy-shield-mk5-equipment"].unit.ingredients, {"cryogenic-science-pack", 1})
  table.insert(data.raw.technology["77-energy-shield-mk5-equipment"].unit.ingredients, {"agricultural-science-pack", 1})
  table.insert(data.raw.technology["77-energy-shield-mk5-equipment"].unit.ingredients, {"electromagnetic-science-pack", 1})
  data.raw.recipe["77-energy-shield-mk5-equipment"].ingredients =
  {
    { type = "item", name = "77-energy-shield-mk4-equipment", amount = 1 },
    { type = "item", name = "quantum-processor", amount = 50 },
    { type = "item", name = "productivity-module-3", amount = 5 },
    { type = "item", name = "speed-module-3", amount = 5 },
  }
  modify_ingredient_amount("77-energy-shield-mk5-equipment", 2, ({20, 50, 150})[diff_idx])
  modify_ingredient_amount("77-energy-shield-mk5-equipment", 3, ({3, 5, 15})[diff_idx])
  modify_ingredient_amount("77-energy-shield-mk5-equipment", 4, ({3, 5, 15})[diff_idx])
end