local mod_name = "__ev-assets__"

data:extend(
{
    
  {
    type = "technology",
    name = "77-energy-shield-mk3-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/energy-shield-mk3-equipment.png"),
    prerequisites = {"energy-shield-mk2-equipment", "military-4", "power-armor-mk2"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-energy-shield-mk3-equipment"
      }
    },
    unit =
    {
      count = 350,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1}
      },
      time = 40
    },
    order = "g-e-b-a"
  },
    
  {
    type = "technology",
    name = "77-energy-shield-mk4-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/energy-shield-mk4-equipment.png"),
    prerequisites = {"77-energy-shield-mk3-equipment", "efficiency-module-3"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-energy-shield-mk4-equipment"
      }
    },
    unit =
    {
      count = 500,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 40
    },
    order = "g-e-b-a"
  },
  {
    type = "technology",
    name = "77-energy-shield-mk5-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/energy-shield-mk5-equipment.png"),
    prerequisites = {"77-energy-shield-mk4-equipment", "productivity-module-3", "speed-module-3"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-energy-shield-mk5-equipment"
      }
    },
    unit =
    {
      count = 750,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 50
    },
    order = "g-e-b-a"
  },
  
})