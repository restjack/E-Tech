local mod_name = "__ev-assets__"
local shield_tiers = {"mk3", "mk4", "mk5"}

-- <> -- { v7.1.0: Shield properties : Health regen/s = Tier_input_flow_limit / tier_energy_per_shield } -- <> --

local shield_properties = {
  { 3, 3, 4 },                        -- tier_size
  { 500, 750, 2000 },                 -- tier_max_shield_value                                    -- { v7.1.0: 300>>500; 400>>750; 500>>2000 }
  { 300, 420, 660 },                  -- tier_buffer_capacity -- { tier_input_flow_limit / 2 }
  { 600, 840, 1320 },                 -- tier_input_flow_limit                                    -- { v7.1.0: 520>>600; 840>>840; 1350>>1320 }
  { 36, 50.4, 39.6 }                  -- tier_energy_per_shield -- { tier_max_shield_value / 5 }  -- { v7.1.0: 60>>36; 84>>50.4; 132>>39.6 }
}

-- <> -- { v7.1.0: Shield equipments } -- <> --

for i, shield_tier in pairs (shield_tiers) do
  data:extend(
  {
    {
      type = "energy-shield-equipment",
      name = "77-energy-shield-"..shield_tier.."-equipment",
      sprite =
      {
        filename = mod_name.."/graphics/equipment/energy-shield-"..shield_tier.."-equipment.png",
        width = 128,
        height = 128,
        priority = "medium",
        scale = 0.5
      },
      shape =
      {
        width = shield_properties[1][i] * settings.startup["shield-equipment-width-multiplier"].value,
        height = shield_properties[1][i] * settings.startup["shield-equipment-height-multiplier"].value,
        type = "full"
      },
      max_shield_value = shield_properties[2][i] * settings.startup["shield-equipment-max-value-multiplier"].value,
      energy_source =
      {
        type = "electric",
        buffer_capacity = shield_properties[3][i] * settings.startup["shield-equipment-capacity-multiplier"].value .. "kJ",
        input_flow_limit = shield_properties[4][i] * settings.startup["shield-equipment-capacity-multiplier"].value .. "kW",
        usage_priority = "primary-input"
      },
      energy_per_shield = shield_properties[5][i] * settings.startup["shield-equipment-consumption-multiplier"].value .. "kJ",
      categories = {"armor"}
    }
  })
end