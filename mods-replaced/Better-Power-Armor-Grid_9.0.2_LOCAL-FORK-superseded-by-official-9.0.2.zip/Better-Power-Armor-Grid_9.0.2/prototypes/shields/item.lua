local mod_name = "__ev-assets__"
local item_sounds = require("__base__.prototypes.item_sounds")

local shield_tiers = {"mk3", "mk4", "mk5"}
local properties = {
  { 15, 15, 10 }, -- (v2.0.0 Changes: -5; -5; -10)
  { 20, 15, 15, 10 } -- (v2.0.0 Changes: +0; -5; -5; -10)
}

data.raw.item["energy-shield-equipment"].subgroup = "ev-shields"
data.raw.item["energy-shield-equipment"].order = "aa"

data.raw.item["energy-shield-mk2-equipment"].subgroup = "ev-shields"
data.raw.item["energy-shield-mk2-equipment"].order = "ab"

for i, shield_tier in pairs (shield_tiers) do
  data:extend({
    {
      type = "item",
      name = "77-energy-shield-"..shield_tier.."-equipment",
      localised_description = {"item-description.energy-shield-equipment"},
		  icon = mod_name.."/graphics/icons/energy-shield-"..shield_tier.."-equipment.png",
      icon_size = 64, icon_mipmaps = 4,
      place_as_equipment_result = "77-energy-shield-"..shield_tier.."-equipment",
      subgroup = "ev-shields",
      order = "ac",
      inventory_move_sound = item_sounds.energy_shield_inventory_move,
      pick_sound = item_sounds.energy_shield_inventory_pickup,
      drop_sound = item_sounds.energy_shield_inventory_move,
      default_request_amount = 10, -- (v2.0.0 Changes: +5)
      stack_size = properties[1][i]
    }
  })
end