data:extend(
{
  {
    type = "item-subgroup",
    name = "ev-armor",
    group = "combat",
    order = "da[armor]-db[ev-armor]"
  },
  {
    type = "item-subgroup",
    name = "ev-fission",
    group = "combat",
    order = "da[armor]-dca[ev-fission]"
  },
  {
    type = "item-subgroup",
    name = "ev-fusion",
    group = "combat",
    order = "da[armor]-dcb[ev-fusion]"
  },
  {
    type = "item-subgroup",
    name = "ev-exoskeletons",
    group = "combat",
    order = "da[armor]-dd[ev-exoskeletons]"
  },
  {
    type = "item-subgroup",
    name = "ev-roboports",
    group = "combat",
    order = "da[armor]-de[ev-roboports]"
  },
  {
    type = "item-subgroup",
    name = "ev-shields",
    group = "combat",
    order = "da[armor]-df[ev-shields]"
  },
  {
    type = "item-subgroup",
    name = "ev-lasers",
    group = "combat",
    order = "da[armor]-dg[ev-lasers]"
  },
  {
    type = "item-subgroup",
    name = "ev-utility",
    group = "combat",
    order = "da[armor]-dh[ev-utility]"
  },
})