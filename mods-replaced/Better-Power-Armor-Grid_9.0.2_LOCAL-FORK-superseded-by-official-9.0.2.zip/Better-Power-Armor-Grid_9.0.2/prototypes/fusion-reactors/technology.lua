local mod_name = "__ev-assets__"

data:extend(
{

  {
    type = "technology",
    name = "77-fusion-reactor-mk2-equipment",
    icon_size = 256, -- icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/fusion-reactor-mk2-equipment.png"),
    prerequisites =
    {
      "fusion-reactor-equipment",
      "productivity-module-3",
      "quality-module-3",
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-fusion-reactor-mk2-equipment"
      }
    },
    unit =
    {
      count = 1500,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
        {"space-science-pack", 1},
        {"metallurgic-science-pack", 1},
        {"agricultural-science-pack", 1},
        {"electromagnetic-science-pack", 1},
        {"cryogenic-science-pack", 1}
      },
      time = 75
    },
  },
  {
    type = "technology",
    name = "77-fusion-reactor-mk3-equipment",
    icon_size = 256, -- icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/fusion-reactor-mk3-equipment.png"),
    prerequisites =
    {
      "77-fusion-reactor-mk2-equipment", "promethium-science-pack"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "77-fusion-reactor-mk3-equipment"
      }
    },
    unit =
    {
      count = 3000,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
        {"space-science-pack", 1},
        {"metallurgic-science-pack", 1},
        {"agricultural-science-pack", 1},
        {"electromagnetic-science-pack", 1},
        {"cryogenic-science-pack", 1}
      },
      time = 75
    },
  }

})