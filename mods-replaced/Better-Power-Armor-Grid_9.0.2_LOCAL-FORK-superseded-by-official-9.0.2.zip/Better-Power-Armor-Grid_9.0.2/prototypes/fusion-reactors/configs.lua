local mod_name = "__ev-assets__"

-- <> -- { File edited in version: v7.1.0 } -- <> --

-- <> -- { v7.1.0: Vanilla + Space age changes } -- <> --

data.raw.technology["fusion-reactor-equipment"].icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/fusion-reactor-equipment.png")
data.raw.technology["fusion-reactor-equipment"].icon_mipmaps = 0

data.raw["generator-equipment"]["fusion-reactor-equipment"].sprite.filename = mod_name.."/graphics/equipment/fusion-reactor-equipment.png"
data.raw.item["fusion-reactor-equipment"].icon = mod_name.."/graphics/icons/fusion-reactor-equipment.png"
data.raw.item["fusion-reactor-equipment"].subgroup = "ev-fusion"
data.raw.item["fusion-reactor-equipment"].order = "aa"

-- <> -- { v6.2.0: Equipment division changes } -- <> --

local tiers = {"mk2", "mk3", "mk4", "mk5", "mk6"}

if settings.startup["ev-armors-enabled"].value == true and settings.startup["ev-armor-division"].value == true then
    for i, tier in pairs (tiers) do
        table.insert(data.raw["generator-equipment"]["77-fusion-reactor-"..tier.."-equipment"].categories, "ind_armor")
    end
end

-- <> -- { v6.2.0: Apply the base values to the equipments and eventually any setting modification } -- <> --

for i, tier in pairs (tiers) do
    local width = settings.startup["fusion-reactor-equipment-width"].value
    local height = settings.startup["fusion-reactor-equipment-height"].value
    local power = {3.0, 5.0, 5.0, 5.0, 5.0}
    data.raw["generator-equipment"]["77-fusion-reactor-"..tier.."-equipment"].shape.width = width
    data.raw["generator-equipment"]["77-fusion-reactor-"..tier.."-equipment"].shape.height = height
    data.raw["generator-equipment"]["77-fusion-reactor-"..tier.."-equipment"].power = power[i] * settings.startup["fusion-reactor-power-multiplier"].value .."MW"
end

-- <> -- { v9.0.0: Recipe difficulty changes via settings } -- <> --

local diff_setting = settings.startup["ev-equipment-recipe-difficulty"].value
local diff_idx = (diff_setting == "Easy" and 1) or (diff_setting == "Normal" and 2) or 3

local function modify_ingredient_amount(recipe_name, index, new_amount)
    if not new_amount then return end 
    
    local recipe = data.raw.recipe[recipe_name]
    if recipe and recipe.ingredients and recipe.ingredients[index] then
        local ing = recipe.ingredients[index]
        
        if ing.amount then
            ing.amount = new_amount
        else
            ing[2] = new_amount
        end
    end
end

modify_ingredient_amount("77-fusion-reactor-mk2-equipment", 2, ({10, 20, 50})[diff_idx])
modify_ingredient_amount("77-fusion-reactor-mk2-equipment", 3, ({20, 40, 100})[diff_idx])
modify_ingredient_amount("77-fusion-reactor-mk2-equipment", 4, ({150, 300, 500})[diff_idx])
modify_ingredient_amount("77-fusion-reactor-mk2-equipment", 5, ({10, 20, 40})[diff_idx])
modify_ingredient_amount("77-fusion-reactor-mk2-equipment", 6, ({15, 25, 50})[diff_idx])

modify_ingredient_amount("77-fusion-reactor-mk3-equipment", 2, ({10, 30, 70})[diff_idx])
modify_ingredient_amount("77-fusion-reactor-mk3-equipment", 3, ({25, 50, 100})[diff_idx])
modify_ingredient_amount("77-fusion-reactor-mk3-equipment", 4, ({200, 300, 500})[diff_idx])
modify_ingredient_amount("77-fusion-reactor-mk3-equipment", 5, ({300, 500, 700})[diff_idx])
