local mod_name = "__ev-assets__"

-- <> -- { v7.1.0: Reactor recipes } -- <> --

data:extend(
{
  {
    type = "recipe",
    name = "77-fusion-reactor-mk2-equipment",
    enabled = false,
    energy_required = 45,
    ingredients =
    {
      { type = "item", name = "fusion-reactor-equipment", amount = 1 },
      { type = "item", name = "fusion-power-cell", amount = 20 },
      { type = "item", name = "supercapacitor", amount = 40 },
      { type = "item", name = "quantum-processor", amount = 300 },
      
      { type = "item", name = "productivity-module-3", amount = 20 },
      { type = "item", name = "quality-module-3", amount = 25 }
    },
    results = { {type = "item", name = "77-fusion-reactor-mk2-equipment", amount = 1 } }
  },
  {
    type = "recipe",
    name = "77-fusion-reactor-mk3-equipment",
    enabled = false,
    energy_required = 60,
    ingredients =
    {
      { type = "item", name = "77-fusion-reactor-mk2-equipment", amount = 1 },
      { type = "item", name = "fusion-power-cell", amount = 30 },
      { type = "item", name = "supercapacitor", amount = 50 },
      { type = "item", name = "quantum-processor", amount = 300 },
      
      { type = "item", name = "promethium-asteroid-chunk", amount = 500 }
    },
    results = { {type = "item", name = "77-fusion-reactor-mk3-equipment", amount = 1 } }
  }
})