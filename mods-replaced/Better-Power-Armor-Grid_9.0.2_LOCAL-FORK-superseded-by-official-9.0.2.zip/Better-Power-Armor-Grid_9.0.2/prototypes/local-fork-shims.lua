-- { LOCAL FORK 9.0.2 - NOT PART OF THE UPSTREAM MOD }
--
-- Upstream 9.0.1 crashes on load with Krastorio2: its K2 compat files call
-- three evanilla functions that no mod defines (ev-assets 3.1.1 only defines
-- evanilla.recipe.add_* and evanilla.tech.add_* - the author's evanilla.item
-- migration shipped half-finished). This file fills exactly those gaps.
--
-- Every definition is guarded with "if not already defined": the moment a
-- future ev-assets (or BPAG) release ships the real functions, these shims
-- are dead code and this fork can be replaced by the official zip.
--
-- Missing functions and what we do:
--   evanilla.recipe.replace_item_in_recipes(old, new)
--       Implemented for real (swap the item name in every recipe's
--       ingredients/results) - the exoskeleton path calls it on items that
--       exist, so a no-op would silently change recipe outcomes.
--   evanilla.item.replace_item(new, old)
--       Logged no-op. Its only call sites target kr-power-armor-mk3/mk4,
--       which do not exist in the Krastorio2 2.1 fork - there is nothing
--       to replace on this modpack.
--   evanilla.item.edit_item(name, props)
--       Logged no-op (only referenced from commented-out lines upstream;
--       defined for safety).

evanilla = evanilla or {}
evanilla.recipe = evanilla.recipe or {}
evanilla.item = evanilla.item or {}

if not evanilla.recipe.replace_item_in_recipes then
  evanilla.recipe.replace_item_in_recipes = function(old_name, new_name)
    local touched = 0
    for _, recipe in pairs(data.raw.recipe) do
      for _, ing in pairs(recipe.ingredients or {}) do
        if ing.name == old_name then
          ing.name = new_name
          touched = touched + 1
        end
      end
      for _, res in pairs(recipe.results or {}) do
        if res.name == old_name then
          res.name = new_name
          touched = touched + 1
        end
      end
    end
    log("[BPAG 9.0.2 local fork] replace_item_in_recipes('" .. tostring(old_name) .. "' -> '" .. tostring(new_name) .. "'): " .. touched .. " reference(s) updated")
  end
end

if not evanilla.item.replace_item then
  evanilla.item.replace_item = function(new_item, old_item)
    log("[BPAG 9.0.2 local fork] evanilla.item.replace_item('" .. tostring(new_item) .. "', '" .. tostring(old_item) .. "') stubbed (missing upstream) - skipped")
  end
end

if not evanilla.item.edit_item then
  evanilla.item.edit_item = function(item_name)
    log("[BPAG 9.0.2 local fork] evanilla.item.edit_item('" .. tostring(item_name) .. "') stubbed (missing upstream) - skipped")
  end
end
