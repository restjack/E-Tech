local mod_name = "__ev-assets__"

-- <> -- { v7.0.0: Space age changes - Graphics } -- <> --

if mods ["space-age"] then
    if settings.startup["ev-armors-enabled"].value == true then
        data.raw["technology"]["power-armor-mk2"].icon = mod_name.."/graphics/technology/power-armor-mk2.png"
    end
    if settings.startup["ev-mech-enabled"].value == true then
      local character = data.raw.character["character"]
      if not character then return end

      if settings.startup["ev-mech-max-tier"].value > 1 then
        local mech_armor_mk2 = table.deepcopy(character.animations[4])
        mech_armor_mk2.armors = {"77-mech-armor-mk2"}
        table.insert(data.raw.character.character.animations, mech_armor_mk2)
      end
      
      if settings.startup["ev-mech-max-tier"].value > 2 then
        local mech_armor_mk3 = table.deepcopy(character.animations[4])
        mech_armor_mk3.armors = {"77-mech-armor-mk3"}
        table.insert(data.raw.character.character.animations, mech_armor_mk3)
      end
    end
else
    if settings.startup["ev-armors-enabled"].value == true then
        data.raw["technology"]["power-armor-mk2"].icon = mod_name.."/graphics/technology/power-armor-mk2.png"
        table.insert(data.raw.technology["power-armor-mk2"].effects, { type = "unlock-recipe", recipe = "industrial-armor-mk1" })
        table.insert(data.raw.technology["power-armor-mk2"].prerequisites, "productivity-module-2")
    end
end