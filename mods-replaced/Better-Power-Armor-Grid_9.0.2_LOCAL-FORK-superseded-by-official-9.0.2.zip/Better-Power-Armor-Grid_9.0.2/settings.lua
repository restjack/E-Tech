data:extend(
{

  {
    type = "string-setting",
    name = "ev-equipment-recipe-difficulty",
    setting_type = "startup",
    default_value = "Normal",
    allowed_values = {"Easy", "Normal", "Hard"},
    order = "aa"
  },

  -- <> -- { v5.0.0: Armor settings } -- <> --

  {
    type = "bool-setting",
    name = "ev-armors-enabled",
    setting_type = "startup",
    default_value = true,
    order = "ba"
  },
  {
    type = "bool-setting",
    name = "ev-armor-division",
    setting_type = "startup",
    default_value = true,
    order = "bb"
  },
  {
    type = "string-setting",
    name = "grid-size",
    setting_type = "startup",
    default_value = "Medium",
    allowed_values = {"Small", "Medium", "Big", "Behemoth"},
    order = "bc"
  },
  {
    type = "int-setting",
    name = "maximum-armor-tier",
    setting_type = "startup",
    default_value = 6,
    minimum_value = 3,
    order = "bd"
  },

  -- <> -- { v7.0.0: Mech armors } -- <> --
  
  {
    type = "bool-setting",
    name = "ev-mech-enabled",
    setting_type = "startup",
    default_value = true,
    order = "bea"
  },
  {
    type = "int-setting",
    name = "ev-mech-max-tier",
    setting_type = "startup",
    default_value = 3,
    minimum_value = 1,
    maximum_value = 3,
    order = "beb"
  },
  {
    type = "int-setting",
    name = "ev-mech-grid-1",
    setting_type = "startup",
    default_value = 10,
    order = "bec"
  },


  {
    type = "int-setting",
    name = "ev-mech-grid-2",
    setting_type = "startup",
    default_value = 12,
    order = "bed"
  },
  {
    type = "string-setting",
    name = "ev-mech-grid-2-ingredient-1",
    setting_type = "startup",
    default_value = "lithium-plate",
    order = "bedb"
  },
  {
    type = "int-setting",
    name = "ev-mech-grid-2-ingredient-1-amount",
    setting_type = "startup",
    default_value = 250,
    order = "bedc"
  },
  {
    type = "string-setting",
    name = "ev-mech-grid-2-ingredient-2",
    setting_type = "startup",
    default_value = "processing-unit",
    order = "bedd"
  },
  {
    type = "int-setting",
    name = "ev-mech-grid-2-ingredient-2-amount",
    setting_type = "startup",
    default_value = 150,
    order = "bede"
  },
  {
    type = "string-setting",
    name = "ev-mech-grid-2-ingredient-3",
    setting_type = "startup",
    default_value = "superconductor",
    order = "bedf"
  },
  {
    type = "int-setting",
    name = "ev-mech-grid-2-ingredient-3-amount",
    setting_type = "startup",
    default_value = 75,
    order = "bedg"
  },
  {
    type = "string-setting",
    name = "ev-mech-grid-2-ingredient-4",
    setting_type = "startup",
    default_value = "supercapacitor",
    order = "bedh"
  },
  {
    type = "int-setting",
    name = "ev-mech-grid-2-ingredient-4-amount",
    setting_type = "startup",
    default_value = 75,
    order = "bedi"
  },


  {
    type = "int-setting",
    name = "ev-mech-grid-3",
    setting_type = "startup",
    default_value = 14,
    order = "bee"
  },
  {
    type = "string-setting",
    name = "ev-mech-grid-3-ingredient-1",
    setting_type = "startup",
    default_value = "promethium-asteroid-chunk",
    order = "beeb"
  },
  {
    type = "int-setting",
    name = "ev-mech-grid-3-ingredient-1-amount",
    setting_type = "startup",
    default_value = 500,
    order = "beec"
  },
  {
    type = "string-setting",
    name = "ev-mech-grid-3-ingredient-2",
    setting_type = "startup",
    default_value = "quantum-processor",
    order = "beed"
  },
  {
    type = "int-setting",
    name = "ev-mech-grid-3-ingredient-2-amount",
    setting_type = "startup",
    default_value = 200,
    order = "beee"
  },
  {
    type = "string-setting",
    name = "ev-mech-grid-3-ingredient-3",
    setting_type = "startup",
    default_value = "superconductor",
    order = "beef"
  },
  {
    type = "int-setting",
    name = "ev-mech-grid-3-ingredient-3-amount",
    setting_type = "startup",
    default_value = 150,
    order = "beeg"
  },
  {
    type = "string-setting",
    name = "ev-mech-grid-3-ingredient-4",
    setting_type = "startup",
    default_value = "supercapacitor",
    order = "beeh"
  },
  {
    type = "int-setting",
    name = "ev-mech-grid-3-ingredient-4-amount",
    setting_type = "startup",
    default_value = 150,
    order = "beei"
  },

  -- <> -- { v5.0.0: Fission reactors settings } -- <> --
  
  {
    type = "bool-setting",
    name = "fission-reactors-enabled",
    setting_type = "startup",
    default_value = true,
    order = "caa"
  },
  {
    type = "int-setting",
    name = "fission-reactor-equipment-height",
    setting_type = "startup",
    default_value = 4,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "cab"
  },
  {
    type = "int-setting",
    name = "fission-reactor-equipment-width",
    setting_type = "startup",
    default_value = 4,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "cac"
  },
  {
    type = "double-setting",
    name = "fission-reactor-power-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "cad"
  },

  -- <> -- { v5.0.0: Fusion reactors settings } -- <> --
  
  {
    type = "bool-setting",
    name = "fusion-reactors-enabled",
    setting_type = "startup",
    default_value = true,
    order = "cba"
  },
  {
    type = "int-setting",
    name = "fusion-reactor-equipment-height",
    setting_type = "startup",
    default_value = 4,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "cbb"
  },
  {
    type = "int-setting",
    name = "fusion-reactor-equipment-width",
    setting_type = "startup",
    default_value = 4,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "cbc"
  },
  {
    type = "double-setting",
    name = "fusion-reactor-power-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "cbd"
  },

  -- <> -- { v5.0.0: Exoskeletons settings } -- <> --
  
  {
    type = "bool-setting",
    name = "exoskeletons-enabled",
    setting_type = "startup",
    default_value = true,
    order = "da"
  },
  {
    type = "int-setting",
    name = "exoskeleton-equipment-height",
    setting_type = "startup",
    default_value = 4,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "db"
  },
  {
    type = "int-setting",
    name = "exoskeleton-equipment-width",
    setting_type = "startup",
    default_value = 2,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "dc"
  },
  {
    type = "double-setting",
    name = "exoskeleton-movement-bonus-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "dd"
  },

  -- <> -- { v5.0.0: Roboports settings } -- <> --
  
  {
    type = "bool-setting",
    name = "roboports-enabled",
    setting_type = "startup",
    default_value = true,
    order = "ea"
  },
  {
    type = "int-setting",
    name = "roboports-equipment-size",
    setting_type = "startup",
    default_value = 3,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "eb"
  },
  {
    type = "string-setting",
    name = "roboports-robot-limit",
    setting_type = "startup",
    default_value = "Medium",
    allowed_values = {"Small", "Medium", "Big"},
    order = "ec"
  },
  {
    type = "string-setting",
    name = "roboports-construction-radious",
    setting_type = "startup",
    default_value = "Medium",
    allowed_values = {"Small", "Medium", "Big"},
    order = "ed"
  },

  -- <> -- { v5.0.0: Shields settings } -- <> --
  
  {
    type = "bool-setting",
    name = "shields-enabled",
    setting_type = "startup",
    default_value = true,
    order = "fa"
  },
  {
    type = "int-setting",
    name = "shield-equipment-height-multiplier",
    setting_type = "startup",
    default_value = 1,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "fb"
  },
  {
    type = "int-setting",
    name = "shield-equipment-width-multiplier",
    setting_type = "startup",
    default_value = 1,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "fc"
  },
  {
    type = "double-setting",
    name = "shield-equipment-max-value-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "fd"
  },
  {
    type = "double-setting",
    name = "shield-equipment-capacity-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "fe"
  },
  {
    type = "double-setting",
    name = "shield-equipment-consumption-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "ff"
  },

  -- <> -- { v5.0.0: Personal lasers settings } -- <> --
  
  {
    type = "bool-setting",
    name = "lasers-enabled",
    setting_type = "startup",
    default_value = true,
    order = "ga"
  },
  {
    type = "int-setting",
    name = "laser-equipment-height",
    setting_type = "startup",
    default_value = 2,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "gb"
  },
  {
    type = "int-setting",
    name = "laser-equipment-width",
    setting_type = "startup",
    default_value = 2,
    allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
    order = "gc"
  },
  {
    type = "double-setting",
    name = "laser-equipment-damage-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "gd"
  },
  {
    type = "double-setting",
    name = "laser-equipment-range-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "ge"
  },
  {
    type = "double-setting",
    name = "laser-equipment-consumption-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "gf"
  },
  {
    type = "double-setting",
    name = "laser-equipment-shooting-speed-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "gg"
  },
  {
    type = "double-setting",
    name = "laser-equipment-buffer-capacity-multiplier",
    setting_type = "startup",
    default_value = 1,
    order = "gh"
  },

  -- <> -- { v5.0.0: Utility equipment settings } -- <> --
  
  {
    type = "bool-setting",
    name = "utility-equipment-enabled",
    setting_type = "startup",
    default_value = true,
    order = "ha"
  },
})