--[[
Credits to JDOGG, Optera, kendfrey, Rseding91 for their original void mods.
--]]

data:extend({
    {
        type = "recipe",
        name = "void-pipe",
        enabled = false,
        ingredients =
        {
            {type = "item", name = "pipe", amount = 1},
            {type = "item", name = "stone-furnace", amount = 1}
        },
        results = {{type="item", name="void-pipe", amount=1}},
    },
    {
        type = "recipe",
        name = "void-chest",
        enabled = false,
        ingredients =
        {
            {type = "item", name = "iron-chest", amount = 1},
            {type = "item", name = "stone-furnace", amount = 1}
        },
        results = {{type="item", name="void-chest", amount=1}},
    },
})
