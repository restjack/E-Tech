--[[
Credits to JDOGG, Optera, kendfrey, Rseding91 for their original void mods.
--]]

local voidTint = {
    r = settings.startup["tint-r"].value,
    g = settings.startup["tint-g"].value,
    b = settings.startup["tint-b"].value,
    a = 1
}

local function tintPictures(pictures, tint)
    for _, picture in pairs(pictures) do
        picture.tint = tint;
        if picture.hr_version then
            picture.hr_version.tint = tint;
        end
    end
end

local void_pipe = table.deepcopy(data.raw["pipe"]["pipe"])
void_pipe.type = "infinity-pipe"
void_pipe.name = "void-pipe"
void_pipe.minable.result = "void-pipe"
void_pipe.gui_mode = "none"
void_pipe.fluid_box.height = 1
void_pipe.fluid_box.base_area = 2500
void_pipe.se_allow_in_space = true
void_pipe.pictures = table.deepcopy(data.raw["pipe"]["pipe"].pictures)
tintPictures(void_pipe.pictures, voidTint)

local void_chest = table.deepcopy(data.raw["container"]["iron-chest"])
void_chest.type = "infinity-container"
void_chest.name = "void-chest"
void_chest.minable.result = "void-chest"
void_chest.order = "a[items]-c[void-chest]"
void_chest.erase_contents_when_mined = true
void_chest.logistic_mode = nil
void_chest.gui_mode = "none"
void_chest.se_allow_in_space = true
void_chest.inventory_size = settings.startup["slots"].value
void_chest.circuit_wire_max_distance = 0
void_chest.enable_inventory_bar = false
void_chest.picture.layers[1].tint = voidTint
--void_chest.picture.layers[1].hr_version.tint = voidTint

data:extend({
    void_pipe,
    void_chest,
})
