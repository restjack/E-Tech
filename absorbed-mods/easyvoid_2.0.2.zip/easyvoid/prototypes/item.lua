--[[
Credits to JDOGG, Optera, kendfrey, Rseding91 for their original void mods.
--]]

local voidTint = {
    r = settings.startup["tint-r"].value,
    g = settings.startup["tint-g"].value,
    b = settings.startup["tint-b"].value,
    a = 1
}

local void_pipe = table.deepcopy(data.raw.item["pipe"])
void_pipe.name = "void-pipe"
void_pipe.place_result = "void-pipe"
void_pipe.order = void_pipe.order .. "a"
void_pipe.icon = nil
void_pipe.icons = {
	{
		icon = "__base__/graphics/icons/pipe.png",
		icon_size = 64,
	},
	{
		icon = "__base__/graphics/icons/pipe.png",
		icon_size = 64,
		tint = voidTint,
	},
}

local void_chest = table.deepcopy(data.raw.item["iron-chest"])
void_chest.name = "void-chest"
void_chest.place_result = "void-chest"
void_chest.order = "a[items]-c[void-chest]"
void_chest.icon = nil
void_chest.icons = {
	{
		icon = "__base__/graphics/icons/iron-chest.png",
		icon_size = 64,
	},
	{
		icon = "__base__/graphics/icons/iron-chest.png",
		icon_size = 64,
		tint = voidTint,
	},
}

data:extend({
    void_pipe,
    void_chest,
})
