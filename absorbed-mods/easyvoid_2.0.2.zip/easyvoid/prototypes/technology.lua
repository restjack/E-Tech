--[[
Credits to JDOGG, Optera, kendfrey, Rseding91 for their original void mods.
--]]

data:extend(
{
    {
        type = "technology",
        name = "void",
        icon = "__easyvoid__/graphics/technology/easyvoid.png",
        icon_size = 128,
        prerequisites = {
            "fluid-handling",
        },
        effects =
        {
            {
                type = "unlock-recipe",
                recipe = "void-pipe",
            },
            {
                type = "unlock-recipe",
                recipe = "void-chest",
            },
        },
        unit =
        {
            time = 30,
            count = 10,
            ingredients =
            {
                {"automation-science-pack", 1},
            },
        },
        order = "c-a",
    },
})
