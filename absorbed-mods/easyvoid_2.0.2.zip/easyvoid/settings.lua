--[[
Credits to JDOGG, Optera, kendfrey, Rseding91 for their original void mods.
--]]

data:extend(
    {
        {
            type = "double-setting",
            name = "tint-r",
            setting_type = "startup",
            minimum_value = 0,
            maximum_value = 1,
            default_value = 0.75,
            order = "aa",
        },
        {
            type = "double-setting",
            name = "tint-g",
            setting_type = "startup",
            minimum_value = 0,
            maximum_value = 1,
            default_value = 0,
            order = "ab",
        },
        {
            type = "double-setting",
            name = "tint-b",
            setting_type = "startup",
            minimum_value = 0,
            maximum_value = 1,
            default_value = 1,
            order = "ac",
        },
        {
            type = "double-setting",
            name = "slots",
            setting_type = "startup",
            minimum_value = 1,
            maximum_value = 10,
            default_value = 4,
            order = "ba",
        },
    }
)
