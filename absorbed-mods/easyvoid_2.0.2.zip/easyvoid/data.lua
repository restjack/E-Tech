--[[
Credits to JDOGG, Optera, kendfrey, Rseding91 for their original void mods.
--]]

require("prototypes.entity")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.technology")
