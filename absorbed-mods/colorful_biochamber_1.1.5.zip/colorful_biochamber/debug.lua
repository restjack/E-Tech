

function d(inx)
	local typex=type(inx);
	if(typex=="number") then d({inx});return;end
	
	if(inx.help) then d(inx.object_name.."/"..inx.name.." is cpp structure");return;end
	if(inx=={}) then d("empty structure");return;end
	
	log( serpent.block(inx) );
end


function p(inx)
	local typex=type(inx);
	if(typex=="number") then p({inx});return;end
	
	if(inx.help) then p(inx.object_name.."/"..inx.name.." is cpp structure");return;end
	if(inx=={}) then p("empty structure");return;end
	
	game.print( serpent.block(inx) );
end



function pd(inx)
	d(inx);
if(game) then
	p(inx);
end
	return;
end


return pd;