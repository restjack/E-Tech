


local function support(inname)
	if( mods[inname] ) then
		require("support."..inname);
	end
end




support("sei-biochamber");
support("space-age");


