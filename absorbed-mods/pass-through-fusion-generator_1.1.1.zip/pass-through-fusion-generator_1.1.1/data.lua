fusion_generator = data.raw["fusion-generator"]["fusion-generator"]
fusion_generator.input_fluid_box.pipe_connections =       {
  { flow_direction="input-output",  direction = defines.direction.south, position = {-1,  2}, connection_category = {"fusion-plasma"} },
  { flow_direction="input-output",  direction = defines.direction.south, position = { 1,  2}, connection_category = {"fusion-plasma"} },
  { flow_direction="input-output", direction = defines.direction.north, position = { 0, -2}, connection_category = {"fusion-plasma"} },
  { flow_direction="input-output", direction = defines.direction.west,  position = {-1,  0}, connection_category = {"fusion-plasma"} },
  { flow_direction="input-output", direction = defines.direction.east,  position = { 1,  0}, connection_category = {"fusion-plasma"} },
  { flow_direction="input-output", direction = defines.direction.west,  position = {-1, -1}, connection_category = {"fusion-plasma"} },
  { flow_direction="input-output", direction = defines.direction.east,  position = { 1, -1}, connection_category = {"fusion-plasma"} },
}

