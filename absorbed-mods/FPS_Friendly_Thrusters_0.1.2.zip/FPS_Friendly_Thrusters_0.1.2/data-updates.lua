data.raw.thruster.thruster.plumes = nil
