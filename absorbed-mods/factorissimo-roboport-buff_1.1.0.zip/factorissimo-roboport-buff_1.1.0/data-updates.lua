local factorissimo_roboport = data.raw["roboport"]["factory-construction-roboport"]

if factorissimo_roboport then
    -- Retrieve the slot counts from the player's startup settings
    local robot_slots = settings.startup["frb-robot-slots"].value
    local material_slots = settings.startup["frb-material-slots"].value
    
    factorissimo_roboport.logistics_radius = 64
    factorissimo_roboport.robot_slots_count = robot_slots
    factorissimo_roboport.material_slots_count = material_slots
end
