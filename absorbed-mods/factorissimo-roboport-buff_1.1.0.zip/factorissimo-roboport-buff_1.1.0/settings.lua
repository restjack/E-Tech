data:extend({
    {
        type = "int-setting",
        name = "frb-robot-slots",
        setting_type = "startup",
        default_value = 7,
        minimum_value = 0
    },
    {
        type = "int-setting",
        name = "frb-material-slots",
        setting_type = "startup",
        default_value = 7,
        minimum_value = 1
    }
})
